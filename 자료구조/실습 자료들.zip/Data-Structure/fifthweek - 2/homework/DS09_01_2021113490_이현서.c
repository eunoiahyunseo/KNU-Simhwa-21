#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#define ERROR_KEY -100

#define MALLOC(p, s)                            \
    if (!((p) = malloc(s)))                     \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

#define REALLOC(p, s)                           \
    if (!((p) = realloc(p, s)))                 \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

typedef struct listNode_
{
    int data;
    struct listNode_ *link;
} listNode, *listPointer;

/* insert a new node with data = 50 into the chain first after node x */
void insert(listPointer *first, listPointer x, int data)
{
    listPointer temp;
    MALLOC(temp, sizeof(*temp));
    temp->data = data;
    // 만약 first가 null이 아니라면
    if (*first)
    {
        temp->link = x->link;
        x->link = temp;
    }
    else
    // 만약 first가 null이라면
    {
        temp->link = NULL;
        *first = temp;
    }
}

/* delete x from the list, trail is the preceding node and *first is the front of the list */
void delete (listPointer *first, listPointer trail, listPointer x)
{
    if (trail)
        trail->link = x->link;
    else
        *first = (*first)->link;

    free(x);
}

listPointer invert(listPointer lead)
{
    /*
        invert the list pointed to by lead
    */
    listPointer middle, trail;
    middle = NULL;
    while (lead)
    {
        trail = middle;
        middle = lead;
        lead = lead->link;
        middle->link = trail;
    }

    return middle;
}

void printList(listPointer first)
{
    for (; first; first = first->link)
        printf("(%p, %d, %p) ", first, first->data, first->link);
    printf("\n");
}

int main(void)
{
    FILE *fp_read;
    int input1Arr[1000] = {0}, input2Arr[1000] = {0}, i;
    fp_read = fopen("input1.txt", "r");
    int count = 0, count2 = 0;
    while (fscanf(fp_read, "%d", input1Arr + count) != EOF)
    {
        count++;
    }

    fp_read = fopen("input2.txt", "r");
    while (fscanf(fp_read, "%d", input2Arr + count2) != EOF)
    {
        count2++;
    }

    listPointer head = NULL;
    listPointer temp = NULL;

    for (i = 0; i < count; i++)
    {
        insert(&head, temp, input1Arr[i]);

        if (i == 0)
        {
            temp = head;
        }
        else
        {
            temp = temp->link;
        }
    }
    printf("First:\n");
    printList(head);
    putchar('\n');

    listPointer head2 = NULL;
    listPointer temp2 = NULL;
    for (i = 0; i < count2; i++)
    {
        insert(&head2, temp2, input2Arr[i]);

        if (i == 0)
        {
            temp2 = head2;
        }
        else
        {
            temp2 = temp2->link;
        }
    }
    printf("Second:\n");
    printList(head2);
    putchar('\n');

    listPointer temp3 = head;
    while (temp3->link != NULL)
    {
        temp3 = temp3->link;
    }

    temp3->link = head2;

    printf("Concatenate:\n");
    printList(head);
    putchar('\n');

    printf("Invert:\n");
    printList(invert(head));
    putchar('\n');

    fclose(fp_read);

    return 0;
}