#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SiZE 1000
int *failureArr;
// failure함수에는 패턴이 일단 있어야 한다.
// 처음으로 맞지 않는 값을 제공해 줘야 한다.
void failure(char *patString)
{
    // int n = strlen(patString);
    // failureArr[0] = -1;
    // int i, j;
    // for (j = 1; j < n; j++)
    // {
    //     i = failureArr[j - 1];
    //     while ((patString[j] != patString[i + 1]) && (i >= 0))
    //     {
    //         i = failureArr[i];
    //     }

    //     if (patString[j] == patString[i + 1])
    //     {
    //         failureArr[j] = i + 1;
    //     }
    //     else
    //     {
    //         failureArr[j] = -1;
    //     }
    // }

    int n = strlen(patString);
    failureArr[0] = -1;
    int i, j;
    for (j = 1; j < n; j++)
    {
        i = failureArr[j - 1];
        while ((i >= 0) && patString[j] != patString[i + 1])
        {
            i = failureArr[i];
        }

        if (patString[j] == patString[i + 1])
        {
            failureArr[j] = i + 1;
        }
        else
        {
            failureArr[j] = -1;
        }
    }

    printf("Failure function:\n");
    for (j = 0; j < n; j++)
    {
        if (j == 0)
        {
            printf("j\t%d", j);
        }
        else
        {
            printf("\t%d", j);
        }
    }
    putchar('\n');

    for (j = 0; j < n; j++)
    {
        if (j == 0)
        {
            printf("pat\t%c", patString[j]);
        }
        else
        {
            printf("\t%c", patString[j]);
        }
    }

    putchar('\n');
    for (j = 0; j < n; j++)
    {
        if (j == 0)
        {
            printf("f\t%d", failureArr[j]);
        }
        else
        {
            printf("\t%d", failureArr[j]);
        }
    }
    putchar('\n');
}

void failure2(char *patString, int *failureArr)
{
    failureArr[0] = -1;
    for (int i = 0, j = 1, status = -1; patString[j] != '\0'; ++j)
    {
        if (patString[i] != patString[j])
        {
            i = 0;
            status = -1;
            failureArr[j] = status;
        }
        else
        {
            i++;
            status++;
            failureArr[j] = status;
        }
    }
    for (int i = 0; i < strlen(patString); i++)
    {
        printf("%d ", failureArr[i]);
    }
}

int pmatch(char *string, char *pat)
{
    // int i = 0, j = 0;
    // int lens = strlen(string);
    // int lenp = strlen(pat);

    // while (i < lens && j < lenp)
    // {
    //     if (string[i] == pat[j])
    //     {
    //         i++;
    //         j++;
    //     }
    //     else if (j == 0)
    //     {
    //         i++;
    //     }
    //     else
    //     {
    //         j = failureArr[j - 1] + 1;
    //         printf("%d %d \n", i, j);
    //     }
    // }

    int i = 0, j = 0;
    int lens = strlen(string);
    int lenp = strlen(pat);

    while (i < lens && j < lenp)
    {
        if (string[i] == pat[j])
        {
            i++;
            j++;
        }
        else if (j == 0)
        {
            i++;
        }
        else
        {
            j = failureArr[j - 1] + 1;
        }
    }

    return ((j == lenp) ? (i - lenp) : -1);
}

int main(void)
{
    FILE *fp_read;
    fp_read = fopen("input.txt", "r");

    char firstString[MAX_SiZE] = {0};
    char secondString[MAX_SiZE] = {0};

    failureArr = malloc(sizeof(int) * strlen(secondString));

    fscanf(fp_read, "%s %s", firstString, secondString);

    // failure2(secondString, failureArr);
    failure(secondString);
    printf("The pattern %s is found at the position %d", secondString, pmatch(firstString, secondString));

    fclose(fp_read);

    return 0;
}
