#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_VERTEX 100
#define false 0
#define true 1

typedef struct node_
{
    int vertex;
    struct node_ *link;

} node, *nodePointer;

nodePointer front, rear;

// 인접 리스트
nodePointer adjList[MAX_VERTEX];
short int visited[MAX_VERTEX];
node queue[MAX_VERTEX];

void dfs(int v)
{
    nodePointer w;
    visited[v] = true;
    printf("%d ", v);
    w = adjList[v];
    while (w != NULL)
    {
        // 만약 방문하지 않은 vertex라면 dfs을 재귀적으로 돌린다.
        if (!visited[w->vertex])
            dfs(w->vertex);

        // 만약 방문한 vertex를 방문했다면
        w = w->link;
    }
}

void addq(int item)
{
    nodePointer temp = malloc(sizeof(*temp));
    temp->vertex = item;
    temp->link = NULL;
    if (!front || !rear)
    {
        front = rear = temp;
    }
    else
    {
        rear->link = temp;
        rear = rear->link;
    }
}

int deleteq()
{
    int temp = front->vertex;
    front = front->link;
    return temp;
}

void bfs(int v)
{
    nodePointer w;
    front = rear = NULL;
    printf("%d ", v);
    visited[v] = true;
    addq(v);
    while (front != NULL)
    {
        v = deleteq();
        w = adjList[v];
        while (w != NULL)
        {
            if (!visited[w->vertex])
            {
                printf("%d ", w->vertex);
                addq(w->vertex);
                visited[w->vertex] = true;
            }

            w = w->link;
        }
    }
}

int main(void)
{
    FILE *fp_read = fopen("input.txt", "r");

    if (fp_read == NULL)
    {
        fprintf(stderr, "File Open Error!");
        exit(EXIT_FAILURE);
    }

    int vertCount, data, check = false;
    fscanf(fp_read, "%d", &vertCount);

    nodePointer tempNode;
    for (int i = 0; i < vertCount; i++)
    {
        check = false;
        for (int j = 0; j < vertCount; j++)
        {
            fscanf(fp_read, "%d", &data);
            if (data == 1)
            {
                // data가 있는 거라면
                nodePointer temp = malloc(sizeof(*temp));
                temp->link = NULL;
                temp->vertex = j;
                if (check == false)
                {
                    adjList[i] = temp;
                    tempNode = temp;
                    check = true;
                }
                else
                {
                    tempNode->link = temp;
                    tempNode = tempNode->link;
                }
            }
        }
    }

    for (int i = 0; i < vertCount; i++)
    {
        printf("Vertex %d: ", i);
        tempNode = adjList[i];
        while (tempNode)
        {
            printf("%d ", tempNode->vertex);
            tempNode = tempNode->link;
        }
        printf("\n");
    }

    printf("DFS: ");
    dfs(0);
    printf("\n");

    memset(visited, false, sizeof(short int) * MAX_VERTEX);

    printf("BFS: ");
    bfs(0);

    return 0;
}
