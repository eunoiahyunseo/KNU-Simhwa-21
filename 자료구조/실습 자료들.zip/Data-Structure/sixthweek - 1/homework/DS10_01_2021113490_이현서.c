#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_QUEUES 10 /* maximum number of stacks */
#define ERROR_KEY -100

#define MALLOC(p, s)                            \
    if (!((p) = malloc(s)))                     \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

#define REALLOC(p, s)                           \
    if (!((p) = realloc(p, s)))                 \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

typedef struct polyNode
{
    int coef;
    int expon;
    struct polyNode *link;
} * polyPointer;

polyPointer a, b;

int COMPARE(int expon1, int expon2)
{
    if (expon1 < expon2)
        return -1;
    else if (expon1 > expon2)
        return 1;
    else
        return 0;
}

void attach(float coefficient, int exponent, polyPointer *ptr)
{
    /*
        create a new node with coef = coefficient and expon = exponent,
        attach it to the node point to by ptr.
    */
    polyPointer temp;
    MALLOC(temp, sizeof(*temp));
    temp->coef = coefficient;
    temp->expon = exponent;
    (*ptr)->link = temp;
    *ptr = temp;
}

polyPointer padd(polyPointer a, polyPointer b)
{
    /*
        return a polynomial which is the sum of a and b
    */
    int sum;
    polyPointer c, rear, temp;
    MALLOC(rear, sizeof(*rear));
    c = rear;

    while (a && b)
    {
        switch (COMPARE(a->expon, b->expon))
        {
        case -1:
            attach(b->coef, b->expon, &rear);
            b = b->link;
            break;
        case 0:
            sum = a->coef + b->coef;
            if (sum)
            {
                attach(sum, a->expon, &rear);
            }
            a = a->link;
            b = b->link;
            break;
        case 1:
            attach(a->coef, a->expon, &rear);
            a = a->link;
            break;
        }
    }
    /*
        copy rest of list a and then list b
    */

    for (; a; a = a->link)
        attach(a->coef, a->expon, &rear);
    for (; b; b = b->link)
        attach(b->coef, b->expon, &rear);

    /*
        delete extra initial node
    */

    temp = c;
    c = c->link;
    free(temp);
    return c;
}

void insert(polyPointer *first, polyPointer x, float coef, int expon)
{
    polyPointer temp;
    MALLOC(temp, sizeof(*temp));
    temp->coef = coef;
    temp->expon = expon;

    if (*first)
    {
        temp->link = x->link;
        x->link = temp;
    }
    else
    {
        temp->link = NULL;
        *first = temp;
    }
}

void printList(polyPointer first)
{
    int check = 0;
    for (; first; first = first->link)
    {
        if ((first->expon != 0) && check == 0)
        {
            printf("%.dx^%d", first->coef, first->expon);
        }
        else if ((first->expon != 0) && check != 0)
        {
            printf("%+dx^%d", first->coef, first->expon);
        }
        else
        {
            printf("%+d", first->coef);
            putchar('\n');
            return;
        }
        check++;
    }

    printf("\n");
}

void readPolynomial(polyPointer *pPoint, FILE *fp_read)
{
    int i, number, expon;
    float coef;
    polyPointer temp = NULL;
    fscanf(fp_read, "%d", &number);
    for (i = 0; i < number; i++)
    {
        fscanf(fp_read, "%f %d", &coef, &expon);
        insert(pPoint, temp, coef, expon);
        if (i == 0)
        {
            temp = *pPoint;
        }
        else
        {
            temp = temp->link;
        }
    }
}

void erase(polyPointer *ptr)
{
    /*
        erase the polynomial pointed to by ptr
     */
    polyPointer temp;
    while (*ptr)
    {
        temp = *ptr;
        *ptr = (*ptr)->link;
        free(temp);
    }
}

int main(void)
{
    FILE *fp_read;
    fp_read = fopen("a.txt", "r");

    polyPointer a = NULL;
    readPolynomial(&a, fp_read);

    polyPointer b = NULL;
    fp_read = fopen("b.txt", "r");
    readPolynomial(&b, fp_read);

    fclose(fp_read);

    polyPointer resultPolynomial = padd(a, b);
    printList(resultPolynomial);
    erase(&resultPolynomial);

    return 0;
}