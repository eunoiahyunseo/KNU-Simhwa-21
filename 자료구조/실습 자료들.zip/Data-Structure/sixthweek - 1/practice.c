#include <stdio.h>
#include <stdlib.h>

typedef struct node_
{
    int data;
    struct node_ *leftChild, rightChild;
} node, *treePointer;

void inorder(treePointer ptr)
{
    /* inorder tree traversal */
    if (ptr)
    {
        inorder(ptr->leftChild);
        printf("%d", ptr->data);
        inorder(ptr->rightChild);
    }
}

int main(void)
{

    return 0;
}