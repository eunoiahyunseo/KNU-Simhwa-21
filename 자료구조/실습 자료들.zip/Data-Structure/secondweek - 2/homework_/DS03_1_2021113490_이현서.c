#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main(void)
{
    srand(time(NULL));
    int number, i, j, temp;
    double start, end, res;
    printf("N: ");
    scanf("%d", &number);
    int *intArr = malloc(sizeof(int) * number);

    // 난수 생성 ( 0 ~ 9 ) 범위는 자율적으로 수정 가능
    int random = 0;

    for (i = 0; i < number; i++)
    {
        random = rand() % 9; // 난수 생성
        intArr[i] = random;
    }

    FILE *fp_open;

    fp_open = fopen("unsorted.txt", "w");

    for (i = 0; i < number; i++)
    {
        fprintf(fp_open, "%d ", intArr[i]);
    }

    start = (double)clock();
    int highest;
    for (i = 0; i < number - 1; i++)
    {
        highest = i;
        for (j = i + 1; j < number; j++)
        {
            if (intArr[j] > intArr[highest])
            {
                highest = j;
            }
        }
        int temp;
        temp = intArr[highest];
        intArr[highest] = intArr[i];
        intArr[i] = temp;
    }

    end = (double)clock();
    res = (end - start) / CLOCKS_PER_SEC;
    printf("Time: %lf", res);

    fp_open = fopen("sorted.txt", "w");

    for (i = 0; i < number; i++)
    {
        fprintf(fp_open, "%d ", intArr[i]);
    }

    fclose(fp_open);
    free(intArr);

    return 0;
}