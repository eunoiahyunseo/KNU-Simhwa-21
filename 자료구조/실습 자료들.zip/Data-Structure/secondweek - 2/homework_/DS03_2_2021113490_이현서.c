#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main(void)
{

    char ISBN[11];

    printf("ISBN: ");
    scanf("%s", ISBN);

    int i, sum = 0, number, index, missingDigit;

    for (i = 1; i < 11; i++)
    {
        if (isdigit(ISBN[i - 1]))
        {
            number = (ISBN[i - 1] - '0') * (11 - i);
            sum += number;
        }
        else
        {
            // 문자열중에 X라면
            if (ISBN[i - 1] == 'X')
            {
                number = 10;
                sum += number;
            }
            else
            {
                index = (11 - i);
                continue;
            }
        }
    }

    int result = sum;
    for (i = 0; i < 11; i++)
    {
        result += index * i;
        if (result % 11 == 0)
        {
            missingDigit = i;
            break;
        }
        else
        {
            result = sum;
        }
    }

    if (missingDigit == 10)
    {

        printf("Missing Digit: %c", 'X');
    }
    else
    {
        printf("Missing Digit: %d", missingDigit);
    }

    return 0;
}
