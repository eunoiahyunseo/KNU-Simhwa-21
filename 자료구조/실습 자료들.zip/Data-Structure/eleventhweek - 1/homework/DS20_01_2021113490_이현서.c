#include <stdio.h>
#include <stdlib.h>

#define MAX 1000

int record[MAX][2];

void SWAP(int *x, int *y)
{
    int temp;
    for (int i = 0; i < 2; i++)
    {
        temp = x[i];
        x[i] = y[i];
        y[i] = temp;
    }
}

void printList(int size)
{
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < 2; j++)
        {
            printf("%5d", record[i][j]);
        }
        printf("\n");
    }
}
void quickSort(int key, int left, int right)
{
    int pivot, i, j;
    if (left < right)
    {
        i = left, j = right + 1;
        pivot = record[left][key];
        do
        {
            do
                i++;
            while (record[i][key] < pivot);

            do
                j--;
            while (record[j][key] > pivot);

            if (i < j)
                SWAP(record[i], record[j]);
        } while (i < j);

        // 만약에 i가 j보다 작은 상황이라면
        // pivot에 해당하는 값을 j로 바꿔주면서 진행해야 한다.
        SWAP(record[left], record[j]);
        quickSort(key, left, j - 1);
        quickSort(key, j + 1, right);
    }
}

int main(void)
{
    FILE *fp_open = fopen("input.txt", "r");

    if (fp_open == NULL)
    {
        fprintf(stderr, "File open Error!");
    }

    int recordNum;
    fscanf(fp_open, "%d", &recordNum);

    int temp;
    for (int i = 0; i < recordNum; i++)
        for (int j = 0; j < 2; j++)
            fscanf(fp_open, "%d", &record[i][j]);

    printf("K1\n");
    quickSort(0, 0, recordNum - 1);
    printList(recordNum);

    printf("K2\n");
    quickSort(1, 0, recordNum - 1);
    printList(recordNum);

    fclose(fp_open);
    return 0;
}