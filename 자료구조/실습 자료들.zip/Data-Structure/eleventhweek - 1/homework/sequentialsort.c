#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ARR_SIZE 100

#define HEAP_FULL(n) (n == ARR_SIZE - 1)
#define HEAP_EMPTY(n) (!n)

int sorted[ARR_SIZE];

typedef struct
{
    int key;
} element;

element heap[ARR_SIZE];

void push(element item, int *n)
{
    int i;
    // 만약 힙이 꽉 차있다면
    if (HEAP_FULL(*n))
    {
        fprintf(stderr, "The heap is full. \n");
        exit(EXIT_FAILURE);
    }
    i = ++(*n);
    while ((i != 1) && (item.key > heap[i / 2].key))
    {
        heap[i] = heap[i / 2];
        i /= 2;
    }
    heap[i] = item;
}

element pop(int *n)
{
    int parent, child;
    element item, temp;
    if (HEAP_EMPTY(*n))
    {
        fprintf(stderr, "The heap is empty. \n");
        exit(EXIT_FAILURE);
    }
    item = heap[1];
    temp = heap[(*n)--];
    parent = 1;
    child = 2;
    while (child <= *n)
    {
        if ((child < *n) && (heap[child].key < heap[child + 1].key))
            child++;

        if (temp.key >= heap[child].key)
            break;

        heap[parent] = heap[child];
        parent = child;
        child *= 2;
    }
    heap[parent] = temp;
    return item;
}

void heap_sort(int a[], int n)
{
    int count = 0, i;
    element newElement = {0};

    // 우선 int 배열의 값을 하나씩 heap에 집어 넣어주어야 한다.
    for (int i = 0; i < n; i++)
    {
        newElement.key = a[i];
        push(newElement, &count);
    }

    for (i = (n - 1); i >= 0; i--)
    {
        a[i] = pop(&count).key;
    }
}

int seqSearch(int a[], int k, int n)
{
    int i;
    for (i = 1; i < n && a[i] != k; i++)
        ;

    if (i >= n)
        return -1;
    return i;
}

void swap(int *a, int *b)
{
    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}

void insertionSort(int a[], int n)
{
    /* sort a[0:n - 1] into nondecreasing order( 오름 차순 ) */
    int i, j, key;
    for (i = 1; i < n; i++)
    {
        key = a[i];
        // 현재 정렬된 배열은 i - 1까지 이므로 i - 1번째부터 역순으로 조사합니다.
        for (j = i - 1; j >= 0 && a[j] > key; j--)
            a[j + 1] = a[j];
        a[j + 1] = key;
    }
}

int partition(int list[], int left, int right)
{
    int pivot;
    int low, high;

    low = left;
    high = right + 1;
    pivot = list[left]; // 정렬할 리스트의 가장 왼쪽 데이터를 피벗으로 선택 ( 임의의 값을 피벗으로 선택 )

    /* low와 high가 교차할 때까지 반복 (low < high) */
    do
    {
        /* list[low]가 피벗보다 작으면 계속 low를 증가 시켜줘야 한다. */
        do
        {
            low++;
        } while (list[low] < pivot && low <= right); // low가 만약에 right이 된다면 멈처 주어야 합니다.

        do
        {
            high--;
        } while (list[high] > pivot && high >= left);

        // 만약 low와 high가 교차하지 않았으면 list[low]를 list[high]와 교환
        if (low < high)
            swap(list + low, list + high);
    } while (low < high);

    // low와 high가 교차했으면 반복문을 빠져나와 list[left]와 list[high]을 교환해줘야 한다.
    swap(list + left, list + high);

    // 피벗의 위치인 high를 반환해주어야 합니다.
    return high;
}

void quick_sort(int list[], int left, int right)
{
    /* 정렬할 범위가 2개 이상의 데이터가렴( 리스트의 크기가 0이나 1이 아니라면) */
    if (left < right)
    {
        // partition함수를 호출하여 피벗을 기준으로 리스트를 비균등 분할 - 분할(Divide)
        int q = partition(list, left, right);
        // 피벗을 제외한 2개의 부분 리스트를 대상으로 순환 호출
        quick_sort(list, left, q - 1);  // (left ~ 피벗 바로 앞) 앞쪽 부분 리스트 정렬 - 정복(Conquer)
        quick_sort(list, q + 1, right); // (피벗 바로 뒤 ~ right) 뒤쪽 부분 리스트 정렬 - 정복(Conquer)
    }
    else
    {
        return;
    }
}

void merge(int list[], int left, int mid, int right)
{
    int i, j, k, l;
    i = left;
    j = mid + 1;
    k = left;

    /* 분할 정렬된 list의 합병 */
    while (i <= mid && j <= right)
    {
        if (list[i] <= list[j])
            sorted[k++] = list[i++];
        else
            sorted[k++] = list[j++];
    }

    // 남아 있는 값들을 일괄 복사
    if (i > mid)
        for (l = j; j <= right; j++)
            sorted[k++] = list[j];
    else
        for (l = i; i <= mid; i++)
            sorted[k++] = list[l];

    for (l = left; l <= right; l++)
        list[l] = sorted[l];
}

void merge_sort(int list[], int left, int right)
{
    int mid;

    // 원소가 1개가 아닌 경우
    if (left < right)
    {
        mid = (left + right) / 2;         // 중간 위치를 계산하여 리스트를 균등 분할 - 분할(Divide)
        merge_sort(list, left, mid);      // 앞쪽 부분 리스트 정렬 - 정복(Conquer)
        merge_sort(list, mid + 1, right); // 뒤쪽 부분 리스트 정렬 - 정복(Conquer)
        merge(list, left, mid, right);    // 정렬된 2개의 부분 배열을 합병하는 과정 - 결합(Combine)
    }
    else
    {
        // 원소가 1개라면 그냥 return시켜 주면 된다.
        return;
    }
}

void bubble_sort(int list[], int n)
{
    int i, j, temp;

    for (i = 0; i < n; i++)
        for (j = 0; j < n - 1 - i; j++)
            if (list[j] > list[j + 1])
                swap(list + j, list + j + 1);
}

void selection_sort(int list[], int n)
{
    int i, j, least;

    // 마지막 숫자는 자동으로 정렬되기 때문에 (개수 - 1)만큼 반복합니다.
    for (i = 0; i < n - 1; i++)
    {
        least = i;

        // 최솟값을 탐색합니다.
        for (j = i + 1; j < n; j++)
            if (list[j] < list[least])
                least = j;

        // 최솟값이 자기 자신이면 자료 이동을 하지 않는다.
        if (i != least)
            swap(list + least, list + i);
    }
}

void printArr(int a[], int n)
{
    for (int i = 0; i < n; i++)
        printf("%d ", a[i]);

    putchar('\n');
}

int main(void)
{
    int sortArr[ARR_SIZE] = {0};
    int count = 0;

    FILE *fp_read = fopen("sort.txt", "r");
    while ((fscanf(fp_read, "%d", sortArr + count) != EOF))
    {
        count++;
    }

    printf("original array: ");
    printArr(sortArr, count);

    // printf("[ 4 ] is in index %d\n", seqSearch(sortArr, 4, count));

    int sortArr_2[ARR_SIZE];
    memcpy(sortArr_2, sortArr, sizeof(int) * ARR_SIZE);
    printf("insertion sort:\t");
    insertionSort(sortArr_2, count);
    printArr(sortArr_2, count);

    int sortArr_3[ARR_SIZE];
    memcpy(sortArr_3, sortArr, sizeof(int) * ARR_SIZE);
    printf("quiuck sort:\t");
    quick_sort(sortArr_3, 0, count - 1);
    printArr(sortArr_3, count);

    int sortArr_4[ARR_SIZE];
    memcpy(sortArr_4, sortArr, sizeof(int) * ARR_SIZE);
    printf("merge sort:\t");
    merge_sort(sortArr_4, 0, count - 1);
    printArr(sortArr_4, count);

    int sortArr_5[ARR_SIZE];
    memcpy(sortArr_5, sortArr, sizeof(int) * ARR_SIZE);
    printf("heap sort:\t");
    heap_sort(sortArr_5, count);
    printArr(sortArr_5, count);

    int sortArr_6[ARR_SIZE];
    memcpy(sortArr_6, sortArr, sizeof(int) * ARR_SIZE);
    printf("bubble sort:\t");
    bubble_sort(sortArr_6, count);
    printArr(sortArr_6, count);

    int sortArr_7[ARR_SIZE];
    memcpy(sortArr_7, sortArr, sizeof(int) * ARR_SIZE);
    printf("selection sort:\t");
    selection_sort(sortArr_7, count);
    printArr(sortArr_7, count);

    return 0;
}