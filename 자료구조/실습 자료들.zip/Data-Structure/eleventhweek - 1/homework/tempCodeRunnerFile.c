
        int q = partition(list, left, right);