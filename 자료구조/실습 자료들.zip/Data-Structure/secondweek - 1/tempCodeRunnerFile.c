
        N = result;