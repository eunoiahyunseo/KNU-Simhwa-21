#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MALLOC(p, s)                            \
    if (!((p) = malloc(s)))                     \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(1);                                \
    }

int **make2dArray(int rows, int cols)
{
    int **x, i;
    MALLOC(x, rows * sizeof(*x));

    for (i = 0; i < rows; i++)
    {
        MALLOC(*(x + i), cols * sizeof(**x));
    }
    return x;
}

int main(void)
{
    // int **intArr = malloc(sizeof(int *) * 3);
    // for (int i = 0; i < 3; i++)
    // {
    //     *(intArr + i) = malloc(sizeof(int) * 5);
    // }
    // int count = 1;

    // for (int j = 0; j < 3; j++)
    // {
    //     for (int i = 0; i < 5; i++)
    //     {
    //         intArr[j][i] = count;
    //         count++;
    //     }
    // }

    // for (int j = 0; j < 3; j++)
    // {
    //     for (int i = 0; i < 5; i++)
    //     {
    //         printf("%d ", intArr[j][i]);
    //     }
    //     putchar('\n');
    // }

    // int **myArray;
    // myArray = make2dArray(5, 10);
    // myArray[2][4] = 6;

    // printf("%d", myArray[2][4]);

    typedef struct person
    {
        char name[20];
        int age;
    } person, *personPtr;

    personPtr person1, person2;
    person1 = malloc(sizeof(person));
    person2 = malloc(sizeof(person));
    strcpy(person1->name, "hyunseo");
    person1->age = 21;
    printf("%s %d\n", person1->name, person1->age);

    memcpy(person2, person1, sizeof(person));

    printf("%s %d", person2->name, person1->age);
    return 0;
}
