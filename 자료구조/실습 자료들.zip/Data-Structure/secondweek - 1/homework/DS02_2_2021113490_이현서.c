#include <stdio.h>

int Factorial(int number)
{
    if (number <= 1)
    {
        return 1;
    }

    return number * Factorial(number - 1);
}
int main(void)
{
    int N, K, i;
    printf("N, K: ");
    scanf("%d %d", &N, &K);
    int result = 0;

    printf("%d ", N);

    for (i = 0; i < K - 1; i++)
    {
        while (N > 0)
        {
            result += Factorial(N % 10);
            N /= 10;
        }
        printf("%d ", result);
        N = result;
        result = 0;
    }
    return 0;
}
