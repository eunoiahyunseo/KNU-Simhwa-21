#include <stdio.h>

int main(void)
{
    int number, i;
    printf("Number: ");
    scanf("%d", &number);
    int isPrime = 1;

    for (i = 2; i < (number / 2) + 1; i++)
    {
        if (number % i == 0)
        {
            isPrime = 0;
        }
    }

    if (isPrime == 1)
    {
        if (number == 1)
        {
            printf("Not Prime");
        }
        else
        {
            printf("Prime");
        }
    }
    else
    {
        printf("Not Prime");
    }
}