#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_VERTICES 100

typedef struct node_
{
    int vertex;
    struct node_ *link;
} node, *nodePointer;

typedef struct hdnodes
{
    int count;
    nodePointer link;
} hdnodes;

hdnodes graph[MAX_VERTICES];

void topSort(hdnodes graph[], int n)
{
    int i, j, k, top;
    nodePointer ptr;
    top = -1;

    for (i = 0; i < n; i++)
    {
        // graph[i].count의 값이 0이면 predecessor가 없는 것이므로
        // i의 count를 -1로 하고 top의 값을 i로 한다.
        if (!graph[i].count)
        {
            graph[i].count = top;
            top = i;
        }
    }

    for (i = 0; i < n; i++)
    {
        // 만약 top
        if (top == -1)
        {
            fprintf(stderr, "\nNetwork has a cycle. Sort terminated. \n");
            exit(EXIT_FAILURE);
        }
        else
        {
            printf("\n%d %d\n", i, top);
            j = top;
            top = graph[top].count;
            printf("%3d", j);
            for (ptr = graph[i].link; ptr; ptr = ptr->link)
            {
                k = ptr->vertex;
                graph[k].count--;
                if (!graph[k].count)
                {
                    graph[k].count = top;
                    top = k;
                }
            }
        }
    }
}

int main(void)
{
    FILE *fp_read = fopen("input.txt", "r");

    if (fp_read == NULL)
    {
        fprintf(stderr, "File Open Error!");
        exit(EXIT_FAILURE);
    }

    int vertexNum;
    fscanf(fp_read, "%d", &vertexNum);
    int **input = malloc(sizeof(int *) * vertexNum);
    for (int i = 0; i < vertexNum; i++)
        input[i] = malloc(sizeof(int) * vertexNum);

    int num;
    for (int i = 0; i < vertexNum; i++)
        for (int j = 0; j < vertexNum; j++)
            fscanf(fp_read, "%d", &input[i][j]);

    nodePointer tempNode;
    nodePointer tempNode2;

    for (int i = 0; i < vertexNum; i++)
    {
        graph[i].link = NULL;
        for (int j = 0; j < vertexNum; j++)
        {
            if (input[i][j] != 0)
            {
                tempNode = malloc(sizeof(*tempNode));
                tempNode->vertex = j;
                tempNode->link = NULL;

                // 현재 링크에 아무것도 없는 경우
                if (!graph[i].link)
                {
                    graph[i].link = tempNode;
                    tempNode2 = tempNode;
                }
                else
                {
                    tempNode2->link = tempNode;
                    tempNode2 = tempNode;
                }
                graph[j].count++;
            }
        }
    }

    topSort(graph, vertexNum);

    return 0;
}