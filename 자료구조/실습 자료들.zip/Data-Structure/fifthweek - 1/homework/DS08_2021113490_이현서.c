#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_STACK_SIZE 100
#define ERROR_KEY 'x'

#define MALLOC(p, s)                            \
    if (!((p) = malloc(s)))                     \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

#define REALLOC(p, s)                           \
    if (!((p) = realloc(p, s)))                 \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

typedef struct
{
    char key;
} element;

element *stack;
int top = -1;
int capacity = 1;

/**
 *  isp and icp arrays -- index is value of precedence
 */
int isp[] = {0, 19, 12, 12, 13, 13, 13, 0};
int icp[] = {20, 19, 12, 12, 13, 13, 13, 0};
typedef enum
{
    lparen,
    rparen,
    plus,
    minus,
    times,
    divide,
    mod,
    eos,
    operand
} precedence;

precedence conversionInfixNotation[1000] = {0};
char postfixNotation[1000] = {0};

void stackFull()
{
    REALLOC(stack, 2 * capacity * sizeof(*stack));
    capacity *= 2;
}

element stackEmpty()
{
    element errorElement;
    return errorElement;
}

/* add an item to the global stack */
void push(element item)
{
    if (top >= MAX_STACK_SIZE - 1)
        stackFull();

    stack[++top] = item;
}

/* delete and return the top element from the stack */
element pop()
{
    if (top == -1)
        return stackEmpty();
    return stack[top--];
}

element peek()
{
    return stack[top];
}

precedence convert(char input)
{
    switch (input)
    {
    case '(':
        return lparen;
    case ')':
        return rparen;
    case '+':
        return plus;
    case '-':
        return minus;
    case '*':
        return times;
    case '/':
        return divide;
    case '%':
        return mod;
    case '\0':
        return eos;
    default:
        return operand;
    }
}

precedence getToken(char *symbol, int *n)
{
    *symbol = postfixNotation[(*n)++];
    switch (*symbol)
    {
    case '(':
        return lparen;
    case ')':
        return rparen;
    case '+':
        return plus;
    case '-':
        return minus;
    case '/':
        return divide;
    case '*':
        return times;
    case '%':
        return mod;
    case '\0':
        return eos;
    default:
        return operand;
    }
}

int eval(void)
{
    precedence token;
    char symbol;
    int n = 0;
    int op1, op2;
    token = getToken(&symbol, &n);
    while (token != eos)
    {
        if (token == operand)
        {
            element newElement = {symbol};
            push(newElement);
        }
        else
        {
            op2 = pop().key - '0';
            op1 = pop().key - '0';
            element newElement = {0};

            switch (token)
            {
            case plus:
                newElement.key = (op1 + op2) + '0';
                push(newElement);
                break;
            case minus:
                newElement.key = (op1 - op2) + '0';
                push(newElement);
                break;
            case times:
                newElement.key = (op1 * op2) + '0';
                push(newElement);
                break;
            case divide:
                newElement.key = (op1 / op2) + '0';
                push(newElement);
                break;
            case mod:
                newElement.key = (op1 % op2) + '0';
                push(newElement);
                break;
            default:
                break;
            }
        }
        token = getToken(&symbol, &n);
    }
    return pop().key - '0';
}

void convertToPostfixNotation(char *InfixNotation)
{
    int count = 0;
    do
    {
        conversionInfixNotation[count] = convert(InfixNotation[count]);
        count++;
    } while (InfixNotation[count - 1] != NULL);

    precedence token;
    int count2 = 0, i;

    for (i = 0; i < count; i++)
    {
        char token = InfixNotation[i];
        if (convert(token) == operand)
        {
            postfixNotation[count2++] = token;
        }
        else if (convert(token) == 1)
        {
            while (convert(peek().key) != lparen)
            {
                postfixNotation[count2++] = pop().key;
            }
            pop();
        }
        else
        {
            while (!(top == -1) &&
                   isp[convert(peek().key)] >= icp[convert(token)])
            {
                postfixNotation[count2++] = pop().key;
            }
            element newElement = {token};
            push(newElement);
        }
    }

    while (!(top == -1))
    {
        postfixNotation[count2++] = pop().key;
    }
}

int main(void)
{
    // infixNotation을 담을 배열
    char InfixNotation[1000] = {0};

    // file pointer로 infixNotation 받아 들이는 작업
    FILE *fp_read;
    fp_read = fopen("input.txt", "r");
    MALLOC(stack, sizeof(*stack));
    fread(InfixNotation, sizeof(InfixNotation), 1, fp_read);

    // postfix로 변환후 출력
    convertToPostfixNotation(InfixNotation);
    printf("Postfix: %s\n", postfixNotation);

    // 결괏값 출력
    printf("Result: %d", eval());

    fclose(fp_read);
    free(stack);

    return 0;
}