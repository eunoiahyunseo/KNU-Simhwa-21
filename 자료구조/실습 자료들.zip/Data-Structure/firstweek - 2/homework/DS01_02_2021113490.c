#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    int value1, value2;

    printf("First Number: ");
    scanf("%d", &value1);

    printf("Second Number: ");
    scanf("%d", &value2);

    int i;
    int sum1 = 0, sum2 = 0;

    // exclude itself and start with value 1
    for (i = 1; i < value1; i++)
    {
        if (value1 % i == 0)
        {
            sum1 += i;
        }
    }

    for (i = 1; i < value2; i++)
    {
        if (value2 % i == 0)
        {
            sum2 += i;
        }
    }

    if ((sum1 == value2) && (sum2 == value1))
    {
        printf("Amicable");
    }
    else
    {
        printf("Not amicable");
    }

    return 0;
}