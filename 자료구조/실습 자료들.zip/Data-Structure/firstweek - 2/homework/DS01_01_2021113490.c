#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    FILE *fp_read;
    int intArr[100] = {0};
    int count = 0, i;

    char inputFileName[100] = {0};
    scanf("%s", inputFileName);

    if ((fp_read = fopen("input.txt", "r")) == NULL)
    {
        printf("error occured in opening the file");
    }

    while (fscanf(fp_read, "%d", intArr + count) != EOF)
    {
        count++;
    }
    fclose(fp_read);

    int minValue, maxValue;

    // find the min value
    minValue = intArr[0];
    maxValue = intArr[0];

    for (i = 1; i < count; i++)
    {
        if (intArr[i] < minValue)
        {
            minValue = intArr[i];
        }
        if (intArr[i] > maxValue)
        {
            maxValue = intArr[i];
        }
    }
    printf("MIN: %d\n", minValue);
    printf("MAX: %d\n", maxValue);

    return 0;
}