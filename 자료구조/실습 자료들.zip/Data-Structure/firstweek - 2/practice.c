#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    int count = 0, input;
    int targetArr[100] = {0};
    while (1)
    {
        scanf("%d", &input);
        if (input == -1)
        {
            break;
        }
        else
        {
            targetArr[count] = input;
            count++;
        }
    }

    typedef enum boolean_
    {
        false,
        true,
    } boolean;
    int i, j;
    int *targetArr_v1;

    targetArr_v1 = malloc(sizeof(int) * count);
    for (i = 0; i < count; i++)
    {
        targetArr_v1[i] = targetArr[i];
    }

    boolean swap;

    // bubble sort
    for (i = 0; i < count - 1; i++)
    {
        swap = false;
        for (j = 0; j < count - 1 - i; j++)
        {
            if (targetArr_v1[j] > targetArr_v1[j + 1])
            {
                int temp;
                temp = targetArr_v1[j];
                targetArr_v1[j] = targetArr_v1[j + 1];
                targetArr_v1[j + 1] = temp;
                swap = true;
            }
        }
        if (swap == false)
        {
            break;
        }
    }

    for (i = 0; i < count; i++)
    {
        printf("%d ", targetArr_v1[i]);
    }

    putchar('\n');

    free(targetArr_v1);

    // selection sort
    int *targetArr_v2;
    targetArr_v2 = malloc(sizeof(int) * count);

    for (i = 0; i < count; i++)
    {
        targetArr_v2[i] = targetArr[i];
    }

    int lowest;
    for (i = 0; i < count - 1; i++)
    {
        lowest = i;
        for (j = i + 1; j < count; j++)
        {
            if (targetArr_v2[j] < targetArr_v2[lowest])
            {
                lowest = j;
            }
        }

        int temp;
        temp = targetArr_v2[lowest];
        targetArr_v2[lowest] = targetArr_v2[i];
        targetArr_v2[i] = temp;
    }

    for (i = 0; i < count; i++)
    {
        printf("%d ", targetArr_v2[i]);
    }

    free(targetArr_v2);

    putchar('\n');

    // insertion sort
    int *targetArr_v3;
    targetArr_v3 = malloc(sizeof(int) * count);

    for (i = 0; i < count; i++)
    {
        targetArr_v3[i] = targetArr[i];
    }

    for (i = 1; i < count; i++)
    {
        for (j = i; j >= 1; j--)
        {
            if (targetArr_v3[j] < targetArr_v3[j - 1])
            {
                int temp;
                temp = targetArr_v3[j];
                targetArr_v3[j] = targetArr_v3[j - 1];
                targetArr_v3[j - 1] = temp;
            }
            else
            {
                break;
            }
        }
    }

    for (i = 0; i < count; i++)
    {
        printf("%d ", targetArr_v3[i]);
    }

    free(targetArr_v3);

    return 0;
}