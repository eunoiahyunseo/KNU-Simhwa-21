#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ARR_SIZE 100

int sorted[ARR_SIZE] = {0};

void swap(int *value1, int *value2)
{
    int temp;
    temp = *value1;
    *value1 = *value2;
    *value2 = temp;
}

void printArr(int a[], int count)
{
    for (int i = 0; i < count; i++)
        printf(" %d  ", a[i]);

    printf("\n");
}

// insertion sort
void insertionSort2(int a[], int n)
{
    int j, key, i;
    for (i = 1; i < n; i++)
    {
        key = a[i];

        for (j = i - 1; j >= 0 && a[j] > key; j--)
            a[j + 1] = a[j];

        // 위 과정이 끝나면 j에다가 key값을 집어 넣어야 한다.
        a[j + 1] = key;
    }
}

int partition(int list[], int left, int right)
{
    int pivot;
    int low, high;

    low = left;
    high = right + 1;
    pivot = list[left];

    // 일단 low가 high보다 작을때 동안만 진행한다.
    do
    {
        do
        {
            low++;
        } while (list[low] < pivot && low <= right);

        do
        {
            high--;
        } while (list[high] > pivot && high >= left);

        // 애초에 low >= high인 것은 바꾸면 안된다. 이는 do while문을 끝내고 처리해준다.
        if (low < high)
            swap(list + low, list + high);
    } while (low < high);

    // 그리고 맨 마지막으로는 list[high]와 list[left]값을 바꾸어야 한다.
    swap(list + left, list + high);
    return high;
}

void quicksort(int list[], int left, int right)
{
    if (left < right)
    {
        // 다음 피벗 위치를 정해주어야 한다.
        int q = partition(list, left, right);
        quicksort(list, left, q - 1);
        quicksort(list, q + 1, right);
    }
    else
    {
        return;
    }
}

void merge(int list[], int left, int mid, int right)
{
    int i, j, k, l;
    i = left;
    j = mid + 1;
    k = left;

    // 분할 정렬된 list의 합병
    while (i <= mid && j <= right)
    {
        if (list[i] <= list[j])
            sorted[k++] = list[i++];
        else
            sorted[k++] = list[j++];
    }

    // 남아 있는 값들을 일괄 복사
    if (i > mid)
    {
        // ㅓ를 추가적으로 남아있는 값들을 복사해 와야 한다.
        for (; j <= right;)
            sorted[k++] = list[j++];
    }
    else
    {
        for (; i <= mid;)
            sorted[k++] = list[i++];
    }

    // 마지막으로 sort배열에 있는 값들을 원래 배열에 복사해와야 한다.
    for (l = left; l <= right; l++)
        list[l] = sorted[l];
}

void mergesort_(int list[], int left, int right)
{
    int mid;
    if (left < right)
    {
        mid = (left + right) / 2;
        mergesort_(list, left, mid);
        mergesort_(list, mid + 1, right);
        merge(list, left, mid, right);
    }
}

void adjust(int list[], int root, int n)
{
    /* adjust the binary tree dto establish the heap */
    int child, rootkey;
    int temp;
    // 가장 위에 해당하는 노드
    rootkey = list[root];
    child = 2 * root;
    while (child <= n)
    {
        if ((child < n) && (list[child] < list[child + 1]))
            child++;

        if (rootkey > list[child])
            break;
        else
        {
            list[child / 2] = list[child];
            child *= 2;
        }
    }
    list[child / 2] = rootkey;
}

void heapSort(int list[], int n)
{
    // perform a heap sort on a[1:n]
    int i, j;
    int temp;
    for (i = n / 2; i >= 0; i--)
        adjust(list, i, n);

    // 여기서는 맨
    // for (i = n - 2; i >= 0; i--)
    // {
    //     printf("asdf");
    //     swap(list, list + i + 1);
    //     adjust(list, 0, i);
    // }
}

int main(void)
{
    int sortArr[ARR_SIZE], count = 0;
    memset(sortArr, 0, sizeof(int) * ARR_SIZE);

    FILE *fp_read = fopen("sort.txt", "r");

    // sortArr + count가 EOF라면 count를 늘려주면 안된다.
    while ((fscanf(fp_read, "%d", sortArr + count) != EOF))
    {
        count++;
    }

    printf("original array: ");
    printArr(sortArr, count);

    int sortArr_2[ARR_SIZE];
    memcpy(sortArr_2, sortArr, sizeof(int) * ARR_SIZE);

    printf("insertionsort: ");
    insertionSort2(sortArr_2, count);
    printArr(sortArr_2, count);

    int sortArr_3[ARR_SIZE];
    memcpy(sortArr_3, sortArr, sizeof(int) * ARR_SIZE);
    printf("quicksort: ");
    quicksort(sortArr_3, 0, count - 1);
    printArr(sortArr_3, count);

    int sortArr_4[ARR_SIZE];
    memcpy(sortArr_4, sortArr, sizeof(int) * ARR_SIZE);
    printf("mergesort: ");
    mergesort_(sortArr_4, 0, count - 1);
    printArr(sortArr_4, count);

    int sortArr_5[ARR_SIZE];
    memcpy(sortArr_5, sortArr, sizeof(int) * ARR_SIZE);
    printf("heapsort: ");
    heapSort(sortArr_5, count - 1);
    printArr(sortArr_5, count);

    return 0;
}