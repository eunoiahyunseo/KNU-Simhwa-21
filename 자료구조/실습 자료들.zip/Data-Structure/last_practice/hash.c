#include <stdio.h>
#include <stdlib.h>

int hashFunction(int key, int tableSize)
{
    return key % tableSize;
}

void structHashTable(int key, int tableSize, int *hashTable)
{
    int hashValue = hashFunction(key, tableSize);
    for (; hashTable[hashValue]; hashValue++)
        ;
    hashTable[hashValue] = key;
}

int *search(int key, int tableSize, int *hashTable)
{
    int homeBucket, currentBucket;
    homeBucket = hashFunction(key, tableSize);

    for (currentBucket = homeBucket; hashTable[currentBucket] && hashTable[currentBucket] != key;)
    {
        currentBucket = (currentBucket + 1) % tableSize;
        if (currentBucket == homeBucket)
            return NULL;
    }

    if (hashTable[currentBucket] == key)
        return hashTable + currentBucket;

    return NULL;
}

int main(void)
{
    FILE *fp_read = fopen("hash.txt", "r");
    int dataNum, tableSize;
    int *hashTable;

    if (fp_read == NULL)
    {
        fprintf(stderr, "File Open Error!");
        exit(EXIT_FAILURE);
    }

    int SearchNum;
    fscanf(fp_read, "%d", &tableSize);
    fscanf(fp_read, "%d", &dataNum);
    fscanf(fp_read, "%d", &SearchNum);

    hashTable = (int *)(malloc(sizeof(int) * tableSize));

    int temp;
    for (int i = 0; i < dataNum; i++)
    {
        fscanf(fp_read, "%d", &temp);
        structHashTable(temp, tableSize, hashTable);
    }

    printf("Hash Table: \n");
    for (int i = 0; i < tableSize; i++)
    {
        if (hashTable[i] == 0)
        {
            printf("%d: \n", i);
        }
        else
        {
            printf("%d: %d\n", i, hashTable[i]);
        }
    }

    int searchNum;
    printf("Search: \n");

    for (int i = 0; i < SearchNum; i++)
    {
        fscanf(fp_read, "%d", &searchNum);
        search(searchNum, tableSize, hashTable) != NULL ? printf("S") : printf("F");
    }

    return 0;
}