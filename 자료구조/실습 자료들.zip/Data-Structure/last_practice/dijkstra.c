#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#define INFINITE (INT_MAX) / (3)
#define true 1
#define false 0

// 해당 정점에서의 최적화를 진행했는지 확인
short int *found;

// 해당 정점 부터의 거리를 최적화 하기 위한 배열
int *distance;
int vertexNum, startEdge;

int selectMinVertex()
{
    int min = INFINITE, minPos = -1;
    for (int i = 0; i < vertexNum; i++)
    {
        if ((min > distance[i]) && !found[i])
        {
            min = distance[i], minPos = i;
        }
    }
    return minPos;
}

void shortestPath(int startEdge, int **cost)
{
    int nextVertex;
    // 여기에서 disatnce에서 각 정점마다의 최적의 경로를 계산해야 합니다.
    for (int i = 0; i < vertexNum; i++)
    {
        found[i] = false;
        distance[i] = cost[startEdge][i];
    }

    found[startEdge] = true;
    // cost에서 startEdge의 시작은 0으로 초기화한다.
    distance[startEdge] = 0;

    for (int j = 0; j < vertexNum - 1; j++)
    {
        nextVertex = selectMinVertex();

        // nextVertex에 대해서 최적화를 진행해 주어야 합니다.
        found[nextVertex] = true;

        for (int i = 0; i < vertexNum; i++)
            if (cost[nextVertex][i] + distance[nextVertex] < distance[i])
                distance[i] = distance[nextVertex] + cost[nextVertex][i];
    }
}

int main(void)
{
    FILE *fp_read = fopen("dijkstra.txt", "r");

    if (fp_read == NULL)
    {
        fprintf(stderr, "File Open Error!");
        exit(EXIT_FAILURE);
    }

    fscanf(fp_read, "%d", &vertexNum);
    fscanf(fp_read, "%d", &startEdge);

    int **cost = malloc(sizeof(int *) * vertexNum);
    for (int i = 0; i < vertexNum; i++)
        cost[i] = malloc(sizeof(int) * vertexNum);

    int temp;
    for (int i = 0; i < vertexNum; i++)
    {
        for (int j = 0; j < vertexNum; j++)
        {
            fscanf(fp_read, "%d", &temp);
            if (temp != 0)
                cost[i][j] = temp;
            else
            {
                // 못 가는 경우는 무한대로 초기화해서 합칠 떄 제한을 걸어놓자.
                cost[i][j] = INFINITE;
            }
        }
    }

    found = malloc(sizeof(short int) * vertexNum);
    distance = malloc(sizeof(int) * vertexNum);

    shortestPath(startEdge, cost);

    for (int i = 0; i < vertexNum; i++)
    {
        printf(" %d ", distance[i]);
    }

    return 0;
}