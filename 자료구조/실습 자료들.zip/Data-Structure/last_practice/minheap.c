#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ELEMENTS 200

#define true 1
#define false 0

typedef struct element_
{
    int key;
} element;
// heap은 0번쨰 인덱스는 사용하지 않고 1번부터 진행된다.
element heap[MAX_ELEMENTS];

int HEAP_FULL(int n)
{
    if (n == MAX_ELEMENTS - 1)
        return true;

    return false;
}

int HEAP_EMPTY(int n)
{
    if (n == 0)
        return true;

    return false;
}

void stackCheck(int stack[])
{
    int i = 0;
    printf("\nstack check >> ");
    while (stack[i] != 0)
    {
        printf("%d ", stack[i++]);
    }
    putchar('\n');
}
// array representation으로 되어 있는 heap을 중위 순회하기 위한 함수
void iterInorder(element heap[], int size)
{
    int stack[MAX_ELEMENTS];
    memset(stack, 0, sizeof(int) * MAX_ELEMENTS);
    int top = -1;
    int i = 1;

    while (true)
    {
        // stack에 왼쪽으로 파고 들어서 싹다 집어 넣는다.
        while (i <= size)
        {
            stack[++top] = i;
            i = i * 2;
        }
        // stackCheck(stack);
        if (top == -1)
            break;

        // stack에서 하나씩 꺼내면서
        i = stack[top--];
        printf("%d ", heap[i].key);
        i = i * 2 + 1;
    }
}

// n은 어디 부분에서부터 삽입할 것인지를 나타내준다.
// bubble up process
void push(element item, int *n)
{
    int i;
    // 먼저 힙이 꽉 찼으면 안된다.
    if (HEAP_FULL(*n))
    {
        fprintf(stderr, "The heap is full. \n");
        exit(EXIT_FAILURE);
    }

    // i는 삽입할 위치를 가리킨다.
    i = ++(*n);

    // i가 1이면 끝내야 하고, 삽입하고자 하는 키가 위쪽 키보다 큰 동안만 수행되어야 합니다.
    // 작거나 i가 1이게 되면 바로 그 자리에서 중단
    while ((i != 1) && item.key < heap[i / 2].key)
    {
        heap[i] = heap[i / 2];
        i /= 2;
    }
    heap[i] = item;
}

// trickle down process
element pop(int *n)
{
    // pop을 하기 위해서는 일단 하나늘 뺴고, 가장 아래걸ㄹ 맨 위로 올린다음에 아래로 내려가면서
    // 비교해 나가야 한다.
    if (HEAP_EMPTY(*n))
    {
        fprintf(stderr, "The heap is empty. \n");
        exit(EXIT_FAILURE);
    }

    element item, temp;
    // tricle down을 하기 위해 가장 위랑, 맨 마지막을 저장해 준다.
    item = heap[1];
    temp = heap[(*n)--];

    int parent, child;
    parent = 1;
    child = 2;

    // 기본적으로 child가 *n을 넘어가면 안된다.
    while (child <= *n)
    {
        // 만약 child + 1이 없으면 어쩔 것인가.
        if ((child < *n) && heap[child].key > heap[child + 1].key)
            child++;

        if (temp.key <= heap[child].key)
            break;

        heap[parent] = heap[child];
        parent = child;
        child *= 2;
    }

    // 다 마치고 나면
    heap[parent] = temp;
    return item;
}

void printLI(int n)
{
    printf("Level Order: ");
    for (int i = 1; i <= n; i++)
        printf("%d ", heap[i].key);

    putchar('\n');

    printf("Inorder Order: ");
    iterInorder(heap, n);
    putchar('\n');
}

int main(void)
{
    FILE *fp_read = fopen("heap.txt", "r");
    int value, n = 0;
    element newElement = {0};
    while ((fscanf(fp_read, "%d", &value) != EOF))
    {
        newElement.key = value;
        // TODO: newElement를 활용하여 heap에 하나씩 삽입해야 한다 (array representation된)
        push(newElement, &n);
    };

    for (int i = 1; i <= n; i++)
    {
        printf("%d => ", heap[i].key);
    }
    putchar('\n');
    printLI(n);
    pop(&n);
    printLI(n);
    return 0;
}