#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SIZE 100
#define INF 100000

int Check[MAX_SIZE][MAX_SIZE] = {0};
int count;

void smallWeight(int size, int **Weight, int *count)
{
    // checker에 정렬한 간선은 음수로 지정한다.
    int small = INF, row, col;
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            if ((small > Check[i][j]) && Check[i][j] > 0)
            {
                small = Check[i][j];
                row = i, col = j;
            }
        }
    }

    // 최종적으로 -1으로 초기화 해 줘야 한다. 그래야 다음에 -1뭐 나오면 재끼고 시작할 수 있으니까
    Check[row][col] = -1;
    Weight[0][*count] = row, Weight[1][(*count)++] = col;
}

int main(void)
{
    FILE *fp_read = fopen("kruskal.txt", "r");
    if (fp_read == NULL)
    {
        fprintf(stderr, "File Open Error!");
        exit(EXIT_FAILURE);
    }

    int count;
    fscanf(fp_read, "%d", &count);

    int Graph[count][count];
    memset(Graph, 0, sizeof(int) * count * count);

    int temp, EdgeCount = 0;

    // 모든 간선들을 체크 하고 갯수를 저장해 줘야 한다.
    for (int i = 0; i < count; i++)
    {
        for (int j = 0; j < count; j++)
        {
            fscanf(fp_read, "%d", &temp);
            if (temp != 0 && j > i)
            {
                EdgeCount++;
                Graph[i][j] = temp;
            }
        }
    }

    for (int i = 0; i < count; i++)
    {
        for (int j = 0; j < count; j++)
        {
            Check[i][j] = Graph[i][j];
        }
    }

    // for (int i = 0; i < count; i++)
    // {
    //     for (int j = 0; j < count; j++)
    //         printf("%d ", Check[i][j]);
    //     printf("\n");
    // }

    int **Weight = malloc(sizeof(int *) * 2);
    for (int i = 0; i < 2; i++)
        Weight[i] = malloc(sizeof(int) * EdgeCount);

    int iterCount = 0, LinearCounter = 0;

    // 이제 위에서 정의한 2차원 배열에 가중치 값이 작은 순서대로 채워나갸야 한다.
    for (int i = 0; i < EdgeCount; i++)
        smallWeight(count, Weight, &LinearCounter);

    // for (int i = 0; i < EdgeCount; i++)
    // {
    //     printf("%d %d\n", Weight[0][i], Weight[1][i]);
    // }

    int *s = malloc(sizeof(int) * count);
    for (int i = 0; i < count; i++)
    {
        s[i] = i;
    }

    // 그리고 선택된 간선을 기억하기 위한 2차원 배열을 만들어 주어야 합니다.
    int **ReM = malloc(sizeof(int) * count);
    for (int i = 0; i < 2; i++)
    {
        ReM[i] = malloc(sizeof(int) * count);
    }

    // kruskal 알고리즘을 위한 초기작업
    int totalCost = 0;
    int edgeCount = 0;
    int v1, v2;
    int s1, s2;
    int i = 0;

    // 만약 정점이 v개라면 v - 1개의 간선이 그려지면 종료해야 한다.
    while (edgeCount != (count - 1))
    {
        v1 = Weight[0][i], v2 = Weight[1][i];
        s1 = s[v1], s2 = s[v2];

        // 아예 같은 경우는 순환이 생기는 구조니까 하면 안된다.
        if (s1 != s2)
        {
            for (int j = 0; j < count; j++)
            {
                if (s[j] == s2)
                {
                    s[j] = s1;
                }
            }

            ReM[0][edgeCount] = v1;
            ReM[1][edgeCount++] = v2;
            totalCost += Graph[v1][v2];
        }
        i++;
    }

    printf("Selected Edges: ");
    for (int k = 0; k < count - 1; k++)
    {
        if (k == count - 2)
        {
            printf("(%d, %d)", ReM[0][k], ReM[1][k]);
        }
        else
        {
            printf("(%d, %d), ", ReM[0][k], ReM[1][k]);
        }
    }
    printf("\nCost: %d\n", totalCost);
    fclose(fp_read);

    return 0;
}