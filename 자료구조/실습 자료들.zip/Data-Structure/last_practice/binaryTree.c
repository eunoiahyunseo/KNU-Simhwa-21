#include <stdio.h>
#include <stdlib.h>

typedef struct node_
{
    int key;
    struct node_ *leftChild;
    struct node_ *rightChild;
} node, *treePointer;

treePointer iterSearch(treePointer tree, int k)
{
    // while문으로 반복해서 값을 찾아야 한다.

    while (tree)
    {
        if (k == tree->key)
            return tree;

        if (k < tree->key)
            tree = tree->leftChild;
        else
            tree = tree->rightChild;
    }

    // 만약 값이 없었다면 그냥 NULl을 리턴해서 값이 없음을 명시해 주어야 한다.
    return NULL;
}

treePointer modifiedSdearch(treePointer tree, int key)
{
    // 만약 tree가 없다면 NULL을 리턴해야 한다
    if (!tree)
        return NULL;

    while (tree)
    {
        // 만약 tree의 key가 삽입하고자 하는 키와 같다면 NULL을 리턴해야 한다.
        if (key == tree->key)
            return NULL;

        // 만약 트리의 key가 삽입하고자 하는 key보다 작으면 왼쪽으로 가면 된다.
        if (tree->key > key)
        {
            if (tree->leftChild == NULL)
                return tree;

            tree = tree->leftChild;
        }
        // 만약 더 크다면 오른쪽으로 가면 된다.
        else
        {
            if (tree->rightChild == NULL)
                return tree;

            tree = tree->rightChild;
        }
    }

    return NULL;
}

void initNode(treePointer *tree, int key)
{
    *tree = (treePointer)malloc(sizeof(node));
    (*tree)->key = key;
    (*tree)->leftChild = (*tree)->rightChild = NULL;
}

void insert(treePointer *node, int k)
{
    treePointer ptr;
    // 삽입할 노드의 바로 위를 반환해 주는 함수이다.
    // 그리고 tree가 만약에 null이라면 아예 없는 거니까 그냥 할당을 해야하는데 이 떄는 null
    // 을 반환하게 하면 된다.
    treePointer temp = modifiedSdearch(*node, k);

    // node가 null이거나 temp가 null이 아닌 경우에
    if (temp || !(*node))
    {
        initNode(&ptr, k);

        // 노드가 있는 경우는 그냥 k가 temp->key보다 작으면 왼쪽으로
        // 크면 오른쪽으로 가게 하면 된다.
        if (*node)
        {
            if (k < temp->key)
                temp->leftChild = ptr;
            else
                temp->rightChild = ptr;
        }
        else
        {
            // 만약에 그냥 노드가 원래 아무것도 없었다면 그 노드에 할당해주어야 한다.
            *node = ptr;
        }
    }
}

void inorder(treePointer ptr)
{
    if (ptr)
    {
        inorder(ptr->leftChild);
        printf(" %d ", ptr->key);
        inorder(ptr->rightChild);
    }
    else
    {
        return;
    }
}

void preorder(treePointer ptr)
{
    if (ptr)
    {
        printf(" %d ", ptr->key);
        inorder(ptr->leftChild);
        inorder(ptr->rightChild);
    }
    else
    {
        return;
    }
}

void postorder(treePointer ptr)
{
    if (ptr)
    {
        inorder(ptr->leftChild);
        inorder(ptr->rightChild);
        printf(" %d ", ptr->key);
    }
    else
    {
        return;
    }
}

void printTree(treePointer head)
{
    printf("Preorder: ");
    preorder(head);
    printf("\n");

    printf("Inorder: ");
    inorder(head);
    printf("\n");

    printf("PostOrder: ");
    postorder(head);
    printf("\n");
}

int main(void)
{
    FILE *fp = fopen("binaryTree1.txt", "r");
    FILE *fsearch = fopen("binaryTree2.txt", "r");

    treePointer head = NULL;

    int key;
    while (fscanf(fp, "%d", &key) != EOF)
    {
        // BST에 입력받은 key를 집어 넣어 주어야 한다.
        insert(&head, key);
    }

    printTree(head);

    int find;
    while (fscanf(fsearch, "%d", &find) != EOF)
    {
        if (iterSearch(head, find))
            printf(" 1 ");
        else
            printf(" 0 ");
    }

    fclose(fp);
    fclose(fsearch);

    return 0;
}