 // while (edgeCount != (count - 1))
    // {
    //     v1 = Weight[0][i], v2 = Weight[1][i];
    //     s1 = s[v1], s2 = s[v2];

    //     // 이에 같은 경우는 순환이 생기는 구조니까 하면 안된다
    //     if (s1 != s2)
    //     {
    //         for (int j = 0; j < count; j++)
    //         {
    //             if (s[j] == s2)
    //             {
    //                 s[j] = s1;
    //             }
    //         }

    //         ReM[0][edgeCount] = v1;
    //         ReM[1][EdgeCount++] = v2;
    //         totalCost += Graph[v1][v2];
    //     }
    //     i++;
    // }