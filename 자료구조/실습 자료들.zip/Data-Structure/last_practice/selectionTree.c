#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LENGTH 100

#define true 1
#define false 0

// winner tree재구성 하는 과정에서 '승자를 값을 저장하기 위한 변수
int winner;

void levelOrder(int *arr, int size)
{
    printf("Level Order: ");
    for (int i = 1; i < size + 1; i++)
    {
        printf(" %d ", arr[i]);
    }
    printf("\n");
}

void iterInorder(int *arr, int size)
{
    printf("Inorder: ");
    int stack[size];
    memset(stack, 0, sizeof(int) * size);
    int i = 1, top = -1;
    while (1)
    {
        while (i <= size)
        {
            stack[++top] = i;
            i *= 2;
        }

        if (top == -1)
            break;

        i = stack[top--];
        printf(" %d ", arr[i]);
        i = i * 2 + 1;
    }
}

int CalcNode(int runCount)
{
    int size = 0, temp = runCount;
    while (temp > 0)
    {
        size = size + temp;
        temp /= 2;
    }
    return size;
}

int findRun(int *arr, int size, int arrSize, int winner)
{
    for (int i = size; i < arrSize + 1; i++)
        if (arr[i] == winner)
            return i;
}

// winnerTree를 구성하는 코드를 짜야 한다.
void winnerTree(int *arr, int size, int arrSize)
{
    int temp = size, tempArrSize = arrSize, i;
    while (temp != 1)
    {
        // 8 ~ 15의 인덱스 값으로 4 ~ 7의 값을 재구성해야 한다.
        for (i = temp; i <= tempArrSize; i = i + 2)
        {
            if (arr[i] >= arr[i + 1])
                arr[i / 2] = arr[i + 1];
            else
                arr[i / 2] = arr[i];
        }
        temp /= 2, tempArrSize /= 2;
    }
    winner = arr[1];
    printf("Winner: %d", winner);
    printf("\n");
}

int main(void)
{
    FILE *fp = fopen("selectionTree.txt", "r");

    if (fp == NULL)
    {
        fprintf(stderr, "File Open Error!");
        exit(EXIT_FAILURE);
    }

    int runCount;
    fscanf(fp, "%d", &runCount);

    int **runArr = malloc(sizeof(int *) * runCount);
    for (int i = 0; i < runCount; i++)
    {
        runArr[i] = malloc(sizeof(int) * MAX_LENGTH);
        memset(runArr[i], 0, MAX_LENGTH);
    }

    int temp, count;

    for (int i = 0; i < runCount; i++)
    {
        count = 0, temp = 0;
        while (true)
        {
            fscanf(fp, "%d", &temp);
            if (temp == -1)
                break;

            runArr[i][count++] = temp;
            // printf("%d ", runArr[i][count - 1]);
        }
        // printf("\n");
    }

    int Arrsize = CalcNode(runCount);
    int *selectionTree = malloc(sizeof(int) * (Arrsize + 1));
    memset(selectionTree, 0, sizeof(int) * (Arrsize + 1));

    int level = 0;
    for (int i = 0; i < runCount; i++)
        selectionTree[runCount + i] = runArr[i][level];

    // 트리를 재구성한다.
    winnerTree(selectionTree, runCount, Arrsize);
    levelOrder(selectionTree, Arrsize);
    iterInorder(selectionTree, Arrsize);

    int run;
    run = findRun(selectionTree, runCount, Arrsize, winner);
    selectionTree[run] = runArr[run - runCount][++level];

    putchar('\n');

    winnerTree(selectionTree, runCount, Arrsize);
    levelOrder(selectionTree, Arrsize);
    iterInorder(selectionTree, Arrsize);

    return 0;
}