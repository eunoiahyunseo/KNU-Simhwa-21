#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_VERTEX 100
#define true 1
#define false 0

typedef struct node_
{
    int vertex;
    struct node_ *link;
} node, *nodePointer;

// queue를 위해 front와 rear를 선언해주어야 합니다.
nodePointer front, rear;

// adjacent list
nodePointer adjList[MAX_VERTEX];
short int visited[MAX_VERTEX];

void initNode(nodePointer *node, int vertex)
{
    *node = malloc(sizeof(nodePointer));
    (*node)->vertex = vertex;
    (*node)->link = NULL;
}

/**
 * @brief DFS를 시작 노드 v부터 시작한다.
 *
 */
void dfs(int v)
{
    nodePointer w;
    visited[v] = true;
    printf(" %d ", v);
    w = adjList[v];
    while (w != NULL)
    {
        // 방문하지 않았을 때만 dfs과정을 진행해 주는 것이 좋아
        if (!visited[w->vertex])
            dfs(w->vertex);

        w = w->link;
    }
}

void addq(int item)
{
    nodePointer temp;
    initNode(&temp, item);

    if (!rear || !front)
    {
        front = rear = temp;
    }
    else
    {
        rear->link = temp;
        rear = rear->link;
    }
}

int deleteq()
{
    int temp = front->vertex;
    front = front->link;
    return temp;
}

// bfs는 dfs와는 다르게 큐를 이용하여야 한다.
void bfs(int v)
{
    nodePointer w;
    front = rear = NULL;
    printf(" %d ", v);
    visited[v] = true;
    addq(v);
    // while (front != NULL)
    // {
    //     v = deleteq();
    //     w = adjList[v];
    //     while (w != NULL)
    //     {
    //         if (!visited[w->vertex])
    //         {
    //             printf(" %d ", w->vertex);
    //             addq(w->vertex);
    //             visited[w->vertex] = true;
    //         }

    //         w = w->link;
    //     }
    // }
    while (front != NULL)
    {
        v = deleteq();
        w = adjList[v];
        while (w != NULL)
        {
            if (!visited[w->vertex])
            {
                printf(" %d ", w->vertex);
                addq(w->vertex);
                visited[w->vertex] = true;
            }
            w = w->link;
        }
    }
}

int main(void)
{
    FILE *fp_read = fopen("DFSBFS.txt", "r");

    if (fp_read == NULL)
    {
        fprintf(stderr, "File Open Error!");
        exit(EXIT_FAILURE);
    }

    int vertCount, data, check = false;
    fscanf(fp_read, "%d", &vertCount);
    // tempNode는 가장 뒤를 가리키게 하는 변수
    nodePointer newNode, tempNode;

    // adjacent list를 구현해야 한다.
    for (int i = 0; i < vertCount; i++)
    {
        check = false;
        for (int j = 0; j < vertCount; j++)
        {
            fscanf(fp_read, "%d", &data);
            if (data == 1)
            {
                // data가 있는 곳이라면
                initNode(&newNode, j);

                if (check == false)
                {
                    // 일단 처음에 아무것도 안들어가 있다면
                    adjList[i] = newNode;
                    tempNode = newNode;
                    check = true;
                }
                else
                {
                    tempNode->link = newNode;
                    tempNode = newNode;
                }
            }
        }
    }

    for (int i = 0; i < vertCount; i++)
    {
        printf("Vertex %d: ", i);
        tempNode = adjList[i];
        while (tempNode)
        {
            printf(" %d ", tempNode->vertex);
            tempNode = tempNode->link;
        }
        printf("\n");
    }

    printf("DFS: ");
    dfs(0);
    printf("\n");

    memset(visited, 0, sizeof(short int) * MAX_VERTEX);

    printf("BFS: ");
    bfs(0);
    printf("\n");

    return 0;
}