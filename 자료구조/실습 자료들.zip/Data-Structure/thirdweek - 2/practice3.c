#include <stdio.h>

#define MAX_QUEUE_SIZE 100
#define ERROR_INT -10000000

typedef struct
{
    int key;
} element;

element queue[MAX_QUEUE_SIZE];
int rear = -1;
int front = -1;

void addq(element);
element deleteq();
void queueFull();
element queueEmpty();

int main(void)
{

    return 0;
}

void queueFull()
{
    fprintf(stderr, "Queue is full, cannot add element");
}

element queueEmpty()
{
    element errorElement = {ERROR_INT};

    return errorElement;
}

void addq(element item)
{
    if (rear == MAX_QUEUE_SIZE - 1)
    {
        queueFull();
    }
    queue[++rear] = item;
}

element deleteq()
{
    if (front == rear)
    {
        return queueEmpty();
    }
}
