#include <stdio.h>

#define MAX_STACK_SIZE 100
#define ERROR_INT -10000000

typedef struct
{
    int key;
} element;

element stack[MAX_STACK_SIZE];
int top = -1;

void push(element);
void stackFull();
element stackEmpty();
element pop();

int main(void)
{
    element newElement;

    newElement.key = 4;
    push(newElement);
    newElement.key = 3;
    push(newElement);

    while (1)
    {
        element popElement = pop();
        if (popElement.key == ERROR_INT)
        {
            break;
        }
        else
        {
            printf("%d가(이) 튀어나왔습니다!!\n", popElement.key);
        }
    }

    return 0;
}

void push(element item)
{
    if (top >= MAX_STACK_SIZE - 1)
    {
        stackFull();
    }
    stack[++top] = item;
}

void stackFull()
{
    fprintf(stderr, "Stack is full, cannot add element");
}

element stackEmpty()
{
    element errorElement;
    errorElement.key = ERROR_INT;
    return errorElement;
}

element pop()
{
    if (top == -1)
    {
        return stackEmpty();
    }

    return stack[top--];
}