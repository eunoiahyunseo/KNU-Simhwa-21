#include <stdio.h>
#include <stdlib.h>

#define MAX_TERMS 1001

typedef struct
{
    float coef;
    int expon;
} polynomial;

polynomial terms[MAX_TERMS];
int avail = 0;

int COMPARE(int LeadExpOfValue1, int LeadExpOfValue2)
{
    if (LeadExpOfValue1 > LeadExpOfValue2)
        return 1;
    else if (LeadExpOfValue1 == LeadExpOfValue2)
        return 0;
    else
        return -1;
}

void attach(float coefficient, int exponent)
{
    if (avail >= MAX_TERMS)
    {
        fprintf(stderr, "Too many terms int the polynomial\n");
        exit(1);
    }
    terms[avail].coef = coefficient;
    terms[avail++].expon = exponent;
}
void padd(int startA, int finishA, int startB, int finishB, int *startD, int *finishD)
{
    /* add A(x) and B(x) to obtain D(x) */
    float coefficient;
    avail = finishB + 1;
    *startD = avail;

    while (startA <= finishA && startB <= finishB)
    {
        switch (COMPARE(terms[startA].expon, terms[startB].expon))
        {
        case -1:
            /* a expon < b expon */
            attach(terms[startB].coef, terms[startB].expon);
            startB++;
            break;
        case 0:
            /* equl exponents */
            coefficient = terms[startA].coef + terms[startB].coef;
            if (coefficient)
                attach(coefficient, terms[startA].expon);
            startA++;
            startB++;
            break;
        case 1:
            /* a expon > b expon */
            attach(terms[startA].coef, terms[startA].expon);
            startA++;
            break;
        }
    }

    for (; startA <= finishA; startA++)
    {
        attach(terms[startA].coef, terms[startA].expon);
    }

    for (; startB <= finishB; startB++)
    {
        attach(terms[startB].coef, terms[startB].expon);
    }
    *finishD = avail - 1;
}

int main(void)
{
    FILE *fp_read;
    fp_read = fopen("a.txt", "r");
    int aNumber, i = 0, aExpon, count = 0, startA, finishA;
    float aCoef;
    fscanf(fp_read, "%d", &aNumber);

    startA = count;
    for (i = 0; i < aNumber; i++)
    {
        fscanf(fp_read, "%f %d", &aCoef, &aExpon);
        terms[i].coef = aCoef;
        terms[i].expon = aExpon;
        count++;
    }
    finishA = count - 1;

    fp_read = fopen("b.txt", "r");
    int bNumber, bExpon, startB, finishB;
    float bCoef;
    fscanf(fp_read, "%d", &bNumber);

    startB = count;
    for (i = 0; i < bNumber; i++)
    {
        fscanf(fp_read, "%f %d", &bCoef, &bExpon);
        terms[startB + i].coef = bCoef;
        terms[startB + i].expon = bExpon;
        count++;
    }
    finishB = count - 1;

    int startD, finishD;

    fclose(fp_read);

    padd(startA, finishA, startB, finishB, &startD, &finishD);

    for (i = startD; i <= finishD; i++)
    {
        if (i == finishD)
        {
            printf("%.3f", terms[i].coef);
        }
        else
        {
            printf("%.3fx^%d + ", terms[i].coef, terms[i].expon);
        }
    }

    return 0;
}