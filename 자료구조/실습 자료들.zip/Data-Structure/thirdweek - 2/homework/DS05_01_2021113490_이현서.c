#include <stdio.h>
#include <stdlib.h>

#define TRUE 1;
#define FALSE 0;

#define MAX_DEGREE 1001 /* Max degree of polynomial + 1 */
typedef struct
{
    int degree;
    float coef[MAX_DEGREE];
} polynomial;

typedef int boolean;

/* 일단 0인 D(x)를 만들어야 한다 */

polynomial Zero()
{
    polynomial newPolynomial = {0, 0.0f};
    return newPolynomial;
}

boolean IsZero(polynomial poly)
{
    for (int i = 0; i <= poly.degree; i++)
    {
        if (poly.coef[poly.degree - i] != 0)
            return FALSE;
    }

    return TRUE;
}

// 앞에꼐 크면 1을 반환 같으면 0을 반환 앞에것이 작으면 -1을 반환한다.
int COMPARE(int LeadExpOfValue1, int LeadExpOfValue2)
{
    if (LeadExpOfValue1 > LeadExpOfValue2)
        return 1;
    else if (LeadExpOfValue1 == LeadExpOfValue2)
        return 0;
    else
        return -1;
}

// 주어진 다항식의 최고차항을 반환한다.
int LeadExp(polynomial poly)
{
    int index = 0;
    while (poly.coef[index] == 0)
    {
        index++;
    }
    return poly.degree - index;
}

// 주어진 다항식에 더하는 것이다
polynomial Attach(polynomial targetPoly, float attachCoef, int attachDegree)
{
    // 만약 기존 targetPoly의 degree보다 attachDegree가 크다면 바꾸어 주어야 한다.
    // 어차피 첫번째가 가장크니까 초기화는 1번만 해줄 것이다.
    if (targetPoly.degree < attachDegree)
        targetPoly.degree = attachDegree;

    // degree를 바꾸어 주었다면 계수를 적절하게 삽입해 주어야 한다.
    targetPoly.coef[targetPoly.degree - attachDegree] = attachCoef;
    return targetPoly;
}

// 주어진 다항식의 최고차항의 계수를 알아내야 한다
float Coef(polynomial targetPoly, int degreeOfPoly)
{
    return targetPoly.coef[targetPoly.degree - degreeOfPoly];
}

polynomial Remove(polynomial targetPoly, int removeDegree)
{
    // targetPoly에 해당하는
    targetPoly.coef[targetPoly.degree - removeDegree] = 0;
    return targetPoly;
}

int main(void)
{
    FILE *fp_read;
    fp_read = fopen("a.txt", "r");

    // A 다항식
    int aNumber, aDegree, i;
    float aCoef;
    polynomial A = Zero();

    fscanf(fp_read, "%d", &aNumber);
    for (i = 0; i < aNumber; i++)
    {
        // 만약  3 3 20 2 5 4 0와 같이 주어졌다 해보자 3은 aNumber에 저장될 것이다
        fscanf(fp_read, "%f %d", &aCoef, &aDegree);
        if (i == 0)
        {
            A.degree = aDegree;
        }
        // i가 1부터는 이제 degree는 건들지 않고 계수만 따로 바꾸어 주면 된다.
        A.coef[A.degree - aDegree] = aCoef;
    }

    fp_read = fopen("b.txt", "r");

    // B 다항식
    int bNumber, bDegree;
    float bCoef;
    polynomial B = Zero();
    fscanf(fp_read, "%d", &bNumber);

    for (i = 0; i < bNumber; i++)
    {
        fscanf(fp_read, "%f %d", &bCoef, &bDegree);
        if (i == 0)
        {
            B.degree = bDegree;
        }
        B.coef[B.degree - bDegree] = bCoef;
    }

    polynomial D = Zero();
    fclose(fp_read);

    // a다항식과 b다항식이 0이 아닌동안 진행해야 한다.
    int sum = 0;
    while (!IsZero(A) && !IsZero(B))
    {
        switch (COMPARE(LeadExp(A), LeadExp(B)))
        {
        // 만약 B의 최고차항이 더 크다면
        case -1:
            // D에다가 B의 가장 큰걸 갖다 붙이는 작업이다.
            D = Attach(D, Coef(B, LeadExp(B)), LeadExp(B));
            B = Remove(B, LeadExp(B));
            break;
        case 0:
            sum = Coef(A, LeadExp(A)) + Coef(B, LeadExp(B));
            if (sum)
            {
                D = Attach(D, sum, LeadExp(A));
                A = Remove(A, LeadExp(A));
                B = Remove(B, LeadExp(B));
            }
            break;
        case 1:
            D = Attach(D, Coef(A, LeadExp(A)), LeadExp(A));
            A = Remove(A, LeadExp(A));
            break;
        }
    }

    while (!IsZero(A))
    {
        D = Attach(D, Coef(A, LeadExp(A)), LeadExp(A));
        A = Remove(A, LeadExp(A));
    }

    while (!IsZero(B))
    {
        D = Attach(D, Coef(B, LeadExp(B)), LeadExp(B));
        B = Remove(B, LeadExp(B));
    }

    for (i = 0; i <= D.degree; i++)
    {
        if (D.coef[i] != 0)
        {
            if (i == D.degree)
            {
                printf("%.3f", D.coef[i]);
            }
            else
            {
                printf("%.3fx^%d + ", D.coef[i], D.degree - i);
            }
        }
    }

    return 0;
}