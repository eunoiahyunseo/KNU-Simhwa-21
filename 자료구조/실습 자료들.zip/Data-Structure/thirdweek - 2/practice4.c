#include <stdio.h>

#define MAX_QUEUE_SIZE 6
#define ERROR_INT -1000000

typedef struct
{
    int key;
} element;

element queue[MAX_QUEUE_SIZE];

int rear = 0, front = 0;

void queueFull()
{
    fprintf(stderr, "queue is full");
}

void addq(element item)
{
    rear = (rear + 1) % MAX_QUEUE_SIZE;
    if (front == rear)
    {
        queueFull();
    }
    queue[rear] = item;
}

element queueEmpty()
{
    fprintf(stderr, "queue is Empty");
    element errorElement;
    errorElement.key = ERROR_INT;
    return errorElement;
}

element deleteq()
{
    element item;
    if (front == rear)
    {
        return queueEmpty();
    }
    front = (front + 1) % MAX_QUEUE_SIZE;
    return queue[front];
}

int main(void)
{
    element newElement;
    newElement.key = 4;
    addq(newElement);

    return 0;
}