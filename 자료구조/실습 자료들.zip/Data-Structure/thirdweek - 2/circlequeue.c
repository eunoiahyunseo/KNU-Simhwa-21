#include <stdio.h>
#include <stdlib.h>

#define TRUE 1
#define FALSE 0
#define ERROR -1
#define MAX_SIZE 10

typedef struct __circleQueue
{
    int rear;
    int front;
    element *data;
} Queue;

typedef int element;
typedef int boolean;

/* 큐 초기화 */
void init_queue(Queue *q)
{
    q->front = 0;
    q->rear = 0;
    (element *)malloc(sizeof(element) * MAX_SIZE);
}

/* 공백 상태인지 여부 */
boolean is_empty(Queue *q)
{
    if (q->front == q->rear)
        return TRUE;
    else
        return FALSE;
}

/* 큐가 포화상태인지 여부 */
boolean is_full(Queue *q)
{
    if (q->rear == (q->rear + 1) % MAX_SIZE)
        return TRUE;
    else
        return FALSE;
}
/* 큐에 데이터 삽입 */
void enqueue(Queue *q, element data)
{
    if (is_full(q))
    {
        printf("\n포화 큐\n");
        return;
    }
    else
    {
        q->rear = (q->rear + 1) % MAX_SIZE;
        q->data[q->rear] = data;
    }
    return;
}

/* 큐 데이터 꺼내기 */

int main(void)
{

    return 0;
}