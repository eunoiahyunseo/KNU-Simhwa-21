
            resultMatrix[b[i].row][b[i].col] = b[i].value;