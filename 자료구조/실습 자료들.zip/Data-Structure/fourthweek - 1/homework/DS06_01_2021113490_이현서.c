#include <stdio.h>
#include <stdlib.h>

#define MAX_TERMS 1001
typedef struct
{
    int col;
    int row;
    int value;
} term;

term a[MAX_TERMS];
term b[MAX_TERMS];
term c[MAX_TERMS];
term d[MAX_TERMS];

void fastTranspose(term a[], term b[])
{
    int rowTerms[MAX_TERMS], startingPos[MAX_TERMS];
    int i, j, numCols = a[0].col, numTerms = a[0].value;
    b[0].row = numCols;
    b[0].col = a[0].row;
    b[0].value = numTerms;

    if (numTerms > 0)
    {
        for (i = 0; i < numCols; i++)
            rowTerms[i] = 0;

        for (i = 1; i <= numTerms; i++)
            rowTerms[a[i].col]++;

        startingPos[0] = 1;
        for (i = 1; i < numCols; i++)
            startingPos[i] = startingPos[i - 1] + rowTerms[i - 1];

        for (i = 1; i <= numTerms; i++)
        {
            j = startingPos[a[i].col]++;
            b[j].row = a[i].col;
            b[j].col = a[i].row;
            b[j].value = a[i].value;
        }
    }
}

int main(void)
{
    FILE *fp_read;

    fp_read = fopen("mat1.txt", "r");
    int cols, rows, i, j, count = 0, mat_value;

    if (fscanf(fp_read, "%d %d", &cols, &rows) != EOF)
    {
        a[count].col = cols;
        a[count].row = rows;
        count++;

        for (i = 0; i < rows; i++)
        {
            for (j = 0; j < cols; j++)
            {
                // 만약에 받으려는 값을 제대로 받았다면
                if (fscanf(fp_read, "%d", &mat_value) != EOF)
                {
                    if (mat_value != 0)
                    {
                        a[count].row = i;
                        a[count].col = j;
                        a[count].value = mat_value;
                        count++;
                    }
                }
            }
        }
        a[0].value = count - 1;
    }

    fp_read = fopen("mat2.txt", "r");

    count = 0;

    if (fscanf(fp_read, "%d %d", &cols, &rows) != EOF)
    {
        b[count].col = cols;
        b[count].row = rows;
        count++;

        for (i = 0; i < rows; i++)
        {
            for (j = 0; j < cols; j++)
            {
                if (fscanf(fp_read, "%d", &mat_value) != EOF)
                {
                    if (mat_value != 0)
                    {
                        b[count].row = i;
                        b[count].col = j;
                        b[count].value = mat_value;
                        count++;
                    }
                }
            }
        }
        b[0].value = count - 1;
    }

    fclose(fp_read);

    int **resultMatrix;
    resultMatrix = (int **)malloc(sizeof(int **) * a[0].row);
    for (i = 0; i < a[0].row; i++)
    {
        *(resultMatrix + i) = (int *)malloc(sizeof(int *) * a[0].col);
    }

    for (i = 1; i <= a[0].value; i++)
    {
        resultMatrix[a[i].row][a[i].col] = a[i].value;
    }

    for (i = 1; i <= b[0].value; i++)
    {
        if (resultMatrix[b[i].row][b[i].col])
        {
            resultMatrix[b[i].row][b[i].col] += b[i].value;
        }
        else
        {
            resultMatrix[b[i].row][b[i].col] = b[i].value;
        }
    }

    count = 0;

    for (i = 0; i < a[0].row; i++)
    {
        for (j = 0; j < a[0].col; j++)
        {
            if (resultMatrix[i][j])
            {
                c[count + 1].row = i;
                c[count + 1].col = j;
                c[count + 1].value = *(*(resultMatrix + i) + j);
                count++;
            }
        }
    }
    c[0].row = a[0].row;
    c[0].col = a[0].col;
    c[0].value = count;

    printf("Matrix Addition:\n");
    for (i = 0; i < count + 1; i++)
    {
        printf("%d %d %d\n", c[i].row, c[i].col, c[i].value);
    }

    fastTranspose(c, d);

    printf("Transpose Matrix:\n");
    for (i = 0; i <= d[0].value; i++)
    {
        printf("%d %d %d\n", d[i].row, d[i].col, d[i].value);
    }

    for (i = 0; i < a[i].row; i++)
    {
        free(resultMatrix[i]);
    }

    free(resultMatrix);

    return 0;
}