#include <stdio.h>
#include <stdlib.h>
#define MAX_QUEUE_SIZE 8 /* maximum queue size */

#define TRUE 1
#define FALSE 0
#define ERROR -1
#define MAX_SIZE 10

typedef int element;
typedef int boolean;

typedef struct __circleQueue
{
    int rear;
    int front;
    element *data;
} Queue;

void init_queue(Queue *q, int allocSize)
{
    q->front = 0;
    q->rear = 0;
    q->data = (element *)malloc(sizeof(element) * MAX_SIZE * allocSize);
}

boolean is_empty(Queue *q)
{
    if (q->front == q->rear)
        return TRUE;
    else
        return FALSE;
}

boolean is_full(Queue *q)
{
    if (q->front == (q->rear + 1) % MAX_SIZE)
        return TRUE;
    else
        return FALSE;
}

void enqueue(Queue *q, element data)
{
    if (is_full(q))
    {
        printf("\n포화 큐\n");
        return;
    }
    else
    {
        q->rear = (q->rear + 1) % (MAX_SIZE);
        q->data[q->rear] = data;
    }
}

element dequeue(Queue *q)
{
    if (is_empty(q))
    {
        printf("공백큐\n");
    }

    q->front = (q->front + 1) % MAX_SIZE;
    return q->data[q->front];
}

void queue_print(Queue q)
{
    int i = q.front;
    if (is_empty(&q))
    {
        printf("\n공백 큐\n");
        return;
    }

    while (i != q.rear)
    {
        i = (i + 1) % MAX_SIZE;
        printf("%d | ", q.data[i]);
    }
    printf("\n\n");
}

void copy(int *prevQueueStartIndex, int *prevQueueFinIndex, int *doublingTargetQueue)
{
    while (prevQueueFinIndex == prevQueueFinIndex)
    {
        *doublingTargetQueue = *prevQueueFinIndex;
        doublingTargetQueue++;
        prevQueueFinIndex++;
    }
}

void queueFull(Queue *q)
{
    Queue newQueue;
    init_queue(&newQueue, 2);

    int start = (q->front + 1) % MAX_SIZE;
    if (start < 2)
    {
        /* not wrap around */
        copy(q->data + start, q->data + start + MAX_SIZE - 1, newQueue.data);
    }
    else
    {
        copy(q->data + start, q->data + MAX_SIZE, newQueue.data);
        copy(q->data, q->data + q->rear + 1, newQueue.data + MAX_SIZE - start);
    }
}

int main(void)
{
    Queue q;
    init_queue(&q, 1);
    for (int i = 0; i < 5; i++)
    {
        enqueue(&q, i);
        queue_print(q);
    }

    for (int i = 0; i < 5; i++)
    {
        dequeue(&q);
        queue_print(q);
    }
    return 0;
}