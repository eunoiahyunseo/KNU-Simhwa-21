#include <stdio.h>
#include <stdlib.h>

#define MAX_ARR_SIZE 1000

#define MALLOC(p, s)                            \
    if (!((p) = malloc(s)))                     \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

#define REALLOC(p, s)                           \
    if (!((p) = realloc(p, s)))                 \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

int ArrayRepresent[MAX_ARR_SIZE] = {0};

typedef struct node_
{
    char data;
    struct node_ *leftChild;
    struct node_ *rightChild;
} node, *treePointer;

void initNode(treePointer *ptr, int data)
{
    MALLOC(*ptr, sizeof(node));
    (*ptr)->data = data;
    (*ptr)->leftChild = NULL;
    (*ptr)->rightChild = NULL;
}

void inorder(treePointer ptr)
{
    if (ptr)
    {
        inorder(ptr->leftChild);
        printf("%d ", ptr->data);
        inorder(ptr->rightChild);
    }
}

void preorder(treePointer ptr)
{
    if (ptr)
    {
        printf("%d ", ptr->data);
        preorder(ptr->leftChild);
        preorder(ptr->rightChild);
    }
}

void postorder(treePointer ptr)
{
    if (ptr)
    {
        postorder(ptr->leftChild);
        postorder(ptr->rightChild);
        printf("%d ", ptr->data);
    }
}

void concatTree(treePointer ptr, int i)
{
    treePointer newNode1, newNode2;
    // printf("Array value >> %d %d\n", ArrayRepresent[i * 2], i * 2);
    if (ArrayRepresent[i * 2] != -1 && ArrayRepresent[i * 2] != 0)
    {
        initNode(&newNode1, ArrayRepresent[i * 2]);
        ptr->leftChild = newNode1;
        concatTree(ptr->leftChild, i * 2);
        // 애초에 -1이 나오면 끝내면 된다. -> 그 아래도 추가할 필요가 없으니까.
    }

    // printf("Array value >> %d %d\n", ArrayRepresent[i * 2 + 1], i * 2 + 1);
    if (ArrayRepresent[i * 2 + 1] != -1 && ArrayRepresent[i * 2 + 1] != 0)
    {
        initNode(&newNode2, ArrayRepresent[i * 2 + 1]);
        ptr->rightChild = newNode2;
        concatTree(ptr->rightChild, i * 2 + 1);
        // 애초에 -1이 나오면 끝내면 된다. -> 그 아래도 추가할 필요가 없으니까.
    }
    else
    {
        return;
    }
}
int main(void)
{
    FILE *fp_read = fopen("input.txt", "r");
    int data, i = 1, count = 0;

    fscanf(fp_read, "%d", &data);
    ArrayRepresent[i] = data;

    while (fscanf(fp_read, "%d", &data) != EOF)
    {
        if (count % 2 == 0)
        {
            count++;
            ArrayRepresent[i * 2] = data;
        }
        else
        {
            count++;
            ArrayRepresent[i * 2 + 1] = data;
            i++;
        }
    }

    printf("Level Order: ");
    for (i = 1; i < count + 2; i++)
    {
        if (ArrayRepresent[i] != -1)
        {
            printf("%d ", ArrayRepresent[i]);
        }
    }

    treePointer root;
    treePointer newNode1, newNode2;

    initNode(&root, ArrayRepresent[1]);
    i = 1;

    concatTree(root, i);

    printf("\nPreorder: ");
    preorder(root);

    printf("\nInorder: ");
    inorder(root);

    printf("\nPostorder: ");
    postorder(root);

    fclose(fp_read);

    return 0;
}