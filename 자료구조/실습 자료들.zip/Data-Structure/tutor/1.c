#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int size = 10;
    int *arr;
    arr = malloc(sizeof(int) * size);
    for (int i = 0; i < size; i++)
    {
        scanf("%d", arr + i);
    }

    int temp;
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size - 1 - i; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
    for (int i = 0; i < size; i++)
    {
        printf("%d ", arr[i]);
    }
    printf("\n");

    int i = 0, checker = 0;
    while (i != size - 1)
    {
        if (arr[i] == arr[i + 1])
        {
            for (int k = 0; k < size - 1; k++)
            {
                arr[k] = arr[k + 1];
            }
            i = checker;
            size--;
        }
        else
        {
            i++;
            checker = i;
        }
    }

    for (int i = 0; i < size; i++)
    {
        printf("%d ", arr[i]);
    }
    return 0;
}