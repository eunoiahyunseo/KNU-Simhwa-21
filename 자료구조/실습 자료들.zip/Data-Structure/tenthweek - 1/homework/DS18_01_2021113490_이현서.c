#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#define INFINITE (INT_MAX) / (2)

#define FALSE 0
#define TRUE 1

int *distance;
short int *found;

int selecMinVertex(int *distance, int vertexNum, short int *found)
{
    int min = INFINITE, minPos = -1;
    for (int i = 0; i < vertexNum; i++)
    {
        if ((distance[i] < min) && !found[i])
            min = distance[i], minPos = i;
    }
    return minPos;
}

void shortestPath(int startEdge, int **cost, int *distance, int vertexNum, short int *found)
{
    int nextVertex;
    // 시작 정점에 대한 데이터 초기화를 해주어야 한다.
    for (int i = 0; i < vertexNum; i++)
    {
        found[i] = FALSE;
        distance[i] = cost[startEdge][i];
    }

    found[startEdge] = TRUE;
    // 처음 노드는 distance = 0으로 초기화 해주어야 한다.
    distance[startEdge] = 0;

    // 이제 found가 False이고 가중치가 가장 낮은 것을 찾는 과정을 처리해 주어야 한다.
    for (int j = 0; j < vertexNum - 2; j++)
    {
        nextVertex = selecMinVertex(distance, vertexNum, found);
        found[nextVertex] = TRUE;
        // 반복하면서 더 짧은 거리가 있나 찾아주는 과정이 있어야 한다.
        for (int i = 0; i < vertexNum; i++)
        {
            if (distance[nextVertex] + cost[nextVertex][i] < distance[i])
                distance[i] = distance[nextVertex] + cost[nextVertex][i];
        }
    }
}

int main(void)
{
    FILE *fp_read = fopen("input.txt", "r");

    if (fp_read == NULL)
    {
        fprintf(stderr, "File Open Error!");
        exit(EXIT_FAILURE);
    }

    int vertexNum, startEdge;

    fscanf(fp_read, "%d", &vertexNum);
    fscanf(fp_read, "%d", &startEdge);

    int **cost = (int **)malloc(sizeof(int *) * vertexNum);
    for (int i = 0; i < vertexNum; i++)
        cost[i] = (int *)malloc(sizeof(int) * vertexNum);

    int temp;
    for (int i = 0; i < vertexNum; i++)
    {
        for (int j = 0; j < vertexNum; j++)
        {
            fscanf(fp_read, "%d", &temp);
            if (temp != 0)
                cost[i][j] = temp;
            else
                cost[i][j] = INFINITE;
        }
    }

    found = (short int *)malloc(sizeof(short int) * vertexNum);
    distance = (int *)malloc(sizeof(int) * vertexNum);

    shortestPath(startEdge, cost, distance, vertexNum, found);

    for (int i = 0; i < vertexNum; i++)
        printf("%d ", distance[i]);

    for (int i = 0; i < vertexNum; i++)
        free(cost[i]);

    free(found);
    free(distance);
    free(cost);

    fclose(fp_read);

    return 0;
}