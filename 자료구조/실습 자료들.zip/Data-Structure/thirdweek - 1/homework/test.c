#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void reverseArr(char[]);
void plusArr(char[], char[], char[]);
void minusArr(char[], char[], char[]);

int main(void)
{
    /**
     *  A >> 입력 1배열
     *  B >> 입력 2배열
     *  R >> 둘의 결괏값 저장할 배열
     */
    char A[10000] = {0}, B[10000] = {0}, R[10000] = {0};
    FILE *fp_read;
    fp_read = fopen("a.txt", "r");
    fscanf(fp_read, "%s", A);

    fp_read = fopen("b.txt", "r");
    fscanf(fp_read, "%s", B);

    reverseArr(A);
    reverseArr(B);

    plusArr(A, B, R);
    putchar('\n');
    minusArr(A, B, R);
    fclose(fp_read);
}

void reverseArr(char arr[])
{
    int len, i;
    char temp;

    len = strlen(arr);
    for (i = 0; i < len / 2; i++)
    {
        temp = arr[i];
        arr[i] = arr[len - 1 - i];
        arr[len - 1 - i] = temp;
    }
}

void plusArr(char A[], char B[], char R[])
{
    int i, carry = 0, sum;

    int biggerString = strlen(A) > strlen(B) ? strlen(A) : strlen(B);
    for (i = 0; i < biggerString; i++)
    {
        // sum이 10을 넘어간다면 carry을 만들어 주고 다음에 추가해준다.
        // 만약 A나 B나 R배열에 직접적으로 carry를 더해주게 된다면 9 + 1이되어 이상한 숫자가 나올 수도 있다
        // 따라서 그냥 계산과정에서 추가해주는것이 오류를 나지 않게 해 줄 수 있을 것이다.
        // 숫자로 변환해 주는 과정에서 carry를 더해준다.
        sum = A[i] - '0' + B[i] - '0' + carry;

        // 만약 null문자와의 계산을 음수가 나올 것이다.
        if (sum < 0)
        {
            sum += '0';
        }

        if (sum >= 10)
        {
            carry = 1;
        }
        else
        {
            carry = 0;
        }

        if ((i == biggerString - 1) && carry == 1)
        {
            R[i] = sum % 10 + '0';
            R[i + 1] = '1';
        }
        else
        {
            R[i] = sum % 10 + '0';
        }
    }
    reverseArr(R);
    printf("Addition: %s", R);
}

void minusArr(char A[], char B[], char R[])
{
    int i, carry = 0, sum;

    int biggerString = strlen(A) > strlen(B) ? strlen(A) : strlen(B);

    for (i = 0; i < biggerString; i++)
    {
        sum = (A[i] - '0') - (B[i] - '0') - carry;
        // printf("%d %d", A[i], B[i]);
        if (sum < 0)
        {
            // 만약에 음수가 나온다면 10을 더한다음에 빼주면 된다
            // 여기서 carry의 의미는 앞의 수를 하나 빼주면 된다
            carry = 1;
            sum += 10;
        }
        else
        {
            if (sum > 10)
            {
                // 변환해 주었다 그런데도 음수가 나왔다면
                sum -= '0';
                if (sum < 0)
                {
                    sum += 10;
                    carry = 1;
                    R[i] = sum + '0';
                    continue;
                }
            }
            carry = 0;
        }

        R[i] = sum + '0';
    }
    reverseArr(R);
    printf("Subtraction: ");
    int check = 1;
    for (i = 0; i < strlen(R); i++)
    {
        // check == 1이라면 출력하지 않는다.
        if (R[i] == '0')
        {
            if (check == 1)
            {
                continue;
            }
            else
            {
                printf("%c", R[i]);
            }
        }
        else
        {
            if (check == 1)
            {
                printf("%c", R[i]);
                check = 0;
            }
            else
            {
                printf("%c", R[i]);
            }
        }
    }
}