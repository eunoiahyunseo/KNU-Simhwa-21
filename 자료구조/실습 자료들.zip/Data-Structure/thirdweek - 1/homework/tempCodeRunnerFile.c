, B[i]);
        if (sum < 0)