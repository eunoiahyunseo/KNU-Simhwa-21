#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void reverseArr(char[]);
void plusArr(char[], char[], char[]);
void minusArr(char[], char[], char[]);

int main(void)
{
    char A[10000] = {0}, B[10000] = {0}, R[10000] = {0};
    FILE *fp_read;
    fp_read = fopen("a.txt", "r");
    fscanf(fp_read, "%s", A);

    fp_read = fopen("b.txt", "r");
    fscanf(fp_read, "%s", B);

    reverseArr(A);
    reverseArr(B);

    plusArr(A, B, R);
    putchar('\n');
    memset(R, '\0', sizeof(R) / sizeof(char));
    minusArr(A, B, R);

    fclose(fp_read);
}

void reverseArr(char arr[])
{
    int len, i;
    char temp;

    len = strlen(arr);
    for (i = 0; i < len / 2; i++)
    {
        temp = arr[i];
        arr[i] = arr[len - 1 - i];
        arr[len - 1 - i] = temp;
    }
}

void plusArr(char A[], char B[], char R[])
{
    int i, carry = 0, sum;

    int biggerString = strlen(A) > strlen(B) ? strlen(A) : strlen(B);
    for (i = 0; i < biggerString; i++)
    {
        // sum이 10을 넘어간다면 carry을 만들어 주고 다음에 추가해준다.
        // 만약 A나 B나 R배열에 직접적으로 carry를 더해주게 된다면 9 + 1이되어 이상한 숫자가 나올 수도 있다
        // 따라서 그냥 계산과정에서 추가해주는것이 오류를 나지 않게 해 줄 수 있을 것이다.
        // 숫자로 변환해 주는 과정에서 carry를 더해준다.
        sum = A[i] - '0' + B[i] - '0' + carry;

        // 만약 null문자와의 계산을 음수가 나올 것이다.
        if (sum < 0)
        {
            sum += '0';
        }

        if (sum >= 10)
        {
            carry = 1;
        }
        else
        {
            carry = 0;
        }

        if ((i == biggerString - 1) && carry == 1)
        {
            R[i] = sum % 10 + '0';
            R[i + 1] = '1';
        }
        else
        {
            R[i] = sum % 10 + '0';
        }
    }
    reverseArr(R);
    printf("Addition: %s", R);
}

void minusArr(char A[], char B[], char R[])
{
    int i, carry = 0, sum;

    int biggerString = strlen(A) > strlen(B) ? strlen(A) : strlen(B);

    for (i = 0; i < biggerString; i++)
    {
        sum = (A[i] - '0') - (B[i] - '0') - carry;
        // printf("%d %d", A[i], B[i]);
        if (sum < 0)
        {
            // 만약에 음수가 나온다면 10을 더한다음에 빼주면 된다
            // 여기서 carry의 의미는 앞의 수를 하나 빼주면 된다
            carry = 1;
            sum += 10;
        }
        else
        {
            if (sum > 10)
            {
                // 변환해 주었다 그런데도 음수가 나왔다면
                sum -= '0';
                if (sum < 0)
                {
                    sum += 10;
                    carry = 1;
                    R[i] = sum + '0';
                    continue;
                }
            }
            carry = 0;
        }
        R[i] = sum + '0';
    }
    reverseArr(R);
    printf("Subtraction: ");
    // CASE1: 100 - 1 처럼 계산 결과가 한 자리가 비어서 099 가 나와 0을 제외하는 경우를 생각해 볼 수 있다.
    // 또다른 코너 테이스로 9999 - 9900 = 0099 에서 0을 없애주는 에러처리를 해 줘야 한다.
    if (R[0] == '0')
    {
        int extremeRValue = atoi(R);
        if (extremeRValue != 0)
        {
            int index = 0;
            while (R[++index] == '0')
                ;

            printf("%s", R + index);
        }
        else
        {
            // CASE2: 그냥 값이 0인 경우 ( extreme corner case )
            printf("%d", extremeRValue);
        }
    }
    else
    {
        printf("%s", R);
    }
}