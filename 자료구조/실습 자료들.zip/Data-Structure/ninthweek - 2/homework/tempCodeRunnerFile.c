
int Check[MAX_SIZE][MAX_SIZE] = {0};