#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SIZE 100
#define INFINITE 100000

int Check[MAX_SIZE][MAX_SIZE] = {0};

void smallWeight(int rowSize, int colSize, int **Weight, int *checker)
{
    int small = INFINITE, row, col;
    for (int i = 0; i < rowSize; i++)
    {
        for (int j = i + 1; j < colSize; j++)
        {
            if ((Check[i][j] > 0) && (small > Check[i][j]))
            {
                small = Check[i][j];
                row = i, col = j;
            }
        }
    }
    // 최종적으로 -1로 초기화 해 줘야 한다.
    // 다시 체크 해 주지 않기 위해서
    Check[row][col] = -1;
    Weight[0][*checker] = row;
    Weight[1][(*checker)++] = col;
}

int main(void)
{
    FILE *fp_read = fopen("input.txt", "r");
    if (fp_read == NULL)
    {
        fprintf(stderr, "File Open Error!");
        exit(EXIT_FAILURE);
    }

    int count, EdgeCount = 0;
    fscanf(fp_read, "%d", &count);

    int Graph[MAX_SIZE][MAX_SIZE] = {0};

    int temp;

    // 모든 간선들을 체크 하고 갯수를 저장해 줘야 한다.
    for (int i = 0; i < count; i++)
    {
        for (int j = 0; j < count; j++)
        {
            fscanf(fp_read, "%d", &temp);
            if (temp != 0 && (j > i))
            {
                EdgeCount++;
                Graph[i][j] = temp;
            }
        }
    }

    for (int i = 0; i < count; i++)
    {
        for (int j = 0; j < count; j++)
        {
            Check[i][j] = Graph[i][j];
        }
    }

    // 모든 간선의 개수만큼 반복을 하는데
    // 이에 포함되어 있는 가중치를 작은 순서대로 저장해 줄 Weight 2차원 배열을 만들어 준다.
    int **Weight = malloc(sizeof(int *) * 2);
    for (int i = 0; i < 2; i++)
    {
        Weight[i] = malloc(sizeof(int) * EdgeCount);
    }

    int iterCount = 0;
    for (int i = 0; i < EdgeCount; i++)
    {
        smallWeight(count, count, Weight, &iterCount);
        // printf("%d %d\n", Weight[0][i], Weight[1][i]);
    }

    int *s = malloc(sizeof(int) * count);
    for (int i = 0; i < count; i++)
    {
        s[i] = i;
    }

    // 일단 선택된 간선을 기억하기 위한 2차원 배열을 만들어 주어야 한다.
    int **ReM = malloc(sizeof(int) * count);
    for (int i = 0; i < 2; i++)
    {
        ReM[i] = malloc(sizeof(int) * count);
    }

    // cost비용의 total value
    int totalCost = 0;
    int edgeCount = 0;
    int v1, v2;
    int s1, s2;
    int i = 0;

    while (edgeCount < (count - 1))
    {
        // 간선에 연결된 두 정점을 저장하고
        v1 = Weight[0][i], v2 = Weight[1][i];
        s1 = s[v1], s2 = s[v2];
        printf("s1 >> %d, s2 >> %d\n", s1, s2);
        // 서로 두개가 다르면 ( subtree )
        if (s1 != s2)
        {
            for (int j = 0; j < count; j++)
            {
                if (s[j] == s2)
                {
                    s[j] = s1;
                }
            }

            ReM[0][edgeCount] = v1;
            ReM[1][edgeCount++] = v2;
            totalCost += Graph[v1][v2];
        }
        i++;
    }

    printf("Selected Edges: ");
    for (int k = 0; k < count - 1; k++)
    {
        if (k == count - 2)
            printf("(%d, %d)", ReM[0][k], ReM[1][k]);
        else
            printf("(%d, %d),", ReM[0][k], ReM[1][k]);
    }
    printf("\nCost: %d\n", totalCost);

    fclose(fp_read);

    return 0;
}