#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#define ERROR_KEY -100

#define MALLOC(p, s)                            \
    if (!((p) = malloc(s)))                     \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

typedef struct listNode_
{
    int data;
    struct listNode_ *link;
} listNode, *listPointer;

listPointer create2()
{
    listPointer first, second;
    MALLOC(first, sizeof(*first));
    MALLOC(second, sizeof(*second));

    second->link = NULL;
    second->data = 20;

    first->data = 10;
    first->link = second;

    return first;
}

void insert(listPointer *first, listPointer x, int data)
{
    listPointer temp;
    MALLOC(temp, sizeof(*temp));
    temp->data = data;
    // 만약 first가 null이 아니라면
    if (*first)
    {
        temp->link = x->link;
        x->link = temp;
    }
    else
    // 만약 first가 null이라면
    {
        temp->link = NULL;
        *first = temp;
    }
}

void delete (listPointer *first, listPointer trail, listPointer x)
{
    if (trail)
        trail->link = x->link;
    else
        *first = (*first)->link;

    free(x);
}

void printList(listPointer first)
{
    printf("The list contains: ");
    for (; first; first = first->link)
        printf("%4d", first->data);

    printf("\n");
}

int main(void)
{
    listPointer first = NULL;
    insert(&first, first, 10);
    insert(&first, first, 30);
    insert(&first, first->link, 20);

    delete (&first, first->link, first->link->link);
    delete (&first, NULL, first);

    printList(first);

    return 0;
}