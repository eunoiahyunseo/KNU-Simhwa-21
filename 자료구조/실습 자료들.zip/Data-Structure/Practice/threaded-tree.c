#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define TRUE 1
#define FALSE 0

#define MAX_STACK_SIZE 100
#define ERROR_KEY '~'

#define MALLOC(p, s)                            \
    if (!((p) = malloc(s)))                     \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

#define REALLOC(p, s)                           \
    if (!((p) = realloc(p, s)))                 \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

typedef struct threaded_tree_
{
    short int left_thread;
    struct threaded_tree_ *left_child;
    char data;
    struct threaded_tree_ *right_child;
    short int right_thread;
} threaded_tree, *threaded_pointer;

threaded_pointer insucc(threaded_pointer tree)
{
    /* find the inorder sucessor of tree in a threaded binary tree */
    threaded_pointer temp;
    temp = tree->right_child;

    // tree->right_thread가 false가 아니라면 즉 이뜻은 inorder preccesdor가 없다면.
    if (!tree->right_thread)
    {
        // left_thread가 true인 동안 left_child로 이동
        while (!temp->left_thread)
        {
            temp = temp->left_child;
        }
    }
    return temp;
}

void tinorder(threaded_pointer tree)
{
    threaded_pointer temp = tree;
    for (;;)
    {
        temp = insucc(temp);
        if (temp == tree)
            break;
        printf("%3c", temp->data);
    }
}

void insert_right(threaded_pointer parent, threaded_pointer child)
{
    /*
        insert child as the right child of of parent in a threaded binary tree
    */
    threaded_pointer temp;
    child->right_child = parent->right_child;
    child->right_thread = parent->right_thread;
    child->left_child = parent;
    child->left_thread = TRUE;
    parent->right_child = child;
    parent->right_thread = FALSE;
    if (!child->right_thread)
    {
        temp = insucc(child);
        temp->left_child = child;
    }
}

int main(void)
{
    threaded_pointer root;
    MALLOC(root, sizeof(threaded_tree));
    root->right_thread = FALSE;

    root->right_child = root;
    root->left_thread = FALSE;

    threaded_pointer newTree;
    MALLOC(newTree, sizeof(threaded_tree));

    root->left_child = newTree;
    newTree->left_thread = FALSE;
    newTree->right_thread = FALSE;
    newTree->left_child = NULL;
    newTree->data = 'A';

    return 0;
}