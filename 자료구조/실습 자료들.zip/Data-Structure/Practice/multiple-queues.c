#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_QUEUES 10 /* maximum number of stacks */
#define ERROR_KEY -100

#define MALLOC(p, s)                            \
    if (!((p) = malloc(s)))                     \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

#define REALLOC(p, s)                           \
    if (!((p) = realloc(p, s)))                 \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }
typedef struct
{
    int key;
} element;

typedef struct queue_
{
    element data;
    struct queue_ *link;
} queue, *queuePointer;

queuePointer front[MAX_QUEUES], rear[MAX_QUEUES];

int capacity = 1;

element queueEmpty()
{
    element errorElement;
    errorElement.key = ERROR_KEY;
    fprintf(stderr, "queue is empty, cannot delete element\n");
    return errorElement;
}

void addq(int i, element item)
{
    queuePointer temp;
    MALLOC(temp, sizeof(*temp));

    temp->data = item;
    temp->link = NULL;

    if (front[i])
    {
        rear[i]->link = temp;
    }
    else
    {
        front[i] = temp;
    }
    rear[i] = temp;
}

element deleteq(int i)
{
    queuePointer temp = front[i];
    element item;
    if (!temp)
    {
        return queueEmpty();
    }
    item = temp->data;
    front[i] = temp->link;
    free(temp);
    return item;
}

int main(void)
{
    element newElement = {1};
    addq(0, newElement);
    newElement.key = 3;
    addq(0, newElement);
    newElement.key = 2;
    addq(0, newElement);

    printf("%d ", deleteq(0).key);
    printf("%d ", deleteq(0).key);
    printf("%d ", deleteq(0).key);
    printf("%d ", deleteq(0).key);
}