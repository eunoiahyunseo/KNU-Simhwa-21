#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define ERROR_KEY -100

#define MALLOC(p, s)                            \
    if (!((p) = malloc(s)))                     \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

#define REALLOC(p, s)                           \
    if (!((p) = realloc(p, s)))                 \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

typedef struct
{
    int key;
} element;

int top = -1;
int capacity = 1;

element *stack;

void stackFull()
{
    REALLOC(stack, 2 * capacity * sizeof(*stack));
    capacity *= 2;
}

element stackEmpty()
{
    element errorElement;
    errorElement.key = ERROR_KEY;
    fprintf(stderr, "Stack is empty, cannot pop element\n");
    return errorElement;
}

void push(element item)
{
    if (top >= capacity - 1)
        stackFull();
    stack[++top] = item;
}

element pop()
{
    if (top == -1)
        return stackEmpty();
    return stack[top--];
}

void popAndprint()
{
    int key = pop().key;
    if (key != ERROR_KEY)
    {
        printf("%d\n", key);
        return;
    }
    return;
}

int main(void)
{
    MALLOC(stack, sizeof(*stack));
    element newElement = {1};
    push(newElement);
    newElement.key = 3;
    push(newElement);
    newElement.key = 2;
    push(newElement);

    popAndprint();
    popAndprint();
    popAndprint();
    popAndprint();

    return 0;
}