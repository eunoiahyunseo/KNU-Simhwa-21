#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define ARR_SIZE 100
#define MALLOC(p, s)                            \
    if (!((p) = malloc(s)))                     \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

#define REALLOC(p, s)                           \
    if (!((p) = realloc(p, s)))                 \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

typedef enum
{
    lparen,
    rparen,
    plus,
    minus,
    times,
    divide,
    mod,
    exponentiation,
    equal,
    eos,
    operand
} precedence;

int top = -1;
int capacity = 1;

int *stack;

int isp[] = {0, 19, 12, 12, 13, 13, 13, -1, -1, 0};
int icp[] = {20, 19, 12, 12, 13, 13, 13, -1, -1, 0};

void stackFull()
{
    REALLOC(stack, 2 * capacity * sizeof(*stack));
    capacity *= 2;
}

void push(int item)
{
    if (top >= capacity - 1)
        stackFull();

    stack[++top] = item;
}

int pop()
{
    if (top == -1)
        return -1000000;
    return stack[top--];
}

char postfix[ARR_SIZE] = {0};
char infix_result[ARR_SIZE] = {0};

precedence getToken(char *symbol, int *n)
{
    *symbol = postfix[(*n)++];
    switch (*symbol)
    {
    case '(':
        return lparen;
    case ')':
        return rparen;
    case '+':
        return plus;
    case '-':
        return minus;
    case '/':
        return divide;
    case '*':
        return times;
    case '%':
        return mod;
    case '^':
        return exponentiation;
    case '=':
        return equal;
    case '\0':
        return eos;
    default:
        return operand;
    }
}

char return_token(precedence token)
{
    switch (token)
    {
    case plus:
        return '+';
    case minus:
        return '-';
    case divide:
        return '/';
    case times:
        return '*';
    case mod:
        return '%';
    case exponentiation:
        return '^';
    case equal:
        return '=';
    default:
        return '1';
    }
}

int eval(void)
{
    precedence token;
    char symbol;
    int op1, op2;
    int n = 0;

    token = getToken(&symbol, &n);
    while (token != eos)
    {
        if (token == operand)
            push(symbol - '0');
        else
        {
            op2 = pop();
            op1 = pop();
            switch (token)
            {
            case plus:
                push(op1 + op2);
                break;
            case minus:
                push(op1 - op2);
                break;
            case times:
                push(op1 * op2);
                break;
            case divide:
                push(op1 / op2);
                break;
            case mod:
                push(op1 % op2);
            case exponentiation:
                push(pow(op1, op2));
                break;
            case equal:
                push(op1 == op2 ? 1 : 0);
                break;
            default:
                break;
            }
        }
        token = getToken(&symbol, &n);
    }
    return pop();
}

void postfixInvert(void)
{
    char symbol;
    precedence token;

    int n = 0, count = 0;
    push(eos);

    for (token = getToken(&symbol, &n); token != eos; token = getToken(&symbol, &n))
    {
        if (token == operand)
            postfix[count++] = symbol;
        else if (token == rparen)
        {
            /* unstack tokens until left parenthesis */
            while (stack[top] != lparen)
                postfix[count++] = return_token(pop());
            pop();
        }
        else
        {
            /* remove and print symbols whose isp is greater
                than or equal to the current token's icp
            */
            while (isp[stack[top]] >= icp[token])
                postfix[count++] = return_token(pop());
            push(token);
        }
    }

    while ((token = pop()) != eos)
        postfix[count++] = return_token(token);

    memset(postfix + count, 0, sizeof(char) * (ARR_SIZE - count));
    printf("\n");
}

void postfixInvert2(void)
{
    char symbol;
    precedence token;

    int n = 0, count = 0;
    push(eos);

    for (token = getToken(&symbol, &n); token != eos; token = getToken(&symbol, &n))
    {
        if (token == operand)
        {
            printf("%c", symbol);
        }
        else if (token == rparen)
        {
            while (stack[top] != lparen)
                printf("%c", return_token(pop()));
            pop();
        }
        else
        {
            while (isp[stack[top]] >= icp[token])
                printf("%c", return_token(pop()));

            push(token);
        }
    }

    while ((token = pop()) != eos)
        printf("%c", return_token(token));
}

int main(void)
{
    FILE *fp_read = fopen("postfix.txt", "r");

    fread(postfix, sizeof(postfix), 1, fp_read);
    MALLOC(stack, sizeof(*stack) * capacity);

    // 받아 들인 infix -> postfix로 바꾼다.
    // postfixInvert();
    // printf("postfix >> %s\n", postfix);

    // // postfix결과를 출력한다.
    // printf("result >> %d", eval());

    postfixInvert2();
    return 0;
}