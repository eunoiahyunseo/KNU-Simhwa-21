#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define MAX_STACK_SIZE 100
#define ERROR_KEY '~'

#define MALLOC(p, s)                            \
    if (!((p) = malloc(s)))                     \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

#define REALLOC(p, s)                           \
    if (!((p) = realloc(p, s)))                 \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

typedef struct node_
{
    char data;
    struct node_ *leftChild;
    struct node_ *rightChild;
} node, *treePointer;

int top = -1;
int capacity = 1;

treePointer stack;

void stackFull()
{
    REALLOC(stack, 2 * capacity * sizeof(*stack));
    capacity *= 2;
}

node stackEmpty()
{
    treePointer ptr;
    MALLOC(ptr, sizeof(*ptr));
    ptr->data = ERROR_KEY;
    return *ptr;
}

void push(node item)
{
    if (top >= capacity - 1)
        stackFull();
    stack[++top] = item;
}

node pop()
{
    if (top == -1)
        return stackEmpty();
    return stack[top--];
}

void initNode(treePointer *ptr, char data)
{
    MALLOC(*ptr, sizeof(node));
    (*ptr)->data = data;
    (*ptr)->leftChild = NULL;
    (*ptr)->rightChild = NULL;
}

void inorder(treePointer ptr)
{
    if (ptr)
    {
        inorder(ptr->leftChild);
        printf("%c ", ptr->data);
        inorder(ptr->rightChild);
    }
}

void preorder(treePointer ptr)
{
    if (ptr)
    {
        printf("%c ", ptr->data);
        preorder(ptr->leftChild);
        preorder(ptr->rightChild);
    }
}

void postorder(treePointer ptr)
{
    if (ptr)
    {
        postorder(ptr->leftChild);
        postorder(ptr->rightChild);
        printf("%c ", ptr->data);
    }
}

void iter_inorder(treePointer root)
{
    treePointer ptr;
    node temp;

    top = -1;
    ptr = root;

    while (1)
    {
        while (ptr != NULL)
        {
            push(*ptr);
            ptr = ptr->leftChild;
        }

        temp = pop();
        if (temp.data == ERROR_KEY)
            break;

        printf("%c ", temp.data);
        ptr = temp.rightChild;
    }
}

treePointer copy(treePointer original)
{
    /**
     * this function returns a treePointer to an exact copy of the original tree
     */
    treePointer temp;
    if (original)
    {
        MALLOC(temp, sizeof(*temp));
        temp->leftChild = copy(original->leftChild);
        temp->rightChild = copy(original->rightChild);
        temp->data = original->data;
        return temp;
    }
    return NULL;
}

int equalTree(treePointer first, treePointer second)
{
    printf("\n%c %c %d\n", first->data, second->data, !second && !first);

    // first와 second이 다르면 false를 리턴하고 같으면 true를 리턴합니다.
    return ((!first && !second) ||
            (first && second && (first->data == second->data) &&
             equalTree(first->leftChild, second->leftChild) &&
             equalTree(first->rightChild, second->rightChild)));
}

int main(void)
{
    treePointer root;
    treePointer newNode, newNode2, newNode3;

    initNode(&newNode, '+');
    root = newNode;

    initNode(&newNode2, '*');
    newNode->leftChild = newNode2;

    initNode(&newNode3, 'E');
    newNode->rightChild = newNode3;

    initNode(&newNode, '*');
    newNode2->leftChild = newNode;

    initNode(&newNode3, 'D');
    newNode2->rightChild = newNode3;

    initNode(&newNode2, '/');
    newNode->leftChild = newNode2;

    initNode(&newNode3, 'C');
    newNode->rightChild = newNode3;

    initNode(&newNode, 'A');
    newNode2->leftChild = newNode;

    initNode(&newNode3, 'B');
    newNode2->rightChild = newNode3;

    printf("================inorder================\n");
    inorder(root);

    printf("\n================preorder================\n");
    preorder(root);

    printf("\n================postorder================\n");
    postorder(root);

    printf("\n================iter_inorder================\n");

    MALLOC(stack, sizeof(*stack));
    iter_inorder(root);
    printf("\n===copy the binary tree===\n");
    treePointer copyTree = copy(root);
    iter_inorder(copyTree);

    if (equalTree(copyTree, root))
    {
        printf("same Tree!!");
    }

    return 0;
}