#include <stdlib.h>
#include <stdio.h>

#define TRUE 1
#define FALSE 0

#define MALLOC(p, s)                            \
    if (!((p) = malloc(s)))                     \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

#define REALLOC(p, s)                           \
    if (!((p) = realloc(p, s)))                 \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

typedef struct
{
    short int row;
    short int col;
    short int dir;
} element;
element *stack;

typedef struct
{
    short int vert;
    short int horiz;
} offsets;

int top = -1;
int capacity = 1;

offsets move[8] = {{-1, 0}, {-1, -1}, {0, 1}, {1, 1}, {1, 0}, {1, -1}, {0, -1}, {1, -1}};

void stackFull()
{
    REALLOC(stack, 2 * capacity * sizeof(*stack));
    capacity *= 2;
}

element stackEmpty()
{
    element errorElement = {-1, -1, -1};
    fprintf(stderr, "Stack is empty, cannot pop element\n");
    return errorElement;
}

void push(element item)
{
    if (top >= capacity - 1)
        stackFull();
    stack[++top] = item;
}

element pop()
{
    if (top == -1)
        return stackEmpty();
    return stack[top--];
}

int main(void)
{
    FILE *fp_read = fopen("maze.txt", "r");
    int col, row, i, j;
    fscanf(fp_read, "%d %d", &row, &col);

    int **maze;
    MALLOC(maze, sizeof(*maze) * (row + 2));
    for (i = 0; i < row + 2; i++)
    {
        MALLOC(*(maze + i), sizeof(**maze) * (col + 2));
    }

    int **mark;
    MALLOC(mark, sizeof(*mark) * row);
    for (i = 0; i < row; i++)
    {
        MALLOC(*(mark + i), sizeof(**mark) * (col));
    }

    for (i = 0; i < row + 2; i++)
    {
        for (j = 0; j < col + 2; j++)
        {
            if (i == 0 || i == row + 1)
            {
                maze[i][j] = 1;
            }
            else
            {
                if (j == 0 || j == col + 1)
                {
                    maze[i][j] = 1;
                }
                else
                {
                    fscanf(fp_read, "%d", maze[i] + j);
                }
            }
        }
    }

    // position을 저장할 stack
    MALLOC(stack, sizeof(*stack));

    /**
     *  starting point (1, 1)
     *  ending point (row, col)
     */

    // next_row와 next_col을 최초 지정값인 (1, 1)지정해줘야 함.
    int row_, col_, next_row, next_col, found = FALSE, dir;
    element position;

    // 지금 초기는 (1, 1)부터 시작해야 하니까 mark칠해주고 position을 (1, 1, 1)로 해준다.
    // row->1, col->1, dir->1부터 시작
    mark[1][1] = 1;
    element initElement = {1, 1, 0};
    push(initElement);

    // 스택에 elemen가 있고 찾아지지 않은동안
    while ((top != -1) && !found)
    {
        // 위에서 지정한 row_, col_은 유동적인 우리가 가야할 길을 저장할 변수이다.
        position = pop();
        row_ = position.row;
        col_ = position.col;
        dir = position.dir;

        // 방향 8바퀴를 돌고 찾을 동안
        while (dir < 8 && !found)
        {
            // 갈 row, col을 next_row와 next_col에 지정해 준다.
            next_row = row_ + move[dir].vert;
            next_col = col_ + move[dir].horiz;

            // 만약 우리가 원하던 길이면 찾았다고 한다.
            if (next_row == row && next_col == col)
            {
                position.row = row_;
                position.col = col_;
                position.dir = dir;
                push(position);
                position.row = row;
                position.col = col;
                position.dir = dir;
                push(position);
                found = TRUE;
            }
            // 만약 가보지 않은 길이고 0이라면
            else if (!maze[next_row][next_col] && !mark[next_row][next_col])
            {
                mark[next_row][next_col] = 1;
                position.row = row_;
                position.col = col_;
                position.dir = dir;
                // 이를 stack에 push해준다.
                push(position);
                // 찾으면 row_, col_을 수정하고 dir를 0으로 지정해 줘야 한다.
                row_ = next_row;
                col_ = next_col;
                dir = 0;
            }
            else
                ++dir;
        }
    }
    if (found)
    {
        printf("The path is : \n");
        for (i = 0; i <= top; i++)
        {
            printf("%2d%5d\n", stack[i].row, stack[i].col);
        }
        // printf("%2d%5d\n", row, col);
    }

    return 0;
}