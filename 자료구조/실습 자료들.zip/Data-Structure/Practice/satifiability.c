#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define TRUE 1
#define FALSE 0

#define MALLOC(p, s)                            \
    if (!((p) = malloc(s)))                     \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

#define REALLOC(p, s)                           \
    if (!((p) = realloc(p, s)))                 \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

typedef enum
{
    not,
    and,
    or
    ,
    true,
    false
} logical;

typedef struct node_
{
    struct node_ *left_child;
    logical data;
    short int value;
    struct node_ *right_child;
} node, *tree_pointer;

void initNode(tree_pointer *ptr, logical data)
{
    MALLOC(*ptr, sizeof(node));
    (*ptr)->data = data;
    (*ptr)->left_child = NULL;
    (*ptr)->right_child = NULL;
}

void post_order_eval(tree_pointer node)
{
    if (node)
    {
        post_order_eval(node->left_child);
        post_order_eval(node->right_child);
        switch (node->data)
        {
        case not:
            node->value = !node->right_child->value;
            break;
        case and:
            node->value = node->right_child->value && node->left_child->value;
            break;
        case or:
            node->value = node->right_child->value || node->left_child->value;
            break;
        case true:
            node->value = TRUE;
            break;
        case false:
            node->value = FALSE;
            break;
        }
    }
}

logical intArr[100] = {0};
logical intArr_final[100][100] = {0};

int count = 0;
void combination(int startIdx, int final)
{
    if (startIdx == final)
    {
        for (int i = 0; i < final; i++)
        {
            intArr_final[count][i] = intArr[i];
        }
        count++;
        return;
    }

    intArr[startIdx] = false;
    combination(startIdx + 1, final);
    intArr[startIdx] = true;
    combination(startIdx + 1, final);
}

int main(void)
{
    tree_pointer root;
    tree_pointer newNode, newNode2, newNode3;

    tree_pointer treeArr[2] = {newNode2, newNode3};

    initNode(&newNode, or);
    root = newNode;

    // initNode(&newNode2, false);
    // newNode->left_child = newNode2;

    // initNode(&newNode3, true);
    // newNode->right_child = newNode3;

    combination(0, 2);
    printf("참이되는 조합은?\n");
    for (int i = 0; i < count; i++)
    {
        for (int j = 0; j < 2; j++)
        {
            initNode(&treeArr[j], intArr_final[i][j]);
        }
        newNode->left_child = treeArr[0];
        newNode->right_child = treeArr[1];

        post_order_eval(root);
        if (root->value)
        {
            printf("%s %s\n", intArr_final[i][0] == false ? "FALSE" : "TRUE", intArr_final[i][1] == false ? "FALSE" : "TRUE");
        }
    }

    return 0;
}