#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define ERROR_KEY -100

#define MALLOC(p, s)                            \
    if (!((p) = malloc(s)))                     \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

#define REALLOC(p, s)                           \
    if (!((p) = realloc(p, s)))                 \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

typedef struct
{
    int key;
} element;

element *queue;

int capacity = 1;
int rear = -1;
int front = -1;

void queueFull()
{
    REALLOC(queue, 2 * capacity * sizeof(*queue));
    capacity *= 2;
}

element queueEmpty()
{
    element errorElement;
    errorElement.key = ERROR_KEY;
    fprintf(stderr, "queue is empty, cannot delete element\n");
    return errorElement;
}

void addq(element item)
{
    if (rear == capacity - 1)
    {
        queueFull();
    }

    queue[++rear] = item;
}

element deleteq()
{
    if (front == rear)
        return queueEmpty();
    return queue[++front];
}

void deleteAndPrint()
{
    int key = deleteq().key;
    if (key != ERROR_KEY)
    {
        printf("%d\n", key);
        return;
    }
    return;
}

int main(void)
{
    MALLOC(queue, sizeof(*queue));
    element newElement = {1};
    addq(newElement);
    newElement.key = 3;
    addq(newElement);
    newElement.key = 2;
    addq(newElement);

    deleteAndPrint();
    deleteAndPrint();
    deleteAndPrint();
    deleteAndPrint();

    return 0;
}