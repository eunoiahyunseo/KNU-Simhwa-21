#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#pragma warning(disable 4996)

int main()
{
    char take[1000];
    int takei[1000] = {0};
    int cnt = -1;
    int temp = 0;
    FILE *fp = fopen("input5.txt", "r");
    fscanf(fp, "%s", take);
    fclose(fp);
    for (int i = 0; i < strlen(take); i++)
    {
        if ((take[i] - '0') >= 0 && (take[i] - '0') <= 9)
        {
            cnt++;
            takei[cnt] = take[i] - '0';
        }
        else if (take[i] == '+')
        {
            temp = takei[cnt - 1] + takei[cnt];
            cnt--;
            takei[cnt] = temp;
        }
        else if (take[i] == '-')
        {
            temp = takei[cnt - 1] - takei[cnt];
            cnt--;
            takei[cnt] = temp;
        }
        else if (take[i] == '*')
        {
            temp = takei[cnt - 1] * takei[cnt];
            cnt--;
            takei[cnt] = temp;
        }
        else if (take[i] == '/')
        {
            temp = takei[cnt - 1] / takei[cnt];
            cnt--;
            takei[cnt] = temp;
        }
        else if (take[i] == '%')
        {
            temp = takei[cnt - 1] % takei[cnt];
            cnt--;
            takei[cnt] = temp;
        }
        else if (take[i] == '^')
        {
            temp = 1;
            for (int i = 0; i < takei[cnt]; i++)
            {
                temp *= takei[cnt - 1];
            }
            cnt--;
            takei[cnt] = temp;
        }
        else if (take[i] == '=')
        {
            if (takei[cnt - 1] == takei[cnt])
            {
                temp = 1;
            }
            else
            {
                temp = 0;
            }
            cnt--;
            takei[cnt] = temp;
        }
    }
    printf("%d\n", takei[cnt]);
}
