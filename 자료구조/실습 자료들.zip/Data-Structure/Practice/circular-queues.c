#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#define ERROR_KEY -100

#define MALLOC(p, s)                            \
    if (!((p) = malloc(s)))                     \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

#define REALLOC(p, s)                           \
    if (!((p) = realloc(p, s)))                 \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

typedef struct
{
    int key;
} element;
element *queue;

int capacity = 6;
int rear = -1;
int front = -1;

void copy(element *startIndex, element *endIndex, element *targetIndex)
{
    /* startIndex ~ endIndex - 1 */
    int increaseIndex = 0;
    while (startIndex != endIndex)
    {
        *(targetIndex + increaseIndex++) = *(startIndex++);
    }
}

void queueFull()
{
    element *newQueue;
    MALLOC(newQueue, 2 * capacity * sizeof(*queue));

    int start = (front + 1) % capacity;

    if (start < 2)
    {
        /* no wrap around */
        copy(queue + start, queue + start + capacity - 1, newQueue);
    }
    else
    {
        /* queue wraps around */
        copy(queue + start, queue + capacity, newQueue);
        copy(queue, queue + rear + 1, newQueue + capacity - start);
    }

    /* switch to newQueue */
    front = 2 * capacity - 1;
    rear = capacity - 2;
    capacity *= 2;
    free(queue);
    queue = newQueue;
}

element queueEmpty()
{
    element errorElement;
    errorElement.key = ERROR_KEY;
    fprintf(stderr, "queue is empty, cannot delete element\n");
    return errorElement;
}

/* add an item to the queue */
void addq(element item)
{
    rear = (rear + 1) % capacity;
    if (front == rear)
    {
        queueFull();
        rear = (rear + 1) % capacity;
    }

    queue[rear] = item;
}

/* remove front element from the queue */
element deleteq()
{
    if (front == rear)
        return queueEmpty();
    front = (front + 1) % capacity;
    return queue[front];
}

void printQueue()
{
    int tempRear = rear, tempFront = front;
    int count = abs(rear - front);

    // front부터 시작해서 row를 만날 때 까지
    while (tempFront != tempRear % capacity)
    {
        tempFront = (tempFront + 1) % capacity;
        printf("%d ", queue[tempFront].key);
    }
}

int main(void)
{
    MALLOC(queue, sizeof(*queue) * capacity);

    element newElement = {1};
    addq(newElement);
    addq(newElement);
    addq(newElement);
    addq(newElement);
    addq(newElement);
    deleteq();
    deleteq();
    deleteq();
    deleteq();
    addq(newElement);
    deleteq();
    newElement.key = 2;
    addq(newElement);
    newElement.key = 3;
    addq(newElement);
    newElement.key = 4;
    addq(newElement);
    newElement.key = 5;
    addq(newElement);
    newElement.key = 6;
    addq(newElement);
    deleteq();
    newElement.key = 7;
    addq(newElement);
    deleteq();

    // 우리가 원하는 circular queue의 상태가 완성 되었다.
    printQueue();

    printf("\nrear >> %d", rear);

    return 0;
}