#include <stdio.h>
#include <stdlib.h>

#define MAX_STACKS 10 /* maximum number of stacks */
#define ERROR_STATE -100

#define MALLOC(p, s)                            \
    if (!((p) = malloc(s)))                     \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

typedef struct
{
    int key;
} element;

typedef struct stack_
{
    element data;
    struct stack_ *link;
} stack, *stackPointer;

stackPointer top[MAX_STACKS];

element stackEmpty()
{
    element errElement;
    errElement.key = ERROR_STATE;
    printf("\nstack is empty!!");
    return errElement;
}

void push(int i, element item)
{
    stackPointer temp;
    MALLOC(temp, sizeof(*temp));
    temp->data = item;
    temp->link = top[i];
    top[i] = temp;
}

element pop(int i)
{
    stackPointer temp = top[i];
    element item;
    if (!temp)
        return stackEmpty();
    item = temp->data;
    top[i] = temp->link;
    free(temp);
    return item;
}

void popAndPrint(int i)
{
    int key = pop(i).key;
    if (key == ERROR_STATE)
        return;
    printf("%d ", key);
}

int main(void)
{
    element newElement = {1};
    push(0, newElement);
    newElement.key = 3;
    push(0, newElement);
    newElement.key = 2;
    push(0, newElement);

    popAndPrint(0);
    popAndPrint(0);
    popAndPrint(0);
    popAndPrint(0);

    return 0;
}