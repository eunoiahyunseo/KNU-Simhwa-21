#include <stdio.h>
#include <stdlib.h>

#define MALLOC(p, s)                            \
    if (!((p) = malloc(s)))                     \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

#define REALLOC(p, s)                           \
    if (!((p) = realloc(p, s)))                 \
    {                                           \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);                     \
    }

#define FALSE 0
#define TRUE 1

typedef struct node_
{
    int data;
    struct node_ *link;

} node, *nodePointer;

int main(void)
{
    FILE *fp_read;
    if ((fp_read = fopen("input.txt", "r")) == NULL)
    {
        fprintf(stderr, "File Open Error!");
        return 0;
    }

    int objectNumber, pairNumber, k;

    fscanf(fp_read, "%d", &objectNumber);
    fscanf(fp_read, "%d", &pairNumber);

    short *out;
    MALLOC(out, sizeof(short) * objectNumber);

    nodePointer *seq;
    MALLOC(seq, sizeof(nodePointer) * objectNumber);

    for (k = 0; k < objectNumber; k++)
    {
        out[k] = TRUE;
    }

    // 추가할 pair의 node
    nodePointer x;
    int i, j;

    for (k = 0; k < pairNumber; k++)
    {
        MALLOC(x, sizeof(node));
        fscanf(fp_read, "%d %d", &i, &j);

        x->data = j;
        x->link = seq[i];
        seq[i] = x;

        MALLOC(x, sizeof(node));
        x->data = i;
        x->link = seq[j];
        seq[j] = x;
    }

    nodePointer temp, temp2, top = NULL;

    for (i = 0; i < objectNumber; i++)
    {
        if (out[i] == TRUE)
        {
            if (i == 0)
            {
                printf("new class: %5d", i);
            }
            else
            {
                printf("\nnew class: %5d", i);
            }

            out[i] = FALSE;
            temp = seq[i];

            while (TRUE)
            {
                while (temp)
                {
                    j = temp->data;
                    if (out[j])
                    {
                        printf("%5d", j);
                        out[j] = FALSE;
                        temp2 = temp->link;
                        temp->link = top;
                        top = temp;
                        temp = temp2;
                    }
                    else
                    {
                        temp = temp->link;
                    }
                }

                if (!top)
                    break;
                temp = seq[top->data];
                top = top->link;
            }
        }
    }

    free(x);
    fclose(fp_read);

    return 0;
}