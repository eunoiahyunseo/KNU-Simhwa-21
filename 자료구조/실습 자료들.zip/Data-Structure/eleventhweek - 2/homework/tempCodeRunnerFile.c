
    homeBucket = hashFunction(key, tableSize);