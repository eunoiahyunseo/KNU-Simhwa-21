#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX_SUBJECT_LENGTH 100
#define weekEndValue 7

typedef struct subject_
{
    char subjectName[MAX_SUBJECT_LENGTH];
    float subject_time;
} subject, *subjectPointer;

typedef enum DayOfWeek_
{
    Sun,
    Mon,
    Tues,
    Wednes,
    Thurs,
    Fri,
    Satur,
} week;

char *enumMapping(int dayValue)
{
    switch (dayValue)
    {
    case Sun:
        return ("Sunday");
    case Mon:
        return ("Monday");
    case Tues:
        return ("Tuesday");
    case Wednes:
        return ("Wednesday");
    case Thurs:
        return ("Thursday");
    case Fri:
        return ("Friday");
    case Satur:
        return ("Saturday");
    default:
        return "";
    }
}
void calcTime(subjectPointer subject, int totalTime, int subjectNum, week dayValue)
{
    int total = 0, random;
    for (int i = 0; i < subjectNum; i++)
    {
        random = (rand() % 10) + 1, total += random;
        subject[i].subject_time = random;
    }

    for (int i = 0; i < subjectNum; i++)
    {
        subject[i].subject_time = (subject[i].subject_time / total) * totalTime;
    }
}

int main(void)
{
    // 받을 과목의 숫자
    int subjectNum;
    printf("입력할 과목의 갯수를 입력해 주세요\n");
    scanf("%d", &subjectNum);
    srand(time(NULL));

    // 과목 명을 subjectNum번 반복해서 받아서 배열에 저장
    subjectPointer *subjectArr;
    subjectArr = (subjectPointer *)(malloc(sizeof(subjectPointer) * weekEndValue));
    for (int i = 0; i < weekEndValue; i++)
        subjectArr[i] = (subjectPointer)(malloc(sizeof(subject) * subjectNum));

    printf("과목의 이름을 입력해주세요.\n");
    for (int i = 0; i < subjectNum; i++)
    {
        for (int j = 0; j < weekEndValue; j++)
        {
            if (j == 0)
                scanf("%s", subjectArr[j][i].subjectName);
            else
                strcpy(subjectArr[j][i].subjectName, subjectArr[j - 1][i].subjectName);
        }
    }

    int totalTime;
    printf("총 할당할 시간을 입력해 주세요\n");
    scanf("%d", &totalTime);

    printf("============================ 주간 시간표 ===========================\n");
    for (int i = 0; i < weekEndValue; i++)
        printf("%-30s", enumMapping(i));

    for (int i = 0; i < weekEndValue; i++)
        calcTime(subjectArr[i], totalTime, subjectNum, i);

    printf("\n\n");

    for (int i = 0; i < subjectNum; i++)
    {
        for (int j = 0; j < weekEndValue; j++)
        {
            printf("%-10s%14.0f시간 |   ", subjectArr[j][i].subjectName, subjectArr[j][i].subject_time);
        }
        printf("\n");
    }

    return 0;
}