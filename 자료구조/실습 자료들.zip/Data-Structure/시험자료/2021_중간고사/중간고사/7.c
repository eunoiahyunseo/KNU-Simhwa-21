#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define TRUE 1
#define FALSE 0

#define MALLOC(p, s)                                \
    if (!((p) = malloc(s)))                         \
    {                                               \
        fprintf(stderr, "error occured in MALLOC"); \
        exit(EXIT_FAILURE);                         \
    }

char res[100] = {0};

void reverse(char arr[])
{
    int len = strlen(arr);
    char temp;
    for (int i = 0; i < len / 2; i++)
    {
        temp = arr[i];
        arr[i] = arr[len - 1 - i];
        arr[len - 1 - i] = temp;
    }
}

void plus(char A[], char B[])
{
    reverse(A);
    reverse(B);

    int len = strlen(A) > strlen(B) ? strlen(A) : strlen(B);
    int i, carry = 0;

    for (i = 0; i < len; i++)
    {
        int sum = A[i] - '0' + B[i] - '0' + carry;
        while (sum < 0)
        {
            sum += '0';
        }

        if (sum > 9)
            carry = 1;
        else
            carry = 0;

        res[i] = sum % 10 + '0';
    }
    if (carry == 1)
        res[len] = '1';

    reverse(res);
    printf("%s\n", res);
    memset(res, 0, sizeof(char) * 100);
}

void minus(char A[], char B[])
{
    int len = strlen(A) > strlen(B) ? strlen(A) : strlen(B);
    int i, carry = 0;

    for (i = 0; i < len; i++)
    {
        int minus = A[i] - '0' - (B[i] - '0') - carry;

        while (minus > 9)
            minus -= '0';

        if (minus < 0)
        {
            carry = 1;
            minus += 10;
        }
        else
            carry = 0;

        res[i] = minus + '0';
    }
    reverse(res);
    int check = 0;
    for (i = 0; res[i] != NULL; i++)
    {
        if (res[i] != '0')
        {
            check = 1;
        }
        if (check == 1)
        {
            printf("%c", res[i]);
        }
    }
}

int main(void)
{
    FILE *fp_read;
    char A[10000] = {0}, B[10000] = {0};

    fp_read = fopen("value1.txt", "r");
    fscanf(fp_read, "%s", A);

    fp_read = fopen("value2.txt", "r");
    fscanf(fp_read, "%s", B);

    fclose(fp_read);

    plus(A, B);
    minus(A, B);
}