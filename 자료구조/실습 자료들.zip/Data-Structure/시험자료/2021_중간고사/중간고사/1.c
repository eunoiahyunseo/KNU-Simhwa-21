#include <stdio.h>
#include <stdlib.h>

#define MALLOC(p, s)                                \
    if (!((p) = malloc(s)))                         \
    {                                               \
        fprintf(stderr, "error occured in MALLOC"); \
        exit(EXIT_FAILURE);                         \
    }

int main(void)
{
    FILE *fp_read = fopen("input.txt", "r");
    int value1, value2;
    fscanf(fp_read, "%d %d", &value1, &value2);

    printf("%d", value1 < value2 ? value2 : value1);

    return 0;
}
