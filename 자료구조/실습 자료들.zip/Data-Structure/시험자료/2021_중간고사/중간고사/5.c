#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define TRUE 1
#define FALSE 0

#define MAX_STACK_SIZE 100
#define ERROR_KEY -999999

#define MALLOC(p, s)                                \
    if (!((p) = malloc(s)))                         \
    {                                               \
        fprintf(stderr, "error occured in MALLOC"); \
        exit(EXIT_FAILURE);                         \
    }

typedef enum
{
    lparen,
    rparen,
    plus,
    minus,
    times,
    divide,
    mod,
    exponentiation,
    equal,
    eos,
    operand,
} precedence;

char expr[100] = {0};

int *stack;
int capacity = 1;

int top = -1;

void stackFull()
{
    stack = realloc(stack, sizeof(int) * capacity * 2);
    capacity *= 2;
}

void push(int item)
{
    if (top >= capacity - 1)
        stackFull();

    stack[++top] = item;
}

int pop()
{
    if (top == -1)
    {
        fprintf(stderr, "stack is empty!");
        return ERROR_KEY;
    }
    return stack[top--];
}

precedence getToken(char *symbol, int *n)
{
    *symbol = expr[(*n)++];
    switch (*symbol)
    {
    case '(':
        return lparen;
    case ')':
        return rparen;
    case '+':
        return plus;
    case '-':
        return minus;
    case '/':
        return divide;
    case '*':
        return times;
    case '%':
        return mod;
    case '^':
        return exponentiation;
    case '=':
        return equal;
    case '\0':
        return eos;
    default:
        return operand;
    }
}

int eval(void)
{
    char symbol;
    int n = 0, op1, op2;
    precedence token;

    token = getToken(&symbol, &n);
    while (token != eos)
    {
        if (token == operand)
        {
            push(symbol - '0');
        }
        else
        {
            op2 = pop();
            op1 = pop();
            switch (token)
            {
            case plus:
                push(op1 + op2);
                break;
            case minus:
                push(op1 - op2);
                break;
            case times:
                push(op1 * op2);
                break;
            case divide:
                push(op1 / op2);
                break;
            case mod:
                push(op1 % op2);
                break;
            case exponentiation:
                push(pow(op1, op2));
                break;
            case equal:
                push(op1 == op2 ? 1 : 0);
                break;
            default:
                break;
            }
        }
        token = getToken(&symbol, &n);
    }
    return pop();
}

int main(void)
{
    MALLOC(stack, sizeof(*stack));
    FILE *fp_read = fopen("input5.txt", "r");
    fread(expr, sizeof(char) * 100, 1, fp_read);

    printf("%d", eval());

    return 0;
}