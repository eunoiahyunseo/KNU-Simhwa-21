#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define TRUE 1
#define FALSE 0

#define MAX_TERMS 100

#define MALLOC(p, s)                                \
    if (!((p) = malloc(s)))                         \
    {                                               \
        fprintf(stderr, "error occured in MALLOC"); \
        exit(EXIT_FAILURE);                         \
    }

typedef struct
{
    float coef;
    int expon;
} polynomial;

polynomial terms[MAX_TERMS];
int avail = 0;

int COMPARE(int value1, int value2)
{
    if (value1 < value2)
    {
        return -1;
    }
    else if (value1 == value2)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

void attach(float coefficient, int exponent)
{
    if (avail >= MAX_TERMS)
    {
        fprintf(stderr, "Too many terms in the polynomial\n");
        exit(EXIT_FAILURE);
    }
    terms[avail].coef = coefficient;
    terms[avail++].expon = exponent;
}

void padd(int startA, int finishA, int startB, int finishB, int *startD, int *finishD)
{
    float coefficient;
    avail = *startD;
    while (startA <= finishA && startB <= finishB)
    {
        switch (COMPARE(terms[startA].expon, terms[startB].expon))
        {
        case -1:
            attach(terms[startB].coef, terms[startB].expon);
            startB++;
            break;
        case 0:
            coefficient = terms[startA].coef + terms[startB].coef;
            if (coefficient)
                attach(coefficient, terms[startA].expon);
            startA++;
            startB++;
            break;
        case 1:
            attach(terms[startA].coef, terms[startA].expon);
            startA++;
            break;
        }
    }

    for (; startA <= finishA; startA++)
        attach(terms[startA].coef, terms[startA].expon);

    for (; startB <= finishB; startB++)
        attach(terms[startB].coef, terms[startB].expon);

    *finishD = avail - 1;
}

int main(void)
{
    int i, j, count = 0;
    FILE *fp_read;
    fp_read = fopen("a.txt", "r");

    int startA, finishA, a_num;
    fscanf(fp_read, "%d", &a_num);

    startA = count;
    for (i = 0; i < a_num; i++)
    {
        fscanf(fp_read, "%f %d", &terms[i].coef, &terms[i].expon);
        count++;
    }
    finishA = count - 1;

    fp_read = fopen("b.txt", "r");
    int startB, finishB, b_num;
    fscanf(fp_read, "%d", &b_num);
    startB = count;
    for (i = 0; i < b_num; i++)
    {
        fscanf(fp_read, "%f %d", &terms[startB + i].coef, &terms[startB + i].expon);
        count++;
    }
    finishB = count - 1;

    int startD, finishD;
    startD = count;

    padd(startA, finishA, startB, finishB, &startD, &finishD);

    polynomial terms_2[MAX_TERMS];
    memset(terms_2, 0, sizeof(polynomial) * MAX_TERMS);

    int sizeofInit = finishD - startD + 1;

    for (i = 0; startD <= finishD; startD++, i++)
    {
        terms_2[i].coef = terms[startD].coef;
        terms_2[i].expon = terms[startD].expon;
    }

    memset(terms, 0, sizeof(polynomial) * MAX_TERMS);
    count = 0;
    startA = count;
    for (i = 0; i < sizeofInit; i++)
    {
        terms[i].coef = terms_2[i].coef;
        terms[i].expon = terms_2[i].expon;
        count++;
    }
    finishA = count - 1;

    fp_read = fopen("c.txt", "r");
    fscanf(fp_read, "%d", &b_num);

    startB = count;
    for (i = 0; i < b_num; i++)
    {
        fscanf(fp_read, "%f %d", &terms[startB + i].coef, &terms[startB + i].expon);
        count++;
    }
    finishB = count - 1;

    startD = count;
    padd(startA, finishA, startB, finishB, &startD, &finishD);

    count = 0;
    for (; startD <= finishD; startD++)
    {
        if (terms[startD].expon == 0)
        {
            if (count == 0)
            {
                printf("%.0f", terms[startD].coef);
                count++;
            }
            else
            {
                printf("%+.0f", terms[startD].coef);
                count++;
            }
        }
        else
        {
            if (count == 0)
            {
                printf("%.0fx^%d", terms[startD].coef, terms[startD].expon);
                count++;
            }
            else
            {
                printf("%+.0fx^%d", terms[startD].coef, terms[startD].expon);
                count++;
            }
        }
    }

    fclose(fp_read);
    return 0;
}