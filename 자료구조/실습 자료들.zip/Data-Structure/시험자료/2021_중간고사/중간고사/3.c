#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define TRUE 1
#define FALSE 0

#define MALLOC(p, s)                                \
    if (!((p) = malloc(s)))                         \
    {                                               \
        fprintf(stderr, "error occured in MALLOC"); \
        exit(EXIT_FAILURE);                         \
    }

int main(void)
{
    int number, i;
    int isPrime = TRUE;

    FILE *fp_read = fopen("input3.txt", "r");
    fscanf(fp_read, "%d", &number);

    for (i = 2; i < (number / 2) + 1; i++)
    {
        if (number % i == 0)
        {
            isPrime = 0;
        }
    }

    if (isPrime == 1)
    {
        if (number == 1)
        {
            printf("Not Prime");
        }
        else
        {
            printf("Prime");
        }
    }
    else
    {
        printf("Not Prime");
    }
}