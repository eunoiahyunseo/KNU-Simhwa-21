#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define TRUE 1
#define FALSE 0

#define MALLOC(p, s)                                \
    if (!((p) = malloc(s)))                         \
    {                                               \
        fprintf(stderr, "error occured in MALLOC"); \
        exit(EXIT_FAILURE);                         \
    }

typedef struct node_
{
    int data;
    struct node_ *link;
} node, *nodePointer;

void insert(nodePointer *pPointer, int data)
{
    nodePointer temp;
    MALLOC(temp, sizeof(node));
    temp->data = data;

    if (!*pPointer)
    {
        printf("1\n");
        *pPointer = temp;
        temp->link = NULL;
    }
    else
    {
        nodePointer temp2 = *pPointer;
        nodePointer temp3 = *pPointer;

        while (temp2 != NULL)
        {
            if (temp2->data < data)
            {
                break;
            }

            temp3 = temp2;
            temp2 = temp2->link;
        }

        if (temp2 == *pPointer)
        {
            temp->link = temp2;
            *pPointer = temp;
        }
        else
        {
            temp->link = temp2;
            temp3->link = temp;
        }
    }
}

void invert(nodePointer *pPointer)
{
    nodePointer middle, trail, lead;
    lead = *pPointer;
    middle = NULL;
    trail = NULL;

    while (lead)
    {
        trail = middle;
        middle = lead;
        lead = lead->link;
        middle->link = trail;
    }
    *pPointer = middle;
}

void printNode(nodePointer pPointer)
{
    nodePointer temp = pPointer;
    while (temp != NULL)
    {
        printf("%d ", temp->data);
        temp = temp->link;
    }
    putchar('\n');
}

int main(void)
{
    FILE *fp_read = fopen("input6.txt", "r");
    int value;
    nodePointer head = NULL;

    while (fscanf(fp_read, "%d", &value) != EOF)
    {
        insert(&head, value);
    }

    printNode(head);

    invert(&head);

    printNode(head);

    return 0;
}