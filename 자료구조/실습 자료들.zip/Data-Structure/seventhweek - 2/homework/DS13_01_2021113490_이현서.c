#include <stdio.h>
#include <stdlib.h>

#define MAX_ELEMENTS 200
#define MAX_ARR_SIZE 1000
#define HEAP_FULL(n) (n == MAX_ELEMENTS - 1)
#define HEAP_EMPTY(n) (!n)

typedef struct
{
    int key;
} element;
element heap[MAX_ELEMENTS];
int n = 0;

void iterInorder(element heap[], int size)
{
    int stack[MAX_ELEMENTS];
    int top = -1;
    int i = 1;
    while (1)
    {
        while (size >= i)
        {
            top++;
            stack[top] = i;
            i = i * 2;
        }
        if (top == -1)
            return;

        i = stack[top];
        top--;
        printf("%d ", heap[i].key);
        i = i * 2 + 1;
    }
}

void push(element item, int *n)
{
    int i;
    // 만약에 HEAP이 꽉 찼다면 에러
    if (HEAP_FULL(*n))
    {
        fprintf(stderr, "The heap is full. \n");
        exit(EXIT_FAILURE);
    }

    i = ++(*n);
    while ((i != 1) && (item.key > heap[i / 2].key))
    {
        heap[i] = heap[i / 2];
        i /= 2;
    }
    heap[i] = item;
}

element pop(int *n)
{
    int parent, child;
    element item, temp;
    if (HEAP_EMPTY(*n))
    {
        fprintf(stderr, "The heap is empty. \n");
        exit(EXIT_FAILURE);
    }

    item = heap[1];

    temp = heap[(*n)--];
    parent = 1;
    child = 2;

    while (child <= *n)
    {
        if ((child < *n) && (heap[child].key < heap[child + 1].key))
            child++;
        if (temp.key >= heap[child].key)
            break;
        heap[parent] = heap[child];
        parent = child;
        child *= 2;
    }
    heap[parent] = temp;
    return item;
}

void printLI(int n)
{
    printf("Level Order: ");
    for (int i = 1; i <= n; i++)
    {
        printf("%d ", heap[i].key);
    }
    putchar('\n');
    printf("Inorder: ");
    iterInorder(heap, n);
    putchar('\n');
}

int main(void)
{
    FILE *fp_read = fopen("input.txt", "r");
    int value;
    element newElement = {0};
    int n = 0;
    while (fscanf(fp_read, "%d", &value) != EOF)
    {
        newElement.key = value;
        push(newElement, &n);
    }

    printLI(n);
    pop(&n);
    printLI(n);
    pop(&n);
    printLI(n);

    return 0;
}