#define N 5 //�ڸ���

#include <stdio.h>
#include <math.h>

int onesDigit(int user);
int tensOnesDigit(int user);
int tensDigit(int user);
int hundredsDigit(int user);
int thousandsDigit(int user);
int getDigits(int a, int biggestDigit, int smallestDigit);

int main(void)
{
	printf("onesDigit(234567)\t7\t%d\n", onesDigit(567));
	printf("tensOnesDigit(234567)\t67\t %d\n", tensOnesDigit(234567));
	printf("tensDigit(234567)\t6\t %d\n", tensDigit(567));
	printf("hundredsDigit(234567)\t5\t %d\n", hundredsDigit(234567));
	printf("thousandsDigit(234567)\t4\t %d\n", thousandsDigit(234567));
	puts("");
	printf("getDigits(12345, 0, 0)\t5\t %d\n", getDigits(12345, 0, 0));
	printf("getDigits(12345, 1, 1)\t4\t %d\n", getDigits(12345, 1, 1));
	printf("getDigits(12345, 4, 4)\t1\t %d\n", getDigits(12345, 4, 4));
	printf("getDigits(12345, 2, 0)\t345\t %d\n", getDigits(12345, 2, 0));
	printf("getDigits(12345, 3, 2)\t23\t %d\n", getDigits(12345, 3, 2));

	return 0;
}

int onesDigit(int user)
{
	return user % 10;
}

int tensOnesDigit(int user)
{
	return user % 100;
}

int tensDigit(int user)
{
	return user % 100 / 10;
}

int hundredsDigit(int user)
{
	return user % 1000 / 100;
}

int thousandsDigit(int user)
{
	return user % 10000 / 1000;
}

int getDigits(int a, int biggestDigit, int smallestDigit)
{
	int arr[N] = {
		0,
	};
	for (int i = 0; i < N; i++)
	{
		int modulo = pow(10, i + 1);
		int division = pow(10, i);

		arr[i] = a % modulo / division;
	}

	int sum = 0, count = 0;
	for (int i = smallestDigit; i <= biggestDigit; i++)
		sum += arr[i] * (int)pow(10, count++);

	return sum;
}