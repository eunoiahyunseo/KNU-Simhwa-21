#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>	//sprintf function
#include <string.h> //strtok function

void initMoney(int dollars, int cents, int money[]);
int dollars(int money[]);
int cents(int money[]);
void prettyPrint(int money[], char str[]);
int isGreaterThan(int m1[], int m2[]);
int isEqual(int m1[], int m2[]);

int main(void)
{
	int m1[2], m2[2], m3[2];
	char money[100];
	initMoney(5, -20, m1);
	printf("dollars(m1)\t4\t %d\n", dollars(m1));
	printf("cents(m1)\t80\t %d\n", cents(m1));
	prettyPrint(m1, money);
}

void initMoney(int dollars, int cents, int money[])
{
	// 전체 돈 total
	int total = dollars * 1000 + cents * 10;
	printf("total >> %d\n", total);

	// money[0] = total / 100;
	// money[1] = total % 100;

	// printf("m1[] = {%d, %d}\n", money[0], money[1]);

	money[0] = total / 1000;
	money[1] = (total % 1000) / 10;
}

int dollars(int money[])
{
	return money[0];
}

int cents(int money[])
{
	return money[1];
}

void prettyPrint(int money[], char str[])
{
	// money[] -> m1[] str[] -> money[]

	// sprintf(str, "$%.2lf", money[0] + money[1] / 100.0);
	// printf("%s\n", str);

	sprintf(str, "\"$%d.%d\"", money[0], money[1]);
}

int isGreaterThan(int m1[], int m2[])
{
	// m1,m2�� int, want to cut $ is(character)
	// m1 = strtok(m1, '$');
	// m2 = strtok(m2, '$');

	// printf("m1 : %d m2 : %d\n", m1, m2);

	// if (m1 > m2)
	// 	return 1;
	// else
	// 	return 0;

	if (((m1[0] == m2[0]) && (m1[1] > m2[1])) || (m1[0] > m2[0]))
		return 1;
	return 0;
}

int isEqual(int m1[], int m2[])
{
	if ((m1[0] == m2[0]) && (m1[1] == m2[1]))
		return 1;
	return 0;
}
