#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *a = NULL;
    if (*(&a))
    {
        printf("Hello World!");
    }

    return 0;
}