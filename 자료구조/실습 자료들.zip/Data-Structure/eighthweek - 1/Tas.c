#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h> //sprintf function
#include <math.h>  //round function

void initMoney(int dollars, int cents, int money[]);
int dollars(int money[]);
int cents(int money[]);
void prettyPrint(int money[], char str[]);
int isGreaterThan(int m1[], int m2[]);
int isEqual(int m1[], int m2[]);
void adder(int m1[], int m2[]);
void add(int m1[], int m2[], int m3[]);

int main(void)
{
   int m1[2], m2[2], m3[2];
   char money[100];
   initMoney(5, -20, m1);
   // printf("dollars(m1)\t4\t % d\n", dollars(m1));
   // printf("cents(m1)\t80\t % d\n", cents(m1));
   prettyPrint(m1, money);
   printf("prettyPrint({5,-20})\t$4.80\t % s\n", money);
   initMoney(3, 120, m2);
   prettyPrint(m2, money);
   printf("prettyPrint({3,120})\t$4.20\t % s\n", money);

   // printf("isGreaterThan($4.80, $4.20)\t1\t % d\n",
   //    isGreaterThan(m1, m2));
   // printf("isGreaterThan($4.20, $4.80)\t0\t % d\n",
   //    isGreaterThan(m2, m1));
   // printf("isEqual($4.80, $4.20)\t0\t % d\n", isEqual(m1, m2));
   // printf("isEqual($4.80, $4.80)\t1\t % d\n", isEqual(m1, m1));

   adder(m1, m2);
   prettyPrint(m1, money);
   // printf("adder(m1, m2)\t$9.00\t % s\n", money);

   // add(m1, m2, m3);
   // prettyPrint(m3, money);
   // printf("add(m1, m2, m3)\t$13.20\t % s\n", money);
}

void initMoney(int dollars, int cents, int money[])
{
   // 전체 돈 total
   int total = dollars * 1000 + cents * 10;
   // printf("total >> %d\n", total);

   money[0] = total / 1000;
   money[1] = (total % 1000) / 10;
}

int dollars(int money[])
{
   return money[0];
}

int cents(int money[])
{
   return money[1];
}

void prettyPrint(int money[], char str[])
{
   // m1[] -> money[] money[] -> str[]
   // sprintf(str, "$%d.%d", money[0], money[1]);
   sprintf(str, "$%.2lf", money[0] + (money[1] / 100.0));
}

int isGreaterThan(int m1[], int m2[])
{
   if (((m1[0] == m2[0]) && (m1[1] > m2[1])) || (m1[0] > m2[0]))
      return 1;
   return 0;
}

int isEqual(int m1[], int m2[])
{
   if ((m1[0] == m2[0]) && (m1[1] == m2[1]))
      return 1;
   return 0;
}

void adder(int m1[], int m2[])
{
   int total = 1000 * (m1[0] + m2[0]) + 10 * (m1[1] + m2[1]);
   m1[0] = total / 1000;
   m1[1] = (total % 1000) / 10;
   // m1[1] = (m1[1] + m2[1]) / 100;
   // m1[0] = m1[0] + m2[0] + m1[1];
}

void add(int m1[], int m2[], int m3[])
{
   // m3 = m1 + m2, m1 and m2 untouched

   m3[0] = m1[0] + m2[0];
   m3[1] = m3[0] + m2[1];
}