#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>	//sprintf function
#include <string.h> //strtok function

void initMoney(int dollars, int cents, int money[]);
int dollars(int money[]);
void prettyPrint(int money[], char str[]);
int isGreaterThan(int m1[], int m2[]);
int isEqual(int m1[], int m2[]);

void main(void)
{
	int m1[2], m2[2], m3[2];
	char money[100];

	initMoney(5, -20, m1);
	printf("dollars(m1)\t4\t % d\n", dollars(m1));
	printf("cents(m1)\t80\t % d\n", cents(m1));

	// for (int i = 0; i < 2; i++)
	// printf("m1[%d] = %d\n", i, m1[i]);

	prettyPrint(m1, money);
	printf("prettyPrint({5,-20})\t$4.80\t%s\n", money);
	initMoney(3, 120, m2);
	prettyPrint(m2, money);
	printf("prettyPrint({3,120})\t$4.20\t%s\n", money);

	printf("isGreaterThan($4.80,$4.20)\t1\t%d\n", isGreaterThan(m1, m2));
	printf("isGreaterThan($4.20,$4.80)\t0\t%d\n", isGreaterThan(m2, m1));
}

void initMoney(int dollars, int cents, int money[])
{
	int total = dollars * 100 + cents;

	money[0] = total / 100;
	money[1] = total % 100;

	printf("m1[] = {%d, %d}\n", money[0], money[1]);
}

int dollars(int money[])
{
	return money[0];
}

int cents(int money[])
{
	return money[1];
}

void prettyPrint(int money[], char str[])
{
	// money[] -> m1[] str[] -> money[]
	sprintf(str, "$%.2lf", money[0] + money[1] / 100.0);
	printf("%s\n", str);
}

int isGreaterThan(int m1[], int m2[])
{
	// m1,m2�� int, want to cut $ is(character)
	// m1 = strtok(m1, '$');
	// m2 = strtok(m2, '$');

	printf("m1 : %d m2 : %d\n", m1, m2);

	if (m1 > m2)
		return 1;
	else
		return 0;
}

int isEqual(int m1[], int m2[])
{
	if (m1 == m2)
		return 1;
	else
		return 0;
}
