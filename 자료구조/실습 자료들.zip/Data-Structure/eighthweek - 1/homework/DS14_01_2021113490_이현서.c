#include <stdio.h>
#include <stdlib.h>

typedef struct node_
{
    int key;
    struct node_ *leftChild;
    struct node_ *rightChild;
} node, *treePointer;

treePointer iterSearch(treePointer tree, int k)
{
    while (tree)
    {
        // 만약에 찾은 경우
        if (k == tree->key)
            return tree;
        if (k < tree->key)
            tree = tree->leftChild;
        else
            tree = tree->rightChild;
    }
    return NULL;
}

// 처음에는 null이 들어 올 것이다.
node *modifiedSearch(treePointer tree, int key)
{
    // 만약 tree가 null이라면 그냥 return
    if (!tree)
        return NULL;

    while (tree)
    {
        // 같으면 추가할 필요 없다
        if (key == tree->key)
            return NULL;

        // 만약 추가 하고자 하는 키가 더 작다면
        // 왼쪽으로 가야한다.
        if (key < tree->key)
        {
            // 그러다 만약에 그 leftChild가 null이라면 그냥 추가할 노드를 return한다.
            if (tree->leftChild == NULL)
                return tree;
            tree = tree->leftChild;
        }
        // 만약 추가 하고자 하는 키가 더 크다면
        else
        {
            // 그러다 만약에 그 rightChild가 null이라면 그냥 추가할 노드를 return한다.
            if (tree->rightChild == NULL)
                return tree;
            tree = tree->rightChild;
        }
    }
    return NULL;
}

void insert(treePointer *node, int k)
{
    treePointer ptr;
    // 추가할 노드의 parentNode
    treePointer temp = modifiedSearch(*node, k);
    // node가 null인 경우도 처리를 해주어야 한다. -> head가 null이게 되면 그냥 할당만 하고 반환
    if (temp || !(*node))
    {
        ptr = (treePointer)malloc(sizeof(*ptr));
        ptr->key = k;
        ptr->leftChild = ptr->rightChild = NULL;

        if (*node)
        {
            if (k < temp->key)
                temp->leftChild = ptr;
            else
                temp->rightChild = ptr;
        }
        // 만약에 node가 있지 않다면 그냥 ptr을 만들어서 반환해 줘야 한다.
        else
            *node = ptr;
    }
}

void inorder(treePointer ptr)
{
    if (ptr)
    {
        inorder(ptr->leftChild);
        printf(" %d ", ptr->key);
        inorder(ptr->rightChild);
    }
}

void preorder(treePointer ptr)
{
    if (ptr)
    {
        printf(" %d ", ptr->key);
        preorder(ptr->leftChild);
        preorder(ptr->rightChild);
    }
}

void postorder(treePointer ptr)
{
    if (ptr)
    {
        postorder(ptr->leftChild);
        postorder(ptr->rightChild);
        printf(" %d ", ptr->key);
    }
}

int main(void)
{
    FILE *fp = fopen("input1.txt", "r");
    FILE *fsearch = fopen("input2.txt", "r");

    treePointer head = NULL;

    int key;
    while (!feof(fp))
    {
        fscanf(fp, "%d", &key);
        insert(&head, key);
    }

    printf("Preorer: ");
    preorder(head);
    printf("\n");

    printf("Inorder: ");
    inorder(head);
    printf("\n");

    printf("PostOrder: ");
    postorder(head);
    printf("\n");

    printf("Search: ");
    int find;

    while (!feof(fsearch))
    {
        fscanf(fsearch, "%d", &find);
        if (iterSearch(head, find))
            printf(" 1 ");
        else
            printf(" 0 ");
    }

    fclose(fp);
    fclose(fsearch);

    return 0;
}