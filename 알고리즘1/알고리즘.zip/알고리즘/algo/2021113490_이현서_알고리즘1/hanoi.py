import sys
input = sys.stdin.readline
answer = 0

def hanoi(num, f, s, t):
    if num == 1: print(f'{f}번 기둥에서 {t}번 기둥으로 {num}번 원반 이동')
    else:
        hanoi(num - 1, f, t, s)
        print(f'{f}번 기둥에서 {t}번 기둥으로 {num}번 원판 이동')
        hanoi(num - 1, s, f, t)
        
def solution(N):
    hanoi(N, 1, 2, 3)

if __name__ == '__main__':
    solution(int(sys.argv[1]))