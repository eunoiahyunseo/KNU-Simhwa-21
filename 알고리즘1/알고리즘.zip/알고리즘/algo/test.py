a = [1, 2, 3, 4, 5, 6]
l = 0; r = len(a) - 1
mid = (l + r) // 2
for i in range(mid, l - 1, -1):
    print(a[i])
