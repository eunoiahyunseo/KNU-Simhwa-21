import sys
input = sys.stdin.readline
INF = float('inf')

def find_mcsa(A, l, m, r):
    left_sum = -INF
    sum = 0
    # mid downto low
    for i in range(m, l - 1, -1):
        sum += A[i]
        if sum > left_sum:
            left_sum = sum
            max_left = i
    
    right_sum = -INF
    sum = 0
    for i in range(m + 1, r + 1):
        sum += A[i]
        if sum > right_sum:
            right_sum = sum
            max_right = i
    
    return (max_left, max_right, left_sum + right_sum)

def select_max_msa(msa_list):
    return sorted(msa_list, key = lambda t: t[2])[-1]
    
def find_msa(A, l, r):
    if l == r: return (l, r, A[l])
    mid = (l + r) // 2
    return select_max_msa([
        find_msa(A, l, mid),
        find_msa(A, mid + 1, r),
        find_mcsa(A, l, mid, r)])
    
def msa(A):
    diff = [0] + [A[i + 1] - A[i] for i in range(len(A) - 1)]
    return find_msa(diff, 0, len(diff) - 1)
        
    
if __name__ == '__main__':
    stock_list = [100, 113, 110, 85, 105, 102, 86, 63, 81, 101, 94, 106, 101, 79, 94, 90, 97]
    buy, sell, profit = msa(stock_list)
    print(profit)