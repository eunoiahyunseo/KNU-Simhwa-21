import sys
input = sys.stdin.readline
answer = 0

T = int(input())

# 왼쪽 부분배열의 최댓값과 오른쪽 부분배열의 최댓값과 걸친 부분배열을 비교
# 가장 큰 값이 전체 배열의 최대부분배열의 원소의 합
def rec(A, l, r):
    if l == r:
        if A[l] > 0: return A[l]
        return 0
    
    mid = (l + r) // 2
    # maxl: 왼쪽 부분배열의 최댓값, maxr: 오른쪽 부분배열의 최댓값
    maxl = rec(A, l, mid); maxr = rec(A, mid + 1, r)
    
    sum = 0 
    # maxCenterL: 왼쪽 부분 배열의 최댓값
    maxCenterL = 0
    for i in range(mid, l - 1, -1):
        sum += A[i]
        maxCenterL = max(maxCenterL, sum)
        
    sum = 0
    # maxCenterR: 오른쪽 부분 배열의 최댓값
    maxCenterR = 0
    for i in range(mid + 1, r + 1):
        sum += A[i]
        maxCenterR = max(maxCenterR, sum)
    
    # maxCetnerR + maxCenterL, maxl, maxr중에 큰 것을 취해야 한다.
    return max([maxl, maxr, maxCenterR + maxCenterL])
        
    
def solution():
    for _ in range(T):
        N = int(input())
        # A = list(map(int, input().split()))
        A = list(map(int, input().split()))
        print(A)
        print(rec(A, 0, N - 1))
        
    global answer
    

if __name__ == '__main__':
    solution()