import sys
input = sys.stdin.readline
ans = 0
MOD = 1000000
limit = int(1e7)
sys.setrecursionlimit(limit)

def hanoi(disc, to):
    global ans
    if disc == 0: return
    now = pos[disc]
    sub = ({1, 2, 3} - {now} - {to}).pop()
    if to == now:
        hanoi(disc - 1, to)
    else:
        ans = (ans + (2 ** (disc - 1))) % MOD
        print(ans)
        hanoi(disc - 1, sub)
n = int(input())
f, s, t = map(int, input().split())
pos = [0] * (n + 1)
for j in range(1, 4):
    for i in list(map(int, input().split())):
        pos[i] = j

hanoi(n, pos[n])

print(pos[n])
print(ans)