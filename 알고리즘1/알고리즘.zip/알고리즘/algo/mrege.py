import sys
sys.setrecursionlimit(10**7)

def mergeSort(l):
    if len(l) <= 1: return l
    mid = len(l) // 2
    left = mergeSort(l[:mid]); right = mergeSort(l[mid:])
    return merge(left, right)
    
    
def merge(l1, l2):
    merged = []
    while len(l1) and len(l2):
        if l1[0] <= l2[0]:
            merged.append(l1.pop(0))
        else:
            merged.append(l2.pop(0))
    if len(l1): merged += l1
    else: merged += l2
    return merged
     
list = [3, 1, 5, 7] 
s_list = mergeSort(list)
print(s_list)