import sys
input = sys.stdin.readline
sys.setrecursionlimit(10**6)
answer = 2e9
N = int(input())
W = [list(map(int, input().split())) for _ in range(N)]
start = 0
def dfs(i, visited, cost):
    global answer
    if visited == (1 << N) - 1:
        if W[i][0] != 0:
            answer = min(answer, cost + W[i][0])
        return

    for j in range(len(W[i])):
        if not (visited & 1 << j) and W[i][j] != 0:
            dfs(j, visited | 1 << j, cost + W[i][j])
            
dfs(start, 1 << 0, 0)
print(answer)