import sys
input = sys.stdin.readline
T = int(input())
'''
    행렬의 곱의 최댓값을 구하는 문제랑 비슷한거 같다
    dp[i][j]를 i번째부터 J번째 파일을 합치는데 드는 최솟값이라고 정의하자
    dp[i][i] = fileList[i]
    dp[i][i + 1] = fileList[i] + fileList[i + 1]
    dp[i][j] = min_{i<=k<=j}(dp[i][k] + dp[k + 1][j]) + sum[j]
'''
for _ in range(T):
    sum = 0
    N = int(input())
    fileList = list(map(int, input().split()))
    psum = [0]
    dp = [[0] * 501 for _ in range(501)]
    for f in fileList:
        sum += f
        psum.append(sum)
    
    for d in range(1, N): # 연쇄 행렬 곱 알고리즘에서 depth를 말한다.
        for tx in range(1, N - d + 1):
            ty = tx + d
            dp[tx][ty] = 1e9
            for k in range(tx, ty):
                dp[tx][ty] = min(dp[tx][ty], dp[tx][k] + dp[k + 1][ty] + (psum[ty] - psum[tx - 1]))
    print(dp[1][N])
            
    
    
    
        
    