import sys
input = sys.stdin.readline
t = int(input())
'''
    dp[i][j]를 정의하자
    i번쨰 숫자를 만들기 위해 뒤에 j를 붙여야 하는 경우의 수를 나타낸다.
'''
dp = [[0] * 4 for _ in range(10001)]
dp[1][1] = 1;
dp[2][1] = 1; dp[2][2] = 1
dp[3][1] = 1; dp[3][2] = 1; dp[3][3] = 1
for i in range(4, 10001):
    dp[i][1] = dp[i - 1][1]
    dp[i][2] = dp[i - 2][1] + dp[i - 2][2]
    dp[i][3] = dp[i - 3][1] + dp[i - 3][2] + dp[i -3][3]

for _ in range(t):
    n = int(input())
    print(dp[n][1] + dp[n][2] + dp[n][3])