import sys
from itertools import permutations
from collections import deque
input = sys.stdin.readline
n = int(input())
s = list(map(int, input().split())) + [0] * (3 - n)
dp = [[[0] * 61 for _ in range(61)] for _ in range(61)]
answer = 1e9
def bfs(s):
    global answer
    queue = deque([s])
    while queue:
        ns = queue.popleft()
        a = max(0, ns[0]); b = max(0, ns[1]); c = max(0, ns[2])
        ret = dp[a][b][c]
        if ret != 0 and ns[-1] >= ret:
            continue
        if all(x <= 0 for x in ns[:3]):
            answer = min(ns[-1], answer)
            continue
        dp[a][b][c] = ns[-1]
        for d in permutations([1, 3, 9]):
            t = [ns[i] - d[i] for i in range(n)] + [0] * (3 - n) + [ns[-1] + 1]
            queue.append(t)
bfs(s + [0])
print(answer)