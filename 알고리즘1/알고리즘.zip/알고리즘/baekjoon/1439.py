from itertools import groupby
s = input()
gr= [''.join(g) for k, g in groupby(s)]
a = sum(1 for group in gr if '1' in group)
b = sum(1 for group in gr if '0' in group)
print(a if a <= b else b)