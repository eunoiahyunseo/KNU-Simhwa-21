import sys
from collections import deque
input = sys.stdin.readline
answer = 0

'''
    2 -> 2 * 2
    2 -> 21
    연산을 최소화 하려면 1을 마지막에 추가하는 것을 먼저 수행해야 한다.
'''

def bfs(a, b):
    queue = deque()
    c = 1
    queue.append((a, b, c))
    while queue:
        a, b, c = queue.pop()
        if a == b:
            return c
        if a < b:
            queue.append((a * 10 + 1, b, c + 1))
            queue.append((a * 2, b, c + 1))
    return -1
    
A, B = map(int, input().split())
answer = bfs(A, B)
print(answer)
