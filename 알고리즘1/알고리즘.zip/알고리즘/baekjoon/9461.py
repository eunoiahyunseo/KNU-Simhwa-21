import sys
input = sys.stdin.readline
answer = 0

def solution():
    global answer
    dp = [0, 1, 1, 1]  + [0] * 98
    for i in range(4, 102):
        dp[i] = dp[i - 2] + dp[i - 3]
    N = int(input())
    for _ in range(N):
        print(dp[int(input().rstrip())])
if __name__ == '__main__':
    solution()