import sys
input = sys.stdin.readline
T = int(input())
dp = [0] * 5001
dp[0] = 1 
for i in range(2, 5001):
    for j in range(2, i + 1, 2):
        dp[i] += dp[j - 2] * dp[i - j]
        dp[i] %= int(1e9 + 7)
for _ in range(T):
    L = int(input())
    print(dp[L])
    