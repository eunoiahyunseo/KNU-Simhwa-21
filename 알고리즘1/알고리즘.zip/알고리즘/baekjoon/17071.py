import sys
from collections import deque
input = sys.stdin.readline
MAX = 5*(10**5)
visited = [[-1 for _ in range(MAX + 1)] for _ in range(2)]
N, K = map(int, input().split())
def bfs():
    q = deque()
    q.append((N, 0))
    visited[0][N] = 0
    while len(q):
        n, t = q.popleft()
        flag = t % 2
        for next_n in [n+1, n-1, 2*n]:
            # 한번도 방문한 적이 없다면 갱신해 주어야 한다.
            if 0 <= next_n <= MAX and visited[1 - flag][next_n] == -1:
                visited[1 - flag][next_n] = t + 1
                q.append((next_n, t + 1))
bfs()
answer = -1
t = 0
flag = 0
while K <= MAX:
    if visited[flag][K] != -1:
        # 작기만 하면 어짜피 짝수배 내에 존재하는거니까
        if visited[flag][K] <= t:
            answer = t
            break
    flag = 1 - flag
    t += 1
    K += t
print(answer)