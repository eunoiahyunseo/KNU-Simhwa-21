import sys
input = sys.stdin.readline
n = int(''.join(map(str, sorted(list(map(int, input().rstrip())), reverse=True))))
print(-1 if n % 30 != 0 else n)