import sys
input = sys.stdin.readline
answer = 0
T = int(input()) 
for _ in range(T):
    N = int(input())
    S = sorted([tuple(map(int, input().split())) for i in range(N)], key=lambda x: x[0])
    t = S[0][1]
    for _, q in S:
        if q <= t:
            t = q
            answer+=1
    print(answer)
    answer = 0