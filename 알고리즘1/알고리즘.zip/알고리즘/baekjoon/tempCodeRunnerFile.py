_activity_selector(k, n):
    m = k + 1