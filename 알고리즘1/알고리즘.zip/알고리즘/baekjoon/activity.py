import sys
input = sys.stdin.readline

'''
    s[i]는 i번째 활동에 대한 시작 시간
    f[i]는 i번째 활동에 대한 종료 시간
'''

s = [1, 3, 0, 5, 3, 5, 6, 8, 8, 2, 12]
f = [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]

sf = []
# 일단 정렬하기 위해 튜플로 묶자
for i in range(len(s)):
    sf.append((s[i], f[i]))

sf.sort(key=lambda x: x[0])
sf.sort(key=lambda x: x[1])

answer = []


def recursive_activity_selector(k, n):
    global answer
    m = k + 1
    while m <= n and s[m] < f[k]:
        m += 1
    if m <= n:
        answer.append(sf[m])
        recursive_activity_selector(m, n)
    else:
        return


answer.append(sf[0])
recursive_activity_selector(0, len(sf) - 1)
print(answer)
