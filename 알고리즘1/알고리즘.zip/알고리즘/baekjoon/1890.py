import sys
input = sys.stdin.readline
sys.setrecursionlimit(10 ** 5)
'''
    map에 있는 숫자만큼 오른쪽, 아래로 가는 경우를 생각해보자.    
'''
n = int(input())
map = [list(map(int, input().split())) for _ in range(n)]
dy = [0, 1]
dx = [1, 0]
dp = [[0] * n for _ in range(n)]
def dfs(y, x):
    if y == n - 1 and x == n - 1:
        return 1
    if map[y][x] == 0:
        return 0
    if dp[y][x] != 0:
        return dp[y][x]
    ret = 0
    for i in range(2):
        ny = y + map[y][x] * dy[i]; nx = x + map[y][x] * dx[i]
        if ny >= 0 and ny < n and nx >= 0 and nx < n:
            ret += dfs(ny, nx)
    dp[y][x] = ret
    return dp[y][x]
print(dfs(0, 0))
