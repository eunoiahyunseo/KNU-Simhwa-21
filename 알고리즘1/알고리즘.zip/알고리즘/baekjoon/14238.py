import sys

input = sys.stdin.readline
sys.setrecursionlimit(10 ** 6)

P = ['A', 'B', 'C']
S = input().rstrip();
A, B, C = tuple([S.count(p) for p in P])
T = ""
flag = False
dp = [[[[[False for _ in range(3)] for _ in range(3)] for _ in range(len(S) + 1)] for _ in range(len(S) + 1)] for _ in range(len(S) + 1)]
'''
    ABBCC
    우선 S의 개수에 따라 알파벳을 분배한다.
    그리고 되지 않는 것은 가지를 잘라버린다. 그리고 이대로 구현하면 3^50 TLE가 날 듯 싶다
    dp(memorization)을 적용해주자.
    이것만으로는 시간 초과가 뜬다 dp[prev1][prev2][a][b][c]에 대한 지역문제를
    최적화 하는 과정까지 하자
'''
def dfs(a, b, c, prev1, prev2):
    global T, flag
    if flag: return
    
    if a == 0 and b == 0 and c == 0:
        print(T)
        flag = True
        return
    
    # 해당 경우는 이미 True로 계산되어서 불가능한 경우를 말한다.
    if dp[a][b][c][prev1][prev2]:
        return
    
    dp[a][b][c][prev1][prev2] = True
    
    if a > 0:
        T += 'A'
        dfs(a - 1, b, c, 0, prev1)
        if flag: return
        T = T[:-1]
        
    if b > 0 and prev1 != 1:
        T += 'B'
        dfs(a, b - 1, c, 1, prev1)
        if flag: return
        T = T[:-1]
    
    if c > 0 and prev1 != 2 and prev2 != 2:
        T += 'C'
        dfs(a, b, c - 1, 2, prev1)
        if flag: return
        T = T[:-1]
        
dfs(A, B, C, 0, 0)
if not flag:
    print(-1)