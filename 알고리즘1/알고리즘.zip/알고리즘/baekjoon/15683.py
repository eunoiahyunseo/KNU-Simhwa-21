import sys
import copy
input = sys.stdin.readline
answer = 1e9
N, M = map(int, input().split())
map = [list(map(int, input().split())) for _ in range(N)]
cctv_pos = []
for y in range(N):
    for x in range(M):
        if map[y][x] in (1, 2, 3, 4, 5):
            cctv_pos.append((map[y][x], (y, x)))
cctv_cnt = len(cctv_pos)
dy = [-1, 0, 1, 0]            
dx = [0, 1, 0, -1]
cctv_dir = {1: [(0,), (1,), (2,), (3,)],
            2: [(0, 2), (1, 3)],
            3: [(0, 1), (1, 2), (2, 3), (0, 3)],
            4: [(0, 1, 2), (1, 2, 3), (2, 3, 0), (3, 0, 1)],
            5: [(0, 1, 2, 3)]}
def cctv_stretch(type, dir, pos):
    global map
    for s_dir in cctv_dir[type][dir]:
        y = pos[0]; x = pos[1]
        while(1):
            ny = y + dy[s_dir]; nx = x + dx[s_dir]
            y = ny; x = nx
            if ny < 0 or ny >= N or nx < 0 or nx >= M: break
            if map[ny][nx] == 6: break
            if map[ny][nx] != 0: continue
            map[ny][nx] = '#'
def dfs(idx, p):
    global map, answer
    if idx == cctv_cnt:
        cnt = 0
        for y in range(N):
            cnt += map[y].count(0)
        answer = min(answer, cnt)
        return
    
    type = cctv_pos[idx][0]
    cur_pos = cctv_pos[idx][1]
    for np in range(p, len(cctv_dir[type])):
        back = copy.deepcopy(map)
        cctv_stretch(type, np, cur_pos)
        dfs(idx + 1, 0)
        map = back
dfs(0, 0)
print(answer)