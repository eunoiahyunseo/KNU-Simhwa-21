import sys
import heapq
input = sys.stdin.readline
'''
    데드라인에 맞춰서 오름차순 정렬을 해준다.
'''
N = int(input())
T = [tuple(map(int, input().split())) for _ in range(N)]
T.sort(key = lambda x: x[1], reverse = True)
T.sort(key = lambda x: x[0])

# print(T)
Q = []
heapq.heappush(Q, T[0][1])
answer = T[0][1]
for i in range(1, N):
    if len(Q) >= T[i][0]: # 만약 추가하려는 데드라인이 넘었다면 까봐야 한다.
        if Q[0] < T[i][1]: # 추가하려는게 만약 더 작은것이 존재한다면 빼내고 다시 집어넣는다.
            answer += (T[i][1] - Q[0])
            heapq.heappop(Q)
            heapq.heappush(Q, T[i][1])
    else: # 만약에 그냥 추가할 수 있다면 그냥 추가한다.
        heapq.heappush(Q, T[i][1])
        answer += T[i][1]
print(answer)