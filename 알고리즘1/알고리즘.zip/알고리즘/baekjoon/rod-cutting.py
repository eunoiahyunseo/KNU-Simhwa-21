import sys
input = sys.stdin.readline

p = [0, 1, 5, 8, 9, 10, 17, 17, 20, 24, 30]

answer = -1
len_p = 10


def rodCut(n):
    if r[n] >= 0:
        return r[n]

    if n <= 0:
        return 0
    q = -1
    for i in range(1, min(n, len_p) + 1):
        if rodCut(n - i) + p[i] > q:
            q = rodCut(n - i) + p[i]
            s[n] = i  # 분할할 때 몇으로 분할했는지 판단하기 위함임

    r[n] = q  # 이미 구한 부분문제는 dp배열에 저장해 놓는다.
    return q


def printRotCutSolution(n):
    print(f"answer: {rodCut(n)}")
    while n > 0:
        print(s[n])
        n -= s[n]


n = int(input())
r = [-1] * (n + 1)
s = [-1] * (n + 1)
printRotCutSolution(n)
