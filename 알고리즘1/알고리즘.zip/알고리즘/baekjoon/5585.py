import sys
input = sys.stdin.readline
answer = 0
'''
    1000원을 냈을 때, 받을 잔돈에 포함된 잔돈의 개수를 구하시오
'''
n = 1000 - int(input())
answer += int(n / 500)
n %= 500
answer += int(n / 100)
n %= 100
answer += int(n / 50)
n %= 50
answer += int(n / 10)
n %= 10
answer += int(n / 5)
n %= 5
answer += int(n / 1)
print(answer)