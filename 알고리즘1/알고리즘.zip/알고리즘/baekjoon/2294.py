import sys
input = sys.stdin.readline
sys.setrecursionlimit(10**5)
INF = 1e9 + 7
N, K = map(int, input().split())
C = [int(input()) for _ in range(N)]
'''
    dp[n]을 n을 만들기 위해 필요한 최소한의 동전 갯수라고 하자.
'''
dp = [0] * 10001
answer = INF
def dfs(n):
    tmp = INF
    if n == 0: return 0
    if dp[n] != 0: return dp[n]
    for c in C:
        if n - c >= 0:
            tmp = min(tmp, dfs(n - c) + 1)
    dp[n] = tmp
    return tmp
        
    
answer = dfs(K)
print(-1 if answer >= INF else answer)