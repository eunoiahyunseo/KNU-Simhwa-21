import sys
input = sys.stdin.readline
                
def smith_waterman(seq1, seq2, match=3, mismatch=-2, gap=-2):
    m, n = len(seq1), len(seq2)
    score = [[0 for j in range(n+1)] for i in range(m+1)]
    traceback = [["" for j in range(n+1)] for i in range(m+1)]
    max_score = 0
    max_pos = None
    
    for i in range(1, m+1):
        for j in range(1, n+1):
            match_score = score[i-1][j-1] + (match if seq1[i-1] == seq2[j-1] else mismatch)
            delete = score[i-1][j] + gap
            insert = score[i][j-1] + gap
            
            # Neddleman-wunsch알고리즘과는 다르게 lower_bound를 0으로 설정해야
            # 국소적으로 최적의 DNA 염기 서열을 고를 수 있다.
            score[i][j] = max(match_score, delete, insert, 0)
            
            if score[i][j] == delete:
                traceback[i][j] = "↑"
            if score[i][j] == insert:
                traceback[i][j] = "←"
            if score[i][j] == match_score:
                traceback[i][j] = "↖"
                
            if score[i][j] >= max_score:
                max_score = score[i][j]
                max_pos = (i, j)
    
    alignment1, alignment2 = "", ""
    # max_pos에서 시작해서 가장 큰 value만을 check해야 한다.
    i, j = max_pos
    while traceback[i][j] != "":
        if traceback[i][j] == "↖":
            alignment1 += seq1[i-1]
            alignment2 += seq2[j-1]
            i -= 1; j -= 1
        elif traceback[i][j] == "↑":
            alignment1 += seq1[i-1]
            alignment2 += '-'
            i -= 1
        else:
            alignment1 += '-'
            alignment2 += seq2[j-1]
            j -= 1

    alignment1 = alignment1[::-1]
    alignment2 = alignment2[::-1]
    
    return score, traceback, alignment1, alignment2, max_score


if __name__ == "__main__":
    N = int(input())
    seq1 = input().rstrip()
    M = int(input())
    seq2 = input().rstrip()
    
    _, _, alignment1, alignment2, max_score = smith_waterman(seq1, seq2)
    print(max_score)
    print(alignment1.replace('-', ''))
    print(alignment2.replace('-', ''))
    
