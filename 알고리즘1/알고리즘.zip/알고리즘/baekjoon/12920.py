import sys
input = sys.stdin.readline
N, M = map(int, input().split())
L = []
for i in range(N):
    V, C, K = map(int, input().split())
    sum = 0
    cnt = 0
    while True:
        sum += 2 ** cnt
        if sum <= K:
            L.append([V * (2 ** cnt), (C * (2 ** cnt))])
            cnt += 1
        else:
            v = K - (sum - 2 ** cnt)
            if v != 0:
                L.append([V * v, C * v])
            break

dp = [[0] * (M + 1) for _ in range(len(L) + 1)]

for i in range(1, len(L) + 1):
    weight = L[i - 1][0]
    value = L[i - 1][1]
    for j in range(1, M + 1):
        if j < weight:
            dp[i][j] = dp[i - 1][j]
        else:
            dp[i][j] = max(dp[i - 1][j], dp[i - 1][j - weight] + value)
print(dp[len(L)][M])
