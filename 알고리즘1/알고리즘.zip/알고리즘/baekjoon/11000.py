import sys
import heapq
input = sys.stdin.readline
n = int(input())
T = sorted([tuple(map(int, input().split())) for _ in range(n)], key = lambda x: x[0])
'''
    interval partitioning의 대표적인 문제이다.
    회의의 시작 순서를 기준으로 정렬한다.
    
    만약 두번쨰 회의를 추가하려는데, 시작 시간이 이전 회의의 종료시간보다 빠르다면 새로 회의실을 만들어주어야 한다.
    아니라면 기존의 회의실을 쓰면 된다.
'''
# print(T)

room = []
# 종료시간을 넣는다.
heapq.heappush(room, T[0][1])
for i in range(1, n):
    # max-heap의 맨 위와 비교하는 작업을 해야한다.
    # 만약 T[i][0]이 room[0]보다 작다면 그냥 집어넣는다.
    if T[i][0] < room[0]:
        heapq.heappush(room, T[i][1])
    else:
        heapq.heappop(room)
        heapq.heappush(room, T[i][1])
        
print(len(room))