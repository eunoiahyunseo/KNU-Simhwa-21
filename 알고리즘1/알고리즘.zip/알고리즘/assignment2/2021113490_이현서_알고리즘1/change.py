import sys
sys.setrecursionlimit(10**5); argv = sys.argv
dp = [0] * 100001

def query(n):
    if dp[n] > 0: return dp[n]
    if n < 0: return float('inf')
    if n == 0: return 0
    dp[n] = min(query(n - 2), query(n - 5)) + 1
    return dp[n]

if __name__ == "__main__":
    q = query(int(argv[1]))
    print(-1 if q >= float('inf') else q)