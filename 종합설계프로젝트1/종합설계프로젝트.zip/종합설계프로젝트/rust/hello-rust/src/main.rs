use std::fs::File;

fn main() {
    let f: u32 = File::open("hello.txt");
}