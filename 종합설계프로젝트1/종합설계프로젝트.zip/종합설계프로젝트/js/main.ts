export class MayBe<T> {
    _value: T;
    constructor(value: T) {
        this._value = value;
    }

    static of(value) {
        return new MayBe(value);
    }

    isNothing() {
        return this._value !== null;
    }

    map(f: CallableFunction) {
        return this.isNothing()
            ? MayBe.of(f(this._value as T))
            : MayBe.of(null);
    }

    join() {
        return this.isNothing() ? MayBe.of(null) : this._value;
    }

    chain(f: CallableFunction) {
        return this.map(f).join();
    }
}
