import { MayBe } from "./main";

let res = MayBe.of("George")
    .map((x: string) => x.toUpperCase())
    .map((x: String) => "Mr. " + x);

console.log(res._value);
