# PyCon 2017: Optimizing Pandas Code for Performance

Materials for the PyCon talk by Sofia Heisler

