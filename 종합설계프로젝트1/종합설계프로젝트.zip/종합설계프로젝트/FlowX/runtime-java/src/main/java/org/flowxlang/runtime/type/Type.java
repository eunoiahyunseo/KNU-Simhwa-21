package org.flowxlang.runtime.type;

public abstract class Type {
}