package org.flowxlang.runtime.function.defaults.panic;

public class PanicException extends Exception {
    public PanicException() {
        super("panic exception");
    }
}
