# FlowX
효율적인 데이터 전처리를 위한 예외처리 기법이 포함된 데이터 플로우 기반 시각적 프로그래밍 언어

## 👨🏻‍💻Contributors
- Runtime: [예창언](https://github.com/nsce9806q), [이우령](https://github.com/WooLyung)
- GUI: [박지원](https://github.com/raipen), [이현서](https://github.com/eunoiahyunseo)
