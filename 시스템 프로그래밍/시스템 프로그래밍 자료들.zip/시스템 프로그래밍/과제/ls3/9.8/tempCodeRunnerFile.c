
            else if (!strcmp(name, "multiply"))