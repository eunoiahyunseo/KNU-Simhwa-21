#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct CalculatorNode
{
    int a;
    int b;
    char name[20];
    int (*fptr)(int, int);
    struct CalculatorNode *next;
} node, *pNode;

int add(int a, int b)
{
    return a + b;
}

int sub(int a, int b)
{
    return a - b;
}

int multiply(int a, int b)
{
    return a * b;
}

int divide(int a, int b)
{
    return (int)(a / b);
}

// 계산노드를 생성한다 name에 따 라서 add, sub, multiply, divide 중 하나를 선택한다.
void addNode(pNode *head, int a, int b, char name[], int (*fptr)(int, int))
{
    pNode newNode = (pNode)malloc(sizeof(node));
    newNode->a = a;
    newNode->b = b;
    strcpy(newNode->name, name);
    newNode->fptr = fptr;
    newNode->next = NULL;

    // head가 null이면 head자체를 삽입해주어야 한다.
    if (*head == NULL)
    {
        *head = newNode;
    }
    else
    {
        pNode temp = *head;
        while (temp->next != NULL)
        {
            temp = temp->next;
        }
        temp->next = newNode;
    }
}

// 현재까지 생성된 계산 노드 출력
void printNode(pNode head)
{
    pNode temp = head;
    while (temp != NULL)
    {
        printf("%s >> %d, %d\n", temp->name, temp->a, temp->b);
        temp = temp->next;
    }
}

// 현재까지 생성된 계산 노드의 계산결과 출력
void calcNode(pNode head)
{
    pNode temp = head;
    while (temp != NULL)
    {
        if (strcmp(temp->name, "add") == 0)
        {
            printf("%d + %d = %d\n", temp->a, temp->b, temp->fptr(temp->a, temp->b));
        }
        else if (strcmp(temp->name, "sub") == 0)
        {

            printf("%d - %d = %d\n", temp->a, temp->b, temp->fptr(temp->a, temp->b));
        }
        else if (strcmp(temp->name, "multiply") == 0)
        {
            printf("%d * %d = %d\n", temp->a, temp->b, temp->fptr(temp->a, temp->b));
        }
        else if (strcmp(temp->name, "divide") == 0)
        {
            if (temp->b == 0)
            {
                printf("0으로 나눌 수 없습니다.\n");
            }
            else
            {
                printf("%d / %d = %d\n", temp->a, temp->b, temp->fptr(temp->a, temp->b));
            }
        }
        temp = temp->next;
    }
}

void delNode(pNode *head)
{
    pNode temp, nextNode;
    temp = *head;

    if (*head == NULL)
        return;

    while (temp != NULL)
    {
        nextNode = temp->next;
        free(temp);
        temp = nextNode;
    }

    *head = NULL;
    return;
}

int main(void)
{
    pNode head = NULL;
    int value;
    int operand1, operand2;
    char name[20];

    while (1)
    {
        printf("1: 노드 생성, 2: 계산 노드 출력, 3: 계산 결과 출력, 4: 노드 삭제, 5: 종료 >> ");
        scanf("%d", &value);

        if (value > 5 || value < 1)
        {
            printf("1과 5사이의 수를 입력해주세요.\n");
            continue;
        }
        else if (value == 5)
        {
            printf("프로그램을 종료합니다.");
            break;
        }

        switch (value)
        {
        // 1이면 계산 노를 생성한다.
        case 1:
            printf("operand1, operand2, name을 입력해주세요 : ");
            scanf("%d %d %s", &operand1, &operand2, name);
            if (!strcmp(name, "add"))
            {
                addNode(&head, operand1, operand2, name, add);
            }
            else if (!strcmp(name, "sub"))
            {
                addNode(&head, operand1, operand2, name, sub);
            }
            else if (!strcmp(name, "multiply"))
            {
                addNode(&head, operand1, operand2, name, multiply);
            }
            else if (!strcmp(name, "divide"))
            {
                addNode(&head, operand1, operand2, name, divide);
            }
            break;
            // 2이면 현재까지 생성된 계산 노드를 출력한다.
        case 2:
            printNode(head);
            break;
        case 3:
            calcNode(head);
            break;
        case 4:
            delNode(&head);
            break;
        }
    }

    return 0;
}