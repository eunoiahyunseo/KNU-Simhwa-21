#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <time.h>

void do_ls(char[]);
void dostat(char *, char *);
void show_file_info(char *, struct stat *);
void mode_to_letters(int, char[]);
char *uid_to_name(uid_t);
char *gid_to_name(gid_t);
char *createpath(char *, char[]);
int compareByTime(const void *a, const void *b);
int compareBySize(const void *a, const void *b);

typedef int (*comparefun)(const void *, const void *);

// 구조체를 하나 만들어 주어야 한다.
struct statInfo
{
	char mode[11];
	int nlink;
	char username[100];
	char groupname[100];
	long size;
	time_t mtime;
	char filename[100];
};

char option[100] = {0};
struct statInfo statInfoList[100] = {0};
int countFile = 0;

// option에 따라서 함수 반환을 따로 해야한다.
comparefun compareFunction(char *option)
{
	// printf("option >> %s", option);
	if (!strcmp(option, "-t"))
		return compareByTime;
	else if (!strcmp(option, "-b"))
		return compareBySize;
	else
		return NULL;
}

int compareByTime(const void *a, const void *b)
{
	return ((struct statInfo *)b)->mtime - ((struct statInfo *)a)->mtime;
}

int compareBySize(const void *a, const void *b)
{
	return (int)((long)((struct statInfo *)b)->size - (long)((struct statInfo *)a)->size);
}

void printStatInfo(struct statInfo statInfoList[])
{
	for (int i = 0; i < countFile; i++)
	{
		printf("%s", statInfoList[i].mode);
		printf("%4d ", statInfoList[i].nlink);
		printf("%-8s ", statInfoList[i].username);
		printf("%-8s ", statInfoList[i].groupname);
		printf("%-8ld ", statInfoList[i].size);
		printf("%.12s ", 4 + ctime(&statInfoList[i].mtime));
		printf("%s \n", statInfoList[i].filename);
	}
}

int main(int argc, char *argv[])
{
	// argc가 1인 경우는 ( "./ls3" ) 이렇게 들어온 경우이다. -> 현재 디렉토리의 대해서만 진행한다.
	if (argc == 1)
	{
		do_ls(".");
	}
	// argc != 1인 경우는 ( "./ls3 -t dir" ) 이렇게 들어온 경우이다. -> ( -t dir )를 한 묶음으로 생각한다.
	else
	{
		while (--argc)
		{
			--argc;
			strcpy(option, *++argv);
			do_ls(*++argv);
		}
	}

	return 0;
}

void do_ls(char dirname[])
{
	DIR *dir_ptr;
	struct dirent *direntp;

	if ((dir_ptr = opendir(dirname)) == NULL)
	{
		fprintf(stderr, "ls2: cannot open %s\n", dirname);
	}
	else
	{
		while ((direntp = readdir(dir_ptr)) != NULL)
			dostat(direntp->d_name, dirname);
		closedir(dir_ptr);
		qsort(statInfoList, countFile, sizeof(struct statInfo), compareFunction(option));

		printStatInfo(statInfoList);
	}
}

char *createpath(char *filename, char dirname[])
{
	// ./을 붙이면 된다.
	static char pathName[100];
	memset(pathName, 0, sizeof(char) * 100);
	strcat(pathName, "./");
	strcat(pathName, dirname);
	strcat(pathName, "/");
	strcat(pathName, filename);
	return pathName;
}

void dostat(char *filename, char dirname[])
{
	struct stat info;
	char *joinPath = createpath(filename, dirname);
	// 들어올 수 있는 경로는 dist ./dist /dist
	if (stat(joinPath, &info) == -1)
		perror(filename);
	else
	{
		show_file_info(filename, &info);
	}
}

void show_file_info(char *filename, struct stat *info_p)
{
	char *uid_to_name(), *gid_to_name();
	void mode_to_letters();
	char modestr[11];

	mode_to_letters(info_p->st_mode, modestr);
	strcpy(statInfoList[countFile].mode, modestr);
	statInfoList[countFile].nlink = (int)info_p->st_nlink;
	strcpy(statInfoList[countFile].username, uid_to_name(info_p->st_uid));
	strcpy(statInfoList[countFile].groupname, gid_to_name(info_p->st_gid));
	statInfoList[countFile].size = (long)info_p->st_size;
	statInfoList[countFile].mtime = info_p->st_mtime;
	strcpy(statInfoList[countFile++].filename, filename);
}

void mode_to_letters(int mode, char str[])
{
	strcpy(str, "----------");
	if (S_ISDIR(mode))
		str[0] = 'd'; /* directory? */
	if (S_ISCHR(mode))
		str[0] = 'c'; /* char devices? */
	if (S_ISBLK(mode))
		str[0] = 'b'; /* block device? */

	if (mode & S_IRUSR)
		str[1] = 'r'; /* 3 bits for user */
	if (mode & S_IWUSR)
		str[2] = 'w';
	if (mode & S_IXUSR)
		str[3] = 'x';

	if (mode & S_IRGRP)
		str[4] = 'r'; /* 3 bits for group */
	if (mode & S_IWGRP)
		str[5] = 'w';
	if (mode & S_IXGRP)
		str[6] = 'x';

	if (mode & S_IROTH)
		str[7] = 'r'; /* 3 bits for other */
	if (mode & S_IWOTH)
		str[8] = 'w';
	if (mode & S_IXOTH)
		str[9] = 'x';
}

#include <pwd.h>
char *uid_to_name(uid_t uid)
{
	struct passwd *pw_ptr;
	static char numstr[10];

	if ((pw_ptr = getpwuid(uid)) == NULL)
	{
		sprintf(numstr, "%d", uid);
		return numstr;
	}
	else
		return pw_ptr->pw_name;
}

#include <grp.h>
char *gid_to_name(gid_t gid)
{
	struct group *grp_ptr;
	static char numstr[10];

	if ((grp_ptr = getgrgid(gid)) == NULL)
	{
		sprintf(numstr, "%d", gid);
		return numstr;
	}
	else
		return grp_ptr->gr_name;
}