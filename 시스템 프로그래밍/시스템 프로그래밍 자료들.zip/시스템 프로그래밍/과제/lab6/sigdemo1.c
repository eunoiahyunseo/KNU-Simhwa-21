#include <stdio.h>
#include <unistd.h>
#include <signal.h>

void my_sig_handler(int signum) { printf("hyunseo\n"); }

int main(void) {
    signal(SIGINT, my_sig_handler);
    for(int i = 0;; i++) {
        printf("hello.\n");
        sleep(1);
    }
}
