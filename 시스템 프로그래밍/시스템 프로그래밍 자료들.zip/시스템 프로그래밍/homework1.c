#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>

#define BUFSIZE 1000
#define COPYMODE 0644

int main(int argc, char* argv[]) {
	int in_fd, out_fd, n_chars;

	char buf[BUFSIZE];

	/* check args */
	if(argc != 3) {
		fprintf(stderr, "usage: %s source destination", *argv);
		exit(1);
	}

	/* open files */
	if((in_fd = open(argv[1], O_RDONLY)) == -1)
		/* cannot open sourcefile (error occured in read file)  */
		fprintf(stderr, "Cannot open %s", argv[1]);

	/* creates a new file */
	if((out_fd = creat(argv[2], COPYMODE)) == -1)
		/* cannot create copyfile */
		fprintf(stderr, "Cannt Create file %s", argv[2]);

	// copies an existing file to a new file
	while((n_chars = read(in_fd, buf, BUFSIZE)) > 0)
		/* read sourcefile buf -> by each BUFSIZE size */
		/* if error in write into copyfile using in_fd */
		if(write(out_fd, buf, n_chars) != n_chars)
			fprintf(stderr, "Cannot Write file to %s", argv[2]);


	if(n_chars == -1)
		fprintf(stderr, "Read error from %s", argv[1]);

	if(close(in_fd) == -1 || close(out_fd) == -1)
		fprintf(stderr, "Error closing file");

	return 0;
}