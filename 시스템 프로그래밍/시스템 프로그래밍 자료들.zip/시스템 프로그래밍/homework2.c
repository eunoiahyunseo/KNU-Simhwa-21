#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

#define BUFFSIZE 1000
#define LOOP 5

struct dump {
	int value1;
	int value2;
	char value3[BUFFSIZE];
};

int main(int argc, char *argv[]) {
	struct dump dumpList[5] = { 0 };

	int in_fd;

	if((in_fd = open("data1.bin", O_RDWR | O_CREAT, 0644)) == -1) {
		fprintf(stderr, "Cannot open | create file");
		exit(1);
	}

	for(int i = 0; i < LOOP; i++) {
		printf("put %d data\n", i);
		scanf("%d %d %s", &dumpList[i].value1, &dumpList[i].value2, dumpList[i].value3);
		write(in_fd, dumpList + i, sizeof(struct dump));
	}

	int in_fd2;
	struct dump dumpList2[5] = { 0 };

	if((in_fd2 = open("data1.bin", O_RDWR | O_CREAT, 0777)) == -1) {
		fprintf(stderr, "Cannt open | create file");
		exit(1);
	}

	for(int i = 0; i < LOOP; i++) {
		read(in_fd2, dumpList2 + i, sizeof(struct dump));
		printf("------------- data[%d] --------------\n", i);
		printf("dump.value1 = %d ", dumpList[i].value1);
		printf("dump.value2 = %d", dumpList[i].value2);
		printf("dump.value3 = %s\n", dumpList[i].value3);
	}

	if(close(in_fd) == -1 || close(in_fd2) == -1)
		fprintf(stderr, "Error closing file");

	return 0;
}