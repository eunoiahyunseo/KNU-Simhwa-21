import org.junit.Test;

import static org.junit.Assert.*;

/**
 * @author ihyeonseo
 */
public class CalcTest {

    @Test
    public void testAddFailure() {
        // given
        int value1 = 1;
        int value2 = 2;

        // when
        int result = Calc.add(value1, value2);

        // then
        int expectedOutput = 5;
        assertTrue("Calc sum incorrected", result == expectedOutput);
    }
}