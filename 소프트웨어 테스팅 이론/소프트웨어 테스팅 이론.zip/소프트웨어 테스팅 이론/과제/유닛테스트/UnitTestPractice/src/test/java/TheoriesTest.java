import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertTrue;
import static org.junit.Assume.assumeTrue;

/**
 * @author ihyeonseo
 */

@RunWith(Theories.class)
public class TheoriesTest {
    @Theory
    public void removeThenAddDoesNotChangeSet(
            Set<String> someSet, String str
    ) {
        assumeTrue(someSet != null);
        assumeTrue(someSet.contains(str));
        HashSet<String> copy = new HashSet<>(someSet);
        copy.remove(str);
        copy.add(str);
        assertTrue(someSet.equals(copy));
    }

    @DataPoints
    public static String[] animals = {"ants", "bat", "cat"};

    @DataPoints
    public static Set[] animalSets = {
            new HashSet(Arrays.asList("ant", "bat")),
            new HashSet(Arrays.asList("ant", "cat", "dog", "olk")),
            new HashSet(Arrays.asList("Snap", "Crackle", "Pop"))
    };

}
