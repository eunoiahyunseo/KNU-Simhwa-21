import org.junit.Test;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.*;
import static org.junit.Assume.assumeTrue;
import static org.junit.runners.Parameterized.*;

/**
 * @author ihyeonseo
 */

@RunWith(Parameterized.class)
public class DataDrivenCalcTest {
    public int a, b, sum;

    public DataDrivenCalcTest(int a, int b, int sum) {
        this.a = a;
        this.b = b;
        this.sum = sum;
    }

    @Parameters public static Collection<Object[]> parameters() {
        return Arrays.asList(new Object[][] {{1, 1, 2}, {2, 3, 5}});
    }

    @Test
    public void additionTest() {
        assertTrue("Addition Test", sum == Calc.add(a, b));
    }



}
