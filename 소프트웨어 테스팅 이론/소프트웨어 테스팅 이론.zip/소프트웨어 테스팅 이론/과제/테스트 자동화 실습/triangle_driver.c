#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int triangle(int a, int b, int c); 

/**
 * @brief test driver
 * 
 * triangle_test_cases.txt에서 함수원형, 테스트케이스 정보를 받아서
 * 이에 대한 테스트를 자동으로 돌리고 coverage를 측정
 * 
 * 원형이 달라질 수 있음에 주의
 * 그리고 테스트의 결과가 별도의 파일로 생성되어야 함
 * @return int 
 */
int main()
{
    char *filename = "triangle_test_cases.txt";
    FILE *fp = fopen(filename, "r");

    // parsing function prototype
    char func_proto[100];
    fgets(func_proto, sizeof func_proto, fp);
    
    char *token;
    char *rest = func_proto;

    token = strtok_r(rest, "(,)", &rest);
    
    // return 

    while((token = strtok_r(rest, "(,)", &rest)) != NULL) {
        printf("%s \n", token);
    }
    
    

    
    return 0;
}

