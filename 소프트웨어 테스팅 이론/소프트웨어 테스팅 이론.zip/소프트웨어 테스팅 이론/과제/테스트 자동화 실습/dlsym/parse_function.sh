echo "enter unit function name"
read unitFunction_name

echo "enter test case file name"
read testcaseFile_name

echo "earlier executed test file is removing..."
rm *.gcov *gcda *gcno test_gcov.txt *.out test_driver.c
sleep 2
echo "removed"

# function protocol 
func_proto=""

# declare data, output list
declare -a data_list
declare -a output_list
tc_count=0

while read -r line; do
  # first line is function prototype
  if [ $tc_count -eq 0 ]; then
    func_proto=$line
    # function name
    function_name=$(echo "$func_proto" | awk -F '[(| ]' '{print $2}')
    # argument list (int a, int b, int c) in function protocol
    args_list=$(echo $func_proto | cut -d "(" -f 2 | cut -d ")" -f 1)
    # cut args_list by delimiter ","
    IFS="," read -ra arr <<< "$args_list"
    # argument count in function proto
    args_count="${#arr[@]}"
    tc_count=$(expr $tc_count + 1)
    continue
  fi
  # parsing test number
  tc=$(echo $line | cut -d " " -f 1)

  # parsing test input
  input=$(echo $line | cut -d " " -f 2-$(expr $args_count + 1))

  # echo $input
  
  data_list[$tc]=$input

  # parsing test output
  output=$(echo $line | cut -d " " -f $(expr $args_count + 2))
  output_list[$tc]=$output

  # tc_ount += 1
  tc_count=$(expr $tc_count + 1)
done < $testcaseFile_name

# call unit function with test case and compare with test result
# then print pass, Fail.
# it will be check structural coverage unit function
expr=""

# make expr
for i in "${!data_list[@]}"; do
  expr="${expr}\tif( ${function_name}($(echo "${data_list[i]}" | sed 's/ /, /g')) == ${output_list[i]} )"
  expr="${expr} printf(\"test case $i: pass\\\\n\"); \n"
  expr="${expr}\telse printf(\"test case $i: Fail\\\\n\"); \n\n"
done

# make test_driver.c by epxr which we make earlier
# cat << EOF
cat << EOF > test_driver.c
#include <stdio.h>
#include <stdlib.h>

${func_proto};

int main() {
$(printf '%b' "${expr}" | sed 's/\t/  /g')
  return 0;
}
EOF

# run test_driver with unit function with option gcov to test structural coverage
gcc -fprofile-arcs -ftest-coverage $(echo $unitFunction_name) test_driver.c -o a.out

echo "-----------test executed-----------"
./a.out

# make report file
gcov -b -f $(echo $unitFunction_name) > test_gcov.txt
echo "-----------test result-----------"
cat test_gcov.txt
