int max(char a, int b, char c) {
    if (a >= b && a >= c) {
        return (int)a;
    } else if (b >= c) {
        return (int)b;
    } else {
        return (int)c;
    }
}