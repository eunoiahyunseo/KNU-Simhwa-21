#include <stdio.h>
#include <stdlib.h>

int max(char a, int b, char c);

int main() {
  if( max(1, 3, 2) == 1 ) printf("test case 1: pass\n"); 
  else printf("test case 1: Fail\n"); 

  if( max('A', 55, 7) == 65 ) printf("test case 2: pass\n"); 
  else printf("test case 2: Fail\n"); 

  if( max(3, 9, 1) == 9 ) printf("test case 3: pass\n"); 
  else printf("test case 3: Fail\n"); 

  if( max(5, 5, 5) == 5 ) printf("test case 4: pass\n"); 
  else printf("test case 4: Fail\n"); 

  if( max(6, 0, 1) == 6 ) printf("test case 5: pass\n"); 
  else printf("test case 5: Fail\n"); 

  if( max(2, 2, 1) == 7 ) printf("test case 6: pass\n"); 
  else printf("test case 6: Fail\n"); 
  return 0;
}
