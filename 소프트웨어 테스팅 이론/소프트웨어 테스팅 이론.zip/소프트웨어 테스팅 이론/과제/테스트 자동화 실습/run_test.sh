gcc -o a.out triangle.c triangle_driver.c
./a.out
