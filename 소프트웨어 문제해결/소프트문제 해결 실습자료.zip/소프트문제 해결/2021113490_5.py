from random import *

#문제 1

random_number = randint(1, 3)

if random_number == 1:
    print("가위")
elif random_number ==2:
    print("주먹")
elif random_number == 3:
    print("보")

#문제 2

random_number2 = randint(1, 10)
if random_number2 <= 5:
    print("가위")
elif random_number2 > 5 and random_number2 <= 8:
    print("바위")
elif random_number2 > 8 and random_number2 <= 10:
    print("보")


#문제 3

CNT = 100
for i in range(CNT + 1):
    for j in range(CNT - i + 1):
        percentage_100 = 3 * i + 5 * j + 2 * (CNT - i - j)
        if percentage_100 == 4 * CNT:
            a = round(i / 100, 2)
            b = round(j / 100, 2)
            c = round((CNT / 100) - a - b, 2)
            percentage = (0.3 * a + 0.5 * b + 0.2 * c) * 100
            print("(가위) >> %.2f (바위) >> %.2f (보) >> %.2f (이길 확률) >> %.2f 퍼센트" %(a, b, c, percentage))
    


