a = "hello, world!"
if not "," in a:
    print(", 없어")
else:
    print(", 있어")