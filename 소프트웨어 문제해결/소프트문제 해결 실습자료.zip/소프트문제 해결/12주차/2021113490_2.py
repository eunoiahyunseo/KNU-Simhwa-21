jnymd = input("주민등록번호 년원일 : ")
a_1 = int(jnymd[:2])
a_2 = int(jnymd[2:4])
a_3 = int(jnymd[4:6])

if a_2 > 12 or a_2 < 1:
    print("주민등록번호의 월 형식이 잘못되었습니다.")
elif a_3 > 31 or a_3 < 1:
    print("주민등록번호의 일 형식이 잘못되었습니다.")
else:
    b = input("성별 표시 : ")
    print(jnymd, b, sep="-")
