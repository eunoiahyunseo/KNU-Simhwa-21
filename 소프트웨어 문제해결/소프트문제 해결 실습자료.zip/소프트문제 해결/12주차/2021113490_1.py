a = input("주민등록번호 년원일 : ")

age  = 2021 - (int(a[:2]) + 1900) + 1
print(f"나이 : {age}")
