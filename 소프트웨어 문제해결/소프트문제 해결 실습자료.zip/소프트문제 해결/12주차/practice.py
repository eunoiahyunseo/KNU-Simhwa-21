import turtle as t

rx = [0] * 10
ry = [0] * 10
move_cnt = 0


def move_robot(action):
    t.clear()
    #입력(action 값)에 따른 청소기 이동 코드
    global move_cnt
    if action == 0:
        t.penup()
        t.goto(rx[0], ry[0])
        t.pendown()
        for i in range(move_cnt - 1):
            t.goto(rx[i + 1], ry[i + 1])
            
            
    elif action == 1:
        t.penup()
        t.goto(rx[move_cnt - 1], ry[move_cnt - 1])
        t.pendown()
        
        for i in range(move_cnt - 1):
            t.goto(rx[move_cnt - 2 - i], ry[move_cnt - 2 - i])
            
    elif action == 2:
        t.penup()
        t.goto(rx[0], ry[0])
        t.pendown()
        t.goto(rx[move_cnt - 1], ry[move_cnt - 1])
        
        
    elif action == 3:
        t.penup()
        t.goto(rx[move_cnt - 1], ry[move_cnt - 1])
        t.pendown()
        t.goto(rx[0], ry[0])
    
    
def clicked(x, y):
    #청소기 위치 저장
    global move_cnt
    rx[move_cnt] = x
    ry[move_cnt] = y
    move_cnt += 1

    
    
def list_clear():
    global move_cnt
    print(move_cnt)
    print(rx)
    print(ry)
    
    
    del rx[1:move_cnt]
    del ry[1:move_cnt]
    move_cnt = 1
    t.penup()
    t.clear()
    t.goto(rx[0], ry[0])
    
#저장된 클릭 순서대로 경로를 이동
def key_SP():
    move_robot(0)
    
    
#저장된 클릭 순서의 역순대로 경로를 이동
def key_BS():
    move_robot(1)
    
    
#처음 위치에서 마지막 위치로 최단 거리를 이동
def key_s():
    move_robot(2)
    
    
#마지막 위치에서 처음위치로 최단거리 이동
def key_r():
    move_robot(3)
    
#저장된 경로를 모두 지운다
def key_e():
    list_clear()
    

    
t.setup(500, 600)
s = t.Screen()
t.hideturtle()



t.speed(6)
t.penup()
clicked(-265, 265)
t.goto(-265, 265)
t.showturtle()

s.onkey(key_SP, "space")
s.onkey(key_BS, "BackSpace")
s.onkey(key_s, "s")
s.onkey(key_r, "r")
s.onkey(key_e, "e")
s.onscreenclick(clicked)
s.listen()
t.mainloop()

