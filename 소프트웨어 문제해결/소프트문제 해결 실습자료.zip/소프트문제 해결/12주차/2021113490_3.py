jnymd = input("주민등록번호 년원일 : ")
a_1 = int(jnymd[:2])
a_2 = int(jnymd[2:4])
a_3 = int(jnymd[4:6])

mfd = {9:1800, 0:1800, 1:1900, 2:1900,
        3:2000, 4:2000, 5:1900, 6:1900,
        7:2000, 8:2000}


if a_2 > 12 or a_2 < 1:
    print("주민등록번호의 월 형식이 잘못되었습니다.")
elif a_3 > 31 or a_3 < 1:
    print("주민등록번호의 일 형식이 잘못되었습니다.")
else:
    b = int(input("성별 표시 : "))
    if b%2 == 1:
        if b == 5:
            print(f"{mfd[b]}년대 태어난 외국인 남성입니다.")
        elif b == 7:
            print(f"{mfd[b]}년대 태어난 외국인 남성입니다.")
        else:
            print(f"{mfd[b]}년대 태어난 남성입니다.")
    else:
        if b == 6:
            print(f"{mfd[b]}년대 태어난 외국인 여성입니다.")
        elif b == 8:
            print(f"{mfd[b]}년대 태어난 외국인 여성입니다.")
        else:
            print(f"{mfd[b]}년대 태어난 여성입니다.")