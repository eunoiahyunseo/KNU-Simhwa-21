# #상보적 방식 (A->T, T->A, G->C, C->G)
# #역순 방식
# #상보적 역순 방식


# def comp(seq):
#     comp_dict = {
#         'A':'T',
#         'T':'A',
#         'C':'G',
#         'G':'C'
#     }

#     seq_comp = ""

#     for i in seq:
#         seq_comp.join(comp_dict[i])

#     print(seq_comp)
#     return seq_comp

# def rev(seq):
#     # seq_rev = sorted(seq, reverse=True)
#     seq_rev = ""
#     length = len(seq)
#     while length >= 0:
#         seq_rev.join(seq[length - 1])
#         length -= 1


#     return seq_rev

# def rev_comp(seq):
#     comp(seq)
#     return rev(seq)    


# src = input("DNA sequence : ")
# print(src)
# count = 0
# is_in = False
# for k in src:
#     if k in 'ATGC':
#         count += 1
#     if count == len(src):
#         is_in = True
# if is_in:
#     cnvt = int(input("1(comp), 2(Rev), 3(Rev_Comp): "))
#     if cnvt <= 3 and cnvt >= 1:
#         if (cnvt == 1):
#             rst = comp(src)
#         elif (cnvt == 2):
#             rst = rev(src)

#         elif (cnvt == 3):
#             rst = rev_comp(src)
        
#         print(src, "->", rst)

#     else:
#         print('1(Comp), 2(Rev), 3(Rev_Comp)!!')
# else:
#     print("ATGC가 src안에 들어가게 문자열을 입력해 주세요")

# import turtle as t

# def draw_pos(x,y):
#     t.clear()
#     t.setpos(x,y)
#     t.stamp()

#     hl = -(t.window_height() / 2)

#     tm = 0
#     while True:
#         y = y-(9.81/2*tm*tm)
#         t.goto(x,y)
#         t.stamp()
#         if y < hl:
#             break
#         tm += 0.3


# t.setup(500,600)
# t.shape("circle")
# t.shapesize(0.3,0.3,0)
# t.penup()
# s = t.Screen()


# s.onscreenclick(draw_pos)
# s.listen()

# t.mainloop()


import turtle as t
import math
tm = 0.3
ux = 0
uy = 0
dx = 0
dy = 0
g = 0.8
velo = 0
ang = 0

def draw_pos(x, y):

    tm = 0.3
    ux = 0
    uy = 0
    dx = 0
    dy = 0
    g = 9.8
    velo = 0
    ang = 0
    velo = t.numinput("입력", "속도 : ", 50, 10, 100)
    ang = math.radians(t.numinput("입력", "각도 : ", 45, 0, 360))

    t.clearstamps()
    t.hideturtle()
    t.setpos(x, y)
    t.showturtle()
    t.stamp()

    hl = -(t.window_height() / 2)
    ux = velo * math.cos(ang)
    uy = velo * math.sin(ang)

    while True:
        x_distance = x + ux * tm
        y_distance = y + uy * tm - 1/2 * g * tm * tm
        t.goto(x_distance, y_distance)

        if y > hl:
            t.stamp()
        else:
            break

    
        tm += 0.3


t.setup(600, 600)
t.shape("circle")
t.shapesize(0.3, 0.3, 0)
t.penup()

s = t.Screen()
s.onscreenclick(draw_pos)
s.listen()
t.mainloop()
