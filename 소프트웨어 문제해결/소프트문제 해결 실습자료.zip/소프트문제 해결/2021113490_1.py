import sys, math
a1, a2, b1, b2, c1, c2 = map(int, input("세 점을 입력해주세요 : ").split())

def point_and_slope_to_line(p, s): # ax + by + c = 0 꼴의 방정식을 배열에다 저장한다.
    linear = []
    if s == sys.float_info.epsilon / 10 ** 100:
        a = 1
        b = 0
        c = -p[0]
        linear.append(a)
        linear.append(b)
        linear.append(c)
        return linear
    else:
        a = -s
        b = 1
        c = -((a * p[0]) + (b * p[1]))
        linear.append(a)
        linear.append(b)
        linear.append(c)
        return linear
    
def same_lineQ(m1, m2):
    return (m1[0] == m2[0] and m1[1] == m2[1] and m1[2] == m2[2])
    
p1 = [a1, a2]
p2 = [b1, b2]
p3 = [c1, c2]

m1 = (b2 - a2) / (b1 - a1)
m2 = (c2 - a2) / (c1 - a1)
m3 = (c2 - b2) / (c1 - b1)

linear_1 = point_and_slope_to_line(p1, m1)
linear_2 = point_and_slope_to_line(p1, m2)
if same_lineQ(linear_1, linear_2):
    print("yes")
else:
    print("no") 


