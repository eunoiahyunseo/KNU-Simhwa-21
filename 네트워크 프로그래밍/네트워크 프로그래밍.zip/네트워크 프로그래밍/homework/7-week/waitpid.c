#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
	int status;
	pid_t pid=fork();
	
	if(pid==0)
	{
		sleep(15);
		return 24;   	
	}
	else
	{
        /**
         * @brief waitpid
         * @param pid 
         * 이는 종료를 확인하고자 하는 자식 프로세스의 ID를 전달 이를 대신해서 -1를
         * 전달하면 wait과 마찬가지로 임의의 자식 프로세스가 종료되기를 기다린다.
         * @param options
         * WNOHANG을 인자로 전달하면 종료된 자식 프로세스가 존재하지 않아도
         * 블로킹 상태에 있지 않고, 0을 반환하면서 함수를 빠져 나옵니다.
         */
		while(!waitpid(-1, &status, WNOHANG))
		{
			sleep(3);
			puts("sleep 3sec.");
		}

		if(WIFEXITED(status))
			printf("Child send %d \n", WEXITSTATUS(status));
	}
	return 0;
}

