#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

void error_handling(char *message);

int main(int argc, char *argv[]) {
    int serv_sock, clnt_sock;

    struct sockaddr_in serv_addr;
    struct sockaddr_in clnt_addr;
    
    socklen_t clnt_addr_size;


    if(argc != 2) {
        printf("Usage : %s <port>\n", argv[0]);
		exit(1);
    }
    
    // socket의 첫번째, 두번쨰 인자로 프로토콜을 알 수 있음으로 3번째에는 0을 적어준다.
    if((serv_sock = socket(PF_INET, SOCK_STREAM, 0)) == -1) {
        error_handling("socket() error");
    }

    memset(&serv_addr, 0, sizeof(serv_addr));
    // IPV4 주소 체계를 사용하기 쉽게 하기 위해 sockaddr_in 구조체를 사용함
    serv_addr.sin_family=AF_INET;
    // byte로 변환
    serv_addr.sin_addr.s_addr=htonl(INADDR_ANY);
    serv_addr.sin_port=htons(atoi(argv[1]));

    if(bind(serv_sock, (struct sockaddr*) &serv_addr, sizeof(serv_addr)) == -1) {
        error_handling("bind() error");
    }

    if(listen(serv_sock, 5) == 1) {
        error_handling("listen() error");
    }

    clnt_addr_size = sizeof(clnt_addr);
    clnt_sock = accept(serv_sock, (struct sockaddr *) &clnt_addr, &clnt_addr_size);
    
    if(clnt_sock==-1)
		error_handling("accept() error");  
	
    char message[1500] = {0};

    // read 
    read(clnt_sock, message, sizeof(message));
    printf("Message from client: %s\n", message);
    strcat(message, " (from server)");

    // write
    write(clnt_sock, message, sizeof(message));
    
    close(clnt_sock); close(serv_sock);
    return 0;
}

void error_handling(char *message)
{
	fputs(message, stderr);
	fputc('\n', stderr);
	exit(1);
}
