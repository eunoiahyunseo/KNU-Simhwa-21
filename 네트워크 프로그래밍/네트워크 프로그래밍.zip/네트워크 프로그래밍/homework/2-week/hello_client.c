#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

void error_handling(char *message);

int main(int argc, char* argv[])
{
	int sock;
	struct sockaddr_in serv_addr;
	
	if(argc!=3){
		printf("Usage : %s <IP> <port>\n", argv[0]);
		exit(1);
	}
	
	if((sock=socket(PF_INET, SOCK_STREAM, 0)) == -1) {
		error_handling("socket() error");
    }
	
	memset(&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family=AF_INET;
	serv_addr.sin_addr.s_addr=inet_addr(argv[1]);
	serv_addr.sin_port=htons(atoi(argv[2]));
		
	if(connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr))==-1) 
		error_handling("connect() error!");
	
    printf("Connect!\n");

	char message[] = "2021113490, Hyunseo Lee";
    char receiveMessage[1500] = {0};
    
    // write
    write(sock, message, sizeof(message));

    // read
    // int read_len, str_len = 0, idx = 0;
    // while((read_len = read(sock, &receiveMessage[idx++], 1))) {
    //     if(read_len == -1) {
    //         error_handling("read() error!");
    //         break;
    //     }
    //     str_len += read_len;
    // }

    read(sock, receiveMessage, sizeof(receiveMessage));
    int str_len = strlen(receiveMessage);

    printf("%s\n", receiveMessage);
    printf("Function read call count: %d\n", str_len);
    
	close(sock);
	return 0;
}

void error_handling(char *message)
{
	fputs(message, stderr);
	fputc('\n', stderr);
	exit(1);
}
