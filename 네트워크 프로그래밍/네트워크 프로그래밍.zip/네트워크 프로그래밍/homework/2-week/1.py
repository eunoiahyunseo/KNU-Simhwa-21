from itertools import product
from collections import defaultdict

low, high = map(int, input().split())

memo = defaultdict(list)
for i in range(1, 19):
    for tup in product(range(1, 10), repeat=i):
        num = int(''.join(map(str, tup)))
        digit_prod = 1
        for j in tup:
            digit_prod *= j
        self_prod = num * digit_prod
        if self_prod < 10**18:
            memo[self_prod].append(num)

memo = dict(sorted(memo.items()))

count = 0
for key in memo:
    if low <= key <= high:
        count += len(memo[key])

print(count)
