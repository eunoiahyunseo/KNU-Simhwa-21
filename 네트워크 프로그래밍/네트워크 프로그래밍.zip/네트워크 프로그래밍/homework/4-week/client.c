#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define BUF_SIZE 1024
void error_handling(char *message);

int main(int argc, char *argv[])
{
	int sock;
    // BUF_SIZE를 넘어가면 메시지를 보내지 못하게 해놓는다.
	char operate_msg[BUF_SIZE];
	struct sockaddr_in serv_adr;
	if(argc!=3) {
		printf("Usage : %s <IP> <port>\n", argv[0]);
		exit(1);
	}
	
	sock=socket(PF_INET, SOCK_STREAM, 0);   
	if(sock==-1)
		error_handling("socket() error");
	
	memset(&serv_adr, 0, sizeof(serv_adr));
	serv_adr.sin_family=AF_INET;
	serv_adr.sin_addr.s_addr=inet_addr(argv[1]);
	serv_adr.sin_port=htons(atoi(argv[2]));
	
	if(connect(sock, (struct sockaddr*)&serv_adr, sizeof(serv_adr))==-1)
		error_handling("connect() error!");
	
	printf("Connected to server.....\n");

	printf("Operand count: ");
    int operand_cnt;
	scanf("%d", &operand_cnt);
    // char형으로 바꿔주어야 함, 1byte만 할당한다고 했으므로
    operate_msg[0] = (char)operand_cnt;
    write(sock, operate_msg, 1);
	
	for(int i = 0; i < operand_cnt; i++)
	{
		printf("Operand %d: ", i + 1);
		scanf("%d", (int*)&operate_msg[i * 4 + 1]);
	}

    // '\n'을 수용하기 위함
	fgetc(stdin);
	fputs("Operator: ", stdout);
    
    // 맨 마지막에 이제 operator를 scan받아야 한다.
	scanf("%c", &operate_msg[operand_cnt * 4 + 1]);

    // 1 + operand_cnt * (sizeof int) + 1
	write(sock, operate_msg, operand_cnt * 4 + 2);
    // printf("operator: %d\n", operate_msg[0]);
    // printf("msg1: %d\n", operate_msg[1]);
    // printf("msg2: %d\n", operate_msg[5]);
    // printf("operand: %c\n", operate_msg[9]);

    int result;
    // 서버로부터 계산된 결괏값을 받아 들여야 한다.
	read(sock, &result, sizeof(int));

	printf("Operation result: %d \n", result);

	close(sock);
	return 0;
}

void error_handling(char *message)
{
	fputs(message, stderr);
	fputc('\n', stderr);
	exit(1);
}