#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define BUF_SIZE 1024
void error_handling(char *message);
int calculate(int opnum, char opnds[], char oprator);

int main(int argc, char *argv[])
{
	int serv_sock, clnt_sock;
	struct sockaddr_in serv_adr, clnt_adr;
	socklen_t clnt_adr_sz;
	if(argc!=2) {
		printf("Usage : %s <port>\n", argv[0]);
		exit(1);
	}
	
	serv_sock=socket(PF_INET, SOCK_STREAM, 0);   
	if(serv_sock==-1)
		error_handling("socket() error");
	
	memset(&serv_adr, 0, sizeof(serv_adr));
	serv_adr.sin_family=AF_INET;
	serv_adr.sin_addr.s_addr=htonl(INADDR_ANY);
	serv_adr.sin_port=htons(atoi(argv[1]));

	if(bind(serv_sock, (struct sockaddr*)&serv_adr, sizeof(serv_adr))==-1)
		error_handling("bind() error");
	if(listen(serv_sock, 5)==-1)
		error_handling("listen() error");	
	clnt_adr_sz=sizeof(clnt_adr);
    clnt_sock=accept(serv_sock, (struct sockaddr*)&clnt_adr, &clnt_adr_sz);	

    printf("Client connected\n");
    int operand_cnt = 0;
    read(clnt_sock, &operand_cnt, 1);
    char operator_info[BUF_SIZE];

    int rec_len = 0;
    // TCP에서의 데이터의 경계성이 없다는 문제 때문에
    // operand_cnt * 4 + 1보다 rec_len이 작은동안 진행해야 한다.
    // 그 이유는 operand_cnt * 4 + 1만큼을 아직 덜 읽었기 때문이다.
    while((operand_cnt * 4 + 1) > rec_len)
        rec_len += read(clnt_sock, &operator_info[rec_len], BUF_SIZE - 1);

    // server에서 계산된 결과
    int calc_result = 0;
    calc_result = calculate(operand_cnt, operator_info + 1, operator_info[rec_len - 1]);

    // 이제 다시 클라이언트로 서버에서 계산한 결과를 보내야 한다.
    write(clnt_sock, &calc_result, sizeof(calc_result));

    close(clnt_sock);
	close(serv_sock);
	return 0;
}

int calculate(int opnum, char opnds[], char op)
{
	int result=opnds[0], i;
	
	switch(op)
	{
	case '+':
		for(i=1; i<opnum; i++) result+=opnds[i * 4];
		break;
	case '-':
		for(i=1; i<opnum; i++) result-=opnds[i * 4];
		break;
	case '*':
		for(i=1; i<opnum; i++) result*=opnds[i * 4];
		break;
	}
	return result;
}

void error_handling(char *message)
{
	fputs(message, stderr);
	fputc('\n', stderr);
	exit(1);
}