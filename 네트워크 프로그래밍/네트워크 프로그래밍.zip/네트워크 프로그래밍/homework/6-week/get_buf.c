#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
void error_handling(char *message);

int main(int argc, char *argv[])
{
	int sock;  
	int snd_buf, rcv_buf, state;
	socklen_t len;
	
    // tcp socket
	sock=socket(PF_INET, SOCK_STREAM, 0);	

	len = sizeof(snd_buf);
    // tcp socket의 SNDBUF(송신 버퍼)의 크기를 get해온다. (기본적인 소켓의 옵션은 SOL_SOCKET)
    // len은 네 번쨰 매개변수로 전달된 주소 값의 버퍼 크기를 담고 있다 여기서는 int형 4byte
	state=getsockopt(sock, SOL_SOCKET, SO_SNDBUF, (void*)&snd_buf, &len);
	if(state)
		error_handling("getsockopt() error");
	
	len=sizeof(rcv_buf);
	state=getsockopt(sock, SOL_SOCKET, SO_RCVBUF, (void*)&rcv_buf, &len);
	if(state)
		error_handling("getsockopt() error");
	
    // 소켓이 만들어지면서 자동으로 할당되어 진다. 우린 그저 설정된 값들을 가져온 것일뿐
	printf("Input buffer size: %d \n", rcv_buf);
	printf("Outupt buffer size: %d \n", snd_buf);
	return 0;
}

void error_handling(char *message)
{
	fputs(message, stderr);
	fputc('\n', stderr);
	exit(1);
}