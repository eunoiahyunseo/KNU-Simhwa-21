#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
	int status;
	pid_t pid=fork();
	
	if(pid==0)
	{
		return 3;   	
	}
	else
	{
		printf("Child PID: %d \n", pid);
		pid=fork();
		if(pid==0)
		{
			exit(7);
		}
		else
		{
			printf("Child PID: %d \n", pid);

            // 자식 프로세스의 종료를 확인해서 좀비 프로세스로 남지 않는다.
            // 그리고 return 3에서 자식 프로세스에서 리턴된 3값이 WIFEXITED(status)의 반환값으로 나온다.
			wait(&status);
			if(WIFEXITED(status))
				printf("Child send one: %d \n", WEXITSTATUS(status));

            // 7
			wait(&status);
			if(WIFEXITED(status))
				printf("Child send two: %d \n", WEXITSTATUS(status));

			sleep(30);
		}
	}
	return 0;
}