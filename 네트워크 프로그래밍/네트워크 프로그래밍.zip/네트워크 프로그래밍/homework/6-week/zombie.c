#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
	pid_t pid = fork();
	
	if(pid==0)
	{
		puts("Hi I'am a child process");
	}
	else
	{
		printf("Child Process ID: %d \n", pid);
        // 부모 프로세스가 30초 쉴때 child process는 zombie process가 된다(Z*)
		sleep(30);
	}

	// 부모 프로세스가 wait을 통해 자식 프로세스의 exit을 확인 해주어야 자식 프로세스가 좀비 프로세스가 되지 않는다.
	// 만약 좀비 프로세스가 되더라도 부모 프로세스가 종료되면 자식 좀비 프로세스는 자연스레 종료된다.
	if(pid==0)
		puts("End child process");
	else
		puts("End parent process");
	return 0;
}
