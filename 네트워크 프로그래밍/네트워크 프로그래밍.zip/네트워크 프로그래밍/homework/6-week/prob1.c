#include <stdio.h>
#include <unistd.h>

int main() {
    // fork() 자식 프로세스인 경우 return 0인 경우만  || -> 이후의 fork()가 호출 될 것이다.

    if(fork() || fork())
        fork();

    // a c b c
    printf("1 ");
    return 0;
}