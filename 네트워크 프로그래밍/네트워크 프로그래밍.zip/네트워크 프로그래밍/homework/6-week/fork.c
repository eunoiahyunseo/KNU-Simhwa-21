#include <stdio.h>
#include <unistd.h>
int gval=10;

int main(int argc, char *argv[])
{
	pid_t pid;
	int lval=20;
	gval++, lval+=5;
	
	pid=fork();		

    // 자식 프로세스 인 경우
	if(pid==0)
		gval+=2, lval+=2;
	else // 부모 프로세스 인 경우
		gval-=2, lval-=2;
	
    // gval과 lval은 fork된 시점으로부터 다른 메모리 영역에 할당되기 때문에, 따로 계산된다.
	if(pid==0)
		printf("Child Proc: [%d, %d] \n", gval, lval);
	else
		printf("Parent Proc: [%d, %d] \n", gval, lval);
	return 0;
}