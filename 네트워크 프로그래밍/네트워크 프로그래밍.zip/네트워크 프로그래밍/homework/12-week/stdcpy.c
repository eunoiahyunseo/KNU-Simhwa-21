#include <stdio.h>
#define BUF_SIZE 3

/**
 * @brief 
 * 표준 입쳘력 함수를 이용해서 버퍼링 기반의 파일 복사를 진행한다
 * 300메가 바이트 이상의 파일을 대사응로 테스트 시 syscpy.c와 속도
 * 차이가 극명하게 나타난다.
 */
int main(int argc, char *argv[])
{
	FILE *fp1;
	FILE *fp2;
	char buf[BUF_SIZE];
	
	fp1 = fopen("news.txt", "r");
	fp2 = fopen("cpy.txt", "w");

	while(fgets(buf, BUF_SIZE, fp1) != NULL)
		fputs(buf, fp2); 

	fclose(fp1);
	fclose(fp2);
	return 0;
}