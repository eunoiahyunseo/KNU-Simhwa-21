#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <signal.h>
#include <sys/types.h>
#include <unistd.h>

#define PORT 9000
#define MAX_MSG_LEN 100
#define TTL 64

void error_handling(char *message);

int main(int argc, char *argv[]) {
    int sockfd;
    struct sockaddr_in server_addr, client_addr;
    pid_t pid;

    int time_live = TTL; // socket multicast ttl
    int option = 1; // so_reuseport option

    struct ip_mreq join_adr;

    if(argc!=4) {
		printf("Usage : %s <GroupIP> <PORT> <UserName>\n", argv[0]);
		exit(1);
	}

    // Create socket
    sockfd = socket(PF_INET, SOCK_DGRAM, 0);

    if (sockfd < 0) {
        perror("Failed to create socket");
        exit(1);
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(atoi(argv[2]));


    setsockopt(sockfd, SOL_SOCKET,
        SO_REUSEPORT, (void *)&option, sizeof option);


    // Bind socket to server address
    if (bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Failed to bind socket");
        exit(1);
    }

    // Get user name
    char username[50];
    strcpy(username, argv[3]);
    username[strlen(argv[3])] = '\0';


    

    // Fork child process for receiving messages
    pid = fork();
    if (pid < 0) {
        perror("Failed to create child process");
        exit(1);
    } else if (pid == 0) {
        /**
         * @brief 자식 프로세스
         * 자식 프로세스에서는 멀티 캐스트로 온 패킷 메시지를 전부 처리해야 한다.
         */
        char buffer[MAX_MSG_LEN];
        int str_len;

        join_adr.imr_multiaddr.s_addr = inet_addr(argv[1]); // multicase group ip
        join_adr.imr_interface.s_addr = htonl(INADDR_ANY); // 멀티캐스트 그룹에 가입할 자신의 IP주소

        setsockopt(sockfd, IPPROTO_IP,
            IP_ADD_MEMBERSHIP, (void *)&join_adr, sizeof join_adr);

        while (1) {
            memset(buffer, 0, sizeof(buffer));
            // 멀티 캐스트가 받을 주소는 NULL로 해준다.
            str_len = recvfrom(sockfd, buffer, MAX_MSG_LEN - 1, 0, NULL, 0);
            if (str_len < 0) {
                perror("Failed to receive message");
                exit(1);
            }
            buffer[str_len] = 0;
            printf("Received Message: %s", buffer);
        }
    } else {
        /**
         * @brief 부모 프로세스
         * 부모 프로세스에서는 메시지를 보내야 한다.
         */
        char message[MAX_MSG_LEN];
        struct sockaddr_in receiver_addr;
        socklen_t receiver_addr_len = sizeof(receiver_addr);

        while (1) {
            fgets(message, sizeof(message), stdin);

            if (message[0] == 'q' || message[0] == 'Q') {
                if (pid != -1) {
                    kill(pid, SIGTERM);
                }
                break;
            }

            // Construct message with username
            char fullMessage[MAX_MSG_LEN + sizeof(username)];
            // fullMessage에 저장하고자 하는 format을 저장한다.
            sprintf(fullMessage, "[%s] %s", username, message);

            memset(&receiver_addr, 0, sizeof(receiver_addr));
            receiver_addr.sin_family = AF_INET;
            receiver_addr.sin_addr.s_addr = inet_addr(argv[1]);
            receiver_addr.sin_port = htons(atoi(argv[2]));

            // Send message to receiver
            ssize_t num_bytes = sendto(sockfd, fullMessage, strlen(fullMessage), 0, (struct sockaddr *)&receiver_addr, receiver_addr_len);
            if (num_bytes < 0) {
                perror("Failed to send message");
                exit(1);
            }
        }

        // Close socket
        close(sockfd);
        
    }

    return 0;
}
