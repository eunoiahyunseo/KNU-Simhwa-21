# class Calculator:
#     def __init__(self):
#         self.result = 0
#     def add(self, num):
#         self.result += num
#         return self.result

# cal1 = Calculator()
# cal2 = Calculator()

# print(cal1.add(3))
# print(cal1.add(4))
# print(cal2.add(3))
# print(cal2.add(7))

# class Concept:
#     def __init__(self, parameter):
#         self.parameter = parameter
#         pass
#     def method(self):
#         return self.parameter

# instance = Concept("argument")
# print(instance.method())

# class Car:
#     color = ""
#     speed = 0

#     def up_speed(self, value):
#         self.speed += value
#     def down_speed(self, value):
#         self.speed -= value

# car = Car()
# print(Car.__dict__)
# car.up_speed(100)
# car.down_speed(200)
# print(car.__dict__)

# class Car:

#     def __init__(self):
#         self.color ="Blue"
#         self.speed = 100

# car = Car()
# print(car.__dict__)

# print(Car.__dict__)

# class Car:
#     count = 0

#     def __init__(self, col, val):
#         self.color = col
#         self.speed = val
#         Car.count += 1
    
# car1 = Car("Blue", 1)
# car2 = Car("Yellow", 2)
# car3 = Car("Green", 3)
# print(Car.count)
# print(Car.__dict__)
# print(car3.__dict__)

# class Test:

#     @staticmethod
#     def plus(x, y):
#         return x + y

#     @classmethod
#     def plus2(cls, x, y):
#         cls.x = x
#         cls.y = y
#         return cls.x + cls.y + cls.number

# add = Test()
# print(add.plus(1, 2))
# print(Test.plus(1, 2))

# class Person:
#     #클래스 속성은 모든 객체가 공유한다.
#     bag = []

#     def put_bag(self, stuff):
#         self.bag2 = []
#         self.bag.append(stuff)
#         self.bag2.append("안경")

# james = Person()
# james.put_bag('책')


# maria = Person()
# maria.put_bag('열쇠')


# print(Person.__dict__)
# print(james.__dict__)

# class Date:
#     string = "date : "
    
#     def __init__(self, date):
#         self.date = self.string + date

#     @staticmethod
#     def now():
#         return Date("today")

#     @classmethod
#     def now2(cls):
#         return cls("today")

#     def show(self):
#         print(self.date)


# class KoreanDate(Date):
#     string = "날짜 : "


# day3 = KoreanDate.now2()
# day3.show()
# day = Date("2020-05-05")
# day2 = day.now()
# day2.show()

# class Car:
#     count = 0
#     _date = "2020-05-05"
#     __company = "KIA"

#     __model_ = "K9"
#     __model__ = "K7"

#     def __init__(self, name):
#         self.brand = name
#         Car.count += 1

#     def get_brand(self):
#         return self.brand #public

#     def _get_date(self):
#         return self._date #protected

#     def __get_company(self):
#         return self.__company #private

# car = Car("hyunseo")

# print(car._Car__company)


# class Car:
#     def __init__(self, name):
#         self.name = name
#         self.speed = 0
#     def up_speed(self, value):
#         self.speed += value
#     def down_speed(self, value):
#         self.speed -= value

# class Sedan(Car):

#     def __init__(self, name, number):
#         self.seat_number = number
#         super().__init__(name)

#     def get_seat_number(self):
#         return self.seat_number

# class Truck(Car):

#     def __init__(self, name, capa):
#         self.capacity = capa
#         super().__init__(name)

#     def get_capacity(self):
#         return self.capacity


# my_car = Sedan("Sonata", 10)
# print(my_car.get_seat_number())

# print(my_car.name)

# class Animal:
#     def __init__(self, name):
#         self.name = name
#         print("class Animal")

#     def get_name(self):
#         print(self.name)

# class Tiger(Animal):
#     def __init__(self, name):
#         print("class Tiger")
#         Animal.__init__(self, name)


# class Lion(Animal):
#     def __init__(self, name):
#         print("class Lion")
#         Animal.__init__(self, name)

# class Liger(Tiger, Lion):
#     def __init__(self, name):
#         print("class Liger")
#         Tiger.__init__(self, name)
#         Lion.__init__(self, name)

# jojo = Liger("Great")
# jojo.get_name()

#이때의 문제점은 최상위 클래스의 생성자가 중복 호출될 수 있다.


# class Animal:
#     def __init__(self, name):
#         self.name = name
#         print("class Animal")

#     def get_name(self):
#         print(self.name)


# class Tiger(Animal):
#     def __init__(self, name):
#         print("class Tiger")
#         super(Tiger, self).__init__(name)

# class Lion(Animal):
#     def __init__(self, name, age):
#         print("class Lion")
#         self.age = age
#         super(Lion, self).__init__(name)

# class Liger(Tiger, Lion):
#     def __init__(self, name, age, face):
#         self.face = face
#         print("class Liger")
#         super(Liger, self).__init__(name, age)

# jojo = Liger("Great", 16, "handsome")
# jojo.get_name()

class A:
    def __init__(self, a):
        self.a = a

class B(A):
    def __init__(self, a, b):
        self.b = b
        super(B, self).__init__(a)

class C(A):
    def __init__(self, a, c):
        self.c = c
        super(C, self).__init__(a)

class D(B, C):
    def __init__(self, a, b, c, d):
        self.d = d
        super(D, self).__init__(a, b, c)

d1 = D(1, 2, 3, 4)

print(d1.a)
print(d1.b)
print(d1.c)
print(d1.d)