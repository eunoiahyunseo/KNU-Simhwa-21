# -*- coding: utf-8 -*-


import turtle as t

def print_key(char):
    print(char, end="")

def key_a():
    print_key("a")
    
def key_sp():
    print_key("s_")
    
def key_sr():
    print_key("s^")
    
s = t.Screen()
s.onkey(key_a, "a")
s.onkeypress(key_sp, "s")
s.onkeyrelease(key_sr, "s")
s.onkey(s.bye, "q")
s.listen()
t.mainloop()