# -*- coding: utf-8 -*-
import turtle as t

color_status = ["white", "blue", "red"]
alert_status = ["정상", "주의", "화재"]
tempc = 50


#온도에 따른 상태를 나타내는 문자열과 생상 원 표시
def check_fire():
    global tempc
    
    if tempc < 80:
        status = 0 #정상
    elif tempc < 120:
        status = 1 #주의
    else:
        status = 2 #화재
        
    t.clear()
    t.home()
    t.pendown()
    t.fillcolor(color_status[status])
    t.begin_fill()
    t.circle(20)
    t.end_fill()
    t.penup()
    t.goto(-22, 50)
    t.write("%s : %d"%(alert_status[status], tempc))


#온도를5도 또는 10도 증가하고, check_fire()함수 호출
def keyUp():
    global tempc
    if tempc < 80:
        tempc += 5
    else:
        tempc += 10
    check_fire()
    

#온도를 5도 또는 10도 감소시키고, check_fire()함수 호출    
def keyDown():
    global tempc
    if tempc < 80:
        tempc -= 5
    else:
        tempc -= 10
    check_fire()
    
    
t.setup(300, 300)
s = t.Screen()
t.hideturtle()
t.speed(0)
check_fire()
s.onkey(keyUp, "Up")
s.onkey(keyDown, "Down")
s.onkey(s.bye, "q")
s.listen()
t.mainloop()
