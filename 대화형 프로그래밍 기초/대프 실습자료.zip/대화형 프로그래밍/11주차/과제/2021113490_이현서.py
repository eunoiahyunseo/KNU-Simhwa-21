import turtle as t

        
def north():
    t.setheading(90)
    t.forward(10)
    

def south():
    t.setheading(270)
    t.forward(10)
    
def east():
    t.setheading(0)
    t.forward(10)
    
def west():
    t.setheading(180)
    t.forward(10)
    
def r():
    t.home()
    t.clear()    
    

s = t.Screen()
s.onkey(north, "Up")
s.onkey(south, "Down")
s.onkey(east, "Right")
s.onkey(west, "Left")
s.onkey(r, "r")
s.listen()
s.mainloop()