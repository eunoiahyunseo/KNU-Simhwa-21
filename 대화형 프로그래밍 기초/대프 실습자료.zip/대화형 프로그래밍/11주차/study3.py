# # -*- coding: utf-8 -*-

# import turtle as t

# def print_number(num):
#     print(num, end="")
    
    
# def print_1()


# s = t.Screen()
# s.onkey(, )
# s.listen()
# t.mainloop()