n = input("문자열을 입력하세요.")
if n in "({[":
    print("존재 합니다.")
else:
    print("없습니다.")