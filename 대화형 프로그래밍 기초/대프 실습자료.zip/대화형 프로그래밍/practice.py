# import sys

# print("버블 정렬 시작")
# #버블 정렬
# a = [4, 9, 2, 1, 5, 7, 10, 46]  #원소 개수 8개
# print(a)
# for i in range(len(a) - 1):
#     for j in range(len(a) - 1):
#         print(j)
#         if (a[j] < a[j + 1]):
#             print(a[j], a[j+1])
#             a[j], a[j + 1] = a[j + 1], a[j]
#             print(a)
        
# print(a)

# print("선택정렬 시작")
# #선택정렬
# a = [4, 9, 2, 1, 5, 7, 10, 46]  #원소 개수 8개
# for i in range(len(a) - 1):
#     b = a[i:]
#     Min = min(b)
#     index = b.index(Min)
#     a[i], a[index + i] = a[index + i], a[i]

# print(a)

# x = 1
# y = 2
# print(x, y)

# x = x^y
# y = y^x
# x = x^y

# print(x, y)

# k = int(input("구하고자 하는 피보나치 수의 갯수 : "))
# def fibo(n):
#     return fibo(n - 1) + fibo(n - 2) if n >= 2 else n
# for n in range(1, k + 1):
#     print(n, fibo(n))


# print("================================")
# def fibo2(n):
#     if n < 2:
#         return n
#     a, b = 0, 1

#     for i in range(n - 1):
#         a, b = b, a + b
#     return b
# for n in range(1, k + 1):
#     print(n, fibo2(n))

# k = 9

# def fibo3(n):
#     list2 = []
#     a, b = 0, 1
#     list2.append(b)
#     for k in range(n - 1):
#         a, b = b, a + b
#         print(f"{b} 더한다")
#         list2.append(b)

#     return list2

# print(fibo3(10))



# def fibo(n, memory = dict()):
#     if n == 1 or n == 2:
#         return 1

#     if n in memory:
#         return memory[n]

#     memory[n] = fibo(n - 1, memory) + fibo(n - 2, memory)

#     return memory[n]


# # print(fibo(102))
# text1 = input("텍스트1 : ").strip()
# text2 = input("텍스트2 : ").strip()
# #문자열 함수인 strip 함수를 활용해서 문자열 양쪽의 공백을 삭제해줍니다.
# #text2를 text1안에서 한번도 찾았는지 확인해줄 변수
# count2 = 0

# #문자열 길이 계산하는 calc_len 사용자 함수 설정
# def calc_len(text):
#     count = 0
#     for i in text:
#         count += 1

#     return count

# #text1의 길이를 계산하는것, text1의 길이만큼 반복하게 된다.
# for i in range(calc_len(text1)):
#     #text1의 원소들을 반복하던중 text2의 첫번째 원소와 같은 원소를 찾게 된다면 if문안으로 들어간다(또한 index out of range를 방지하기 위해 시작된 text1부터 text2의 길이만큼의 여유길이가 존재해야 한다.)
#     if (text1[i] == text2[0] and ((i + 1) + calc_len(text2)) <= calc_len(text1)):
#            #text[i] 문법은 i라면 i-1번째에 있는 문자가 출력되는 것을 의미한다.
#            #관계연산자 and를 활용해서 양쪽의 관계연산자로 만든 두 식을 모두 만족해야만 True가 나오도록 한다. 
#         #text2의 길이를 순회하면서 맞는 횟수를 카운트할 변수
#         count = 0
#         #이제 text2의 길이만큼 반복하면서 비교 시작
#         for k in range(calc_len(text2)):
#             #시작된 text1의 인덱스와 text2의 첫번째 인덱스를 비교하고 text2 길이만큼 반복
#             if (text1[i + k] == text2[k]):
#                 #만약 같다면 count변수를 하나씩 증가시킴
#                 count += 1
#         #만약 count가 text2의 길이와 같다면 포함된다는 뜻이므로 print를 해주어 text1에서 시작된 인덱스를 출력한다.
#         if (count == calc_len(text2)):
#             #또한 한번 포함되는 문자열을 찾았으므로 count2변수를 하나 증가시켜준다.
#             count2 += 1
#             print("%d" %i)
#                   #문자열 포맷팅 정수형태이므로 %d를 활용한다.
            
# #만약 한개라도 찾았으면 그냥 넘어가고 한개도 못찾았으면 count2==0 이 되므로 찾을 수 없습니다를 출력한다.
# if count2 >= 1:
#     pass
# else:
#     print("찾을 수 없습니다.")


# print("%05d" %30)
# print("%07.1f" %30.23)
# print("%7.3f"%30.2)
# print("{:,}".format(100000000))
# print("{:,}".format(100_000_000))
# print(f"{100_000_000:,}")


# print(r"\n \t \' \" \\ 를 그대로 출력")
# print(0b11010011)
# print(int('0b10010011', 2))
# print(int('10010011', 2))

# print(int('0x93', 16))
# print(int('93', 16))

# print(bin(13))
# print(bin(0x13))
# print(bin(0xC5F7))

# num = int(input("숫자를 입력하세요 >>"))
# print(f"2진수 값 \t{num:b}")
# print(f"8진수 값 \t{num:o}")
# print(f"10진수 값 \t{num:d}")
# print(f"16진수 값 \t{num:x}")

# print(f"2진수 값 \t{bin(num)}")
# print(f"8진수 값 \t{oct(num)}")
# print(f"10진수 값 \t{num}")
# print(f"16진수 값 \t{hex(num)}")

# a = 3
# b = 4
# print(f"{a} * {b} = {a / b : 3.1f}")

# c = 1000023
# print(f"{c:034d}")

# tax = 12.5/100
# price = 100.5
# price * tax

# a = 256
# b = 256

# print(a == b)
# print(a is b)
# print(id(a), id(b))

# a = 10
# expr = f"{a >> 1} {a >> 2} {a >> 3} {a >> 4}"
# print(expr)

# a = 12345
# print(~a)
# print(~a  + 1)

# for i in range(2, 10):
#     for k in range(1, 10):
#         print(f"{i} x {k} = {i*k : 3d}")
#     print()

# x_list = [0, 10, 20, 30, 40, 50]

# for index, x in enumerate(x_list):
#     print(index, x, x_list[index])

# a_list = [1, 2, 3, 4, 5]

# a_list.insert(0, 6)
# print(a_list)

# b_list = [1, 2, 3, 4, 5]
# b_list[1:1] = 100, 200
# print(b_list)

# b_list = [1, 6, 2, 3, 4, 5]
# b_list.remove(6)
# print(b_list)

# b_list = [1, 2, 3, 4, 5]
# for attribute in dir(b_list):
#     if attribute[0] == "_":
#         pass
#     else:
#         print(attribute)

# week = "월", "화", "수", "목", "금", "토", "일"

# del week
# print(week)

# a = 0,
# print(type(a), a)

# packing = 1, 2, 3, 4, 5,
# a, b, c, d, e = packing
# print(whos)