def foo():
    global x
    x = 200
    print(locals())
    print(x)


def foo_2():
    x = 100
    print(locals())




def outer_func():
    msg = "Hello, world!"

    def inner_func():
        print(msg)
 
    inner_func()

def A_1():
    x = 100
    def B():
        nonlocal x
        x = 200

    B()
    print(x)



def A_2():
    x = 10
    y = 100
    def B():
        x = 20

        def C():
            nonlocal x
            nonlocal y
            x = x + 30
            y = y + 300
            print(x)
            print(y)

        C()
    B()


x = 1
def A_3():
    x = 10
    def B():
        x = 20
        def C():
            global x
            x += 30
            print(x)
        C()
    B()


def calc_1():
    a = 3
    b = 5
    def mul_add(x):
        return a * x + b
    return mul_add


def calc_2():
    a = 3
    b = 5
    return lambda x: a * x + b


def pr():
    a = 3
    b = 5
    def pc():
        a = 5
        b = 3
    pc()
    print(a, b)


def calc_3():
    a = 3
    b = 5
    total = 0
    def mul_add(x):
        nonlocal total
        total += a * x + b
        print(total)
    return mul_add

def outer():
    x = 100
    def inner():
        print(x)
    return inner


# c = calc_3()
# print(c(1), c(2), c(3))

# foo = outer()
# foo()
#펑션 클로저는 그 함수가 정의될 때 자신을 감싸고 있는 namespace가 어떻게 생겼는지 기억한다는 의미이다.
#간단하게 말하면, 어떠한 함수를 객체로 받을 때 그 함수를 감싸는 scope의 변수들 또한 같이 가져간다는 의미입니다.

#일급객체란
#변수나 데이터 구조에 넣을 수 있다.
#함수의 매개변수에 전달 할 수 있어야 한다.
#반환값(return)으로 사용할 수 있어야 한다.

#실행 중(run-time)에 함수를 생성할 수 있어야 한다.
#파이썬에서는 def안에서 def로 함수를 만들거나, lambda를 사용하여 실행중에 함수를 생성할 수 있으므로,
#파이썬의 함수는 일급 객체 또는 일급시민입니다.


class Calcurator:
    @staticmethod
    def substract(a ,b):
        print(a - b)

# calc = Calcurator()
# calc.substract(100, 10)
# Calcurator.substract(100, 200)


#데코레이터는 기존의 사용자 정의 함수를 수정하지 않은 상태에서 추가 기능을 구현할 떄 사용합니다.
def foo():
    print('foo 함수의 시작')
    print('foo')
    print('foo 함수의 끝')


def bar():
    print('bar 함수의 시작')
    print('bar')
    print('bar 함수의 끝')

# foo()
# bar()

def deco(func):
    def wrapper():
        print(func.__name__, '함수의 시작')
        func()
        print(func.__name__, '함수의 끝')
    return wrapper

def foo_():
    print('foo')
def bar_():
    print('bar')

# deco_foo = deco(foo_)
# deco_foo()

# deco_bar = deco(bar_)
# deco_bar()


@deco
def foo__():
    print('foo')

@deco
def bar__():
    print('bar')

# foo__()
# bar__()

def decorator_01(func):
    def wrapper():
        print('decorator_01')
        func()
    return wrapper

def decorator_02(func):
    def wrapper():
        print('decorator_02')
        func()
    return wrapper


@decorator_02
@decorator_01
def sayfoo():
    print('안녕하세요.')


def sayfoo_():
    print('안녕하세요_')

# decorated_sayfoo = decorator_01(decorator_02(sayfoo_))
# decorated_sayfoo()

#슬기로운 파이썬 트릭
def outer(func):
    def wrapper():
        return '<outer>' + func() + '</outer>'
    return wrapper

def inner(func):
    def wrapper():
        return '<inner>' + func() + '</inner>'
    return wrapper

@outer
@inner
def greeting():
    return "안녕하세요"

# print(greeting())

def decorator(func):
    def wrapper(x, y):
        r = func(x, y)
        print(f"{func.__name__}(x={x}, y={y}) -> {r}")
        return r
    return wrapper

@decorator
def subtract(x, y):
    return x - y


def decorator(func):
    def wrapper(*args, **kwargs):
        r = func(*args, **kwargs)
        print(type(args), type(kwargs))
        print(f"{func.__name__}(args={args}, kwargs={kwargs}) -> {r}")

        return r
    return wrapper

@decorator
def get_max(*args):
    return max(args)

@decorator
def get_min(**kwargs):
    return min(kwargs.values())

# print(get_max(*[10, 20, 30, 40, 50]))
# print(get_min(**dict(x=10, y=20, z=30)))


@decorator
def mul(a, b):
    return a + b

# print(mul(10, 20))


def decorator(func):
    def wrapper(self, x, y):
        r = func(self, x, y)
        print(f"{func.__name__}(x={x}, y={y})->{r}")
        return r
    return wrapper

class Calcurator:
    @decorator
    def substract(self, x, y):
        return x - y


# calc = Calcurator()
# print(calc.substract(100, 10))


import functools

def is_x_multiple(x):
    def real_decorator(func):
        @functools.wraps(func)
        def wrapper(a, b):
            r = func(a, b)
            if r % x == 0:
                print(f"{func.__name__}의 반환값은 {x}의 배수입니다.")
            else:
                print(f"{func.__name__}의 반환값은 {x}의 배수가 아닙니다.")
            return r
        return wrapper
    return real_decorator

@is_x_multiple(3)
def add(a, b):
    return a + b


# print(add(15, 45))
# print(add(20, 15))

def add(a, b):
    return a - b

decorated_add = is_x_multiple(3)(is_x_multiple(7)(add))
decorated_add(10, 5)







@is_x_multiple(2)
@is_x_multiple(3)
@is_x_multiple(7)
def add_(a, b):
    return a + b

# print(add_(10, 20))



class Decorator:

    def __init__(self, func):
        self.func = func

    def __call__(self):
        print(self.func.__name__, '함수의 시작')
        self.func()
        print(self.func.__name__, '함수의 끝')

@Decorator
def sayfoo():
    print('안녕하세요')


def sayfoo_():
    print('안녕하세요')

# deco_sayfoo = Decorator(sayfoo)
# deco_sayfoo()

class Decorator_:
    def __init__(self, func):
        self.func = func

    def __call__(self, *args, **kwargs):
        r = self.func(*args, **kwargs)
        print(f"{self.func.__name__}(args={args}, kwargs={kwargs}) -> {r}")
        return r

@Decorator_
def subtract(*args, **kwargs):
    
    item = list(args) + list(kwargs.values())
    return min(item)
    

# subtract(100, 20)
# subtract(x=100, y=20, z=50)
# subtract(100, 20, x=100, y=20, z=50, r = 10)


class Is_x_multiple:
    def __init__(self, x):
        self.x = x

    def __call__(self, func):
        def wrapper(a, b):
            r = func(a, b)
            if r % self.x == 0:
                print(f'{func.__name__}의 반환값은 {self.x}의 배수입니다.')
            else:
                print(f'{func.__name__}의 반환값은 {self.x}의 배수가 아닙니다.')
            return r
        return wrapper

@Is_x_multiple(3)
def subtract(a, b):
    return a - b

# print(subtract(100, 10))
# print(subtract(200, 150))


def countdown(n):
    count = n
    def down():
        nonlocal count
        count -= 1
    return down

# n = 20
# c = countdown(n)

# print(type(c))

# for i in range(n):
#     print(c(), end=' ')







