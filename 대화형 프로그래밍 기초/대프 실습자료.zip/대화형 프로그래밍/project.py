#requests는 서버에게 url에 해당하는 html을 요청하거나,
#카카오 OpenAPI의 REST API를 사용하기 위함입니다.


#<title>태그

#<link>태그
#<link href="/style.css" rel="stylesheet" type="text/css" />
#주로 css 파일을 연결할 때 사용하는 태그입니다. link요소의 특성을 살펴보면
#href는 해당 CSS파일의 주소
#type과 rel에는 각각의 맞게 적어주게 된다.



#<style> 태그
#<style>태그는 html문서안에 css를 그대로 사용하고자 할때 적어주는 태그입니다.
#style요소 안에 원하는 css내용을 넣으시면 굳이 외부 css파일을 사용하실 필요 없이 html파일 안에서 사용가능합니다.


#<script>태그
#src속성을 넣어 외부에 있는 js를 불러와 사용할 수 있으며 혹은 src속성을 사용하지 않고,
#<script>태그 사이에 javascript코드를 넣어 사용하실 수도 있습니다.

#<h1><h2><h3><h4><h5><h6>태그
#문서 본문의 헤드라인이다.


#<p><pre><br><hr>태그
#p는 문단 태그로서 텍스트를 감싸게 되는 태그입니다.
#웹 페이지에서 텍스트의 경우 따로 감싸지 않고 써도 되는 부분이지만, 명확한 의미를 위함과 동시에 <p>태그 자체가
#가지고 있는 문단으로서 블록요소이기 때문에 사용하는 경우도 종종있습니다.
#pre는 띄어쓰기, 들여쓰기, 줄바꿈 등이 그대로 웹 페이지에 표시되게 되고
#이는 시를 표현하거나 혹은 기태 색다른 텍스트를 표현할 때 쓰이곤 한다.
#br태그는 줄바꿈 태그로서 작용된다.
#hr태그는 화제의 전환등에 사용된다. 사용시 화면에 수평선을 그리게 되어 디자인 상으로 활용되는 경우도 있다.


#



# import requests
# from bs4 import BeautifulSoup
# import re

# webpage = requests.get("https://www.daangn.com/hot_articles")

# soup = BeautifulSoup(webpage.content, "html.parser")


# # print(soup.select(".card-region-name"))

# for x in range(0, 10):
#     print(soup.select(".card-title")[x].get_text())
    
    



# import requests
# from bs4 import BeautifulSoup

# url = "https://velog.io/@swhybein/python-BeautifulSoup으로-크롤링하기"

# req = requests.get(url)

# #<Response [200]>잘 가져왔다는 뜻임
# print(req)

# html = req.test 

# soup = BeautifulSoup(html, "html.parser")

# dict = {'A':1, 'D':4, 'C':3, 'B':2}

# sdict = sorted(dict.items(), key = lambda x : x[1])
# x = [["0" for _ in range(4)] for _ in range(4)]
# print(x)