#%%
import matplotlib.pyplot as plt


x = [i for i in range(20)]
y = [i**2 for i in x]

print(x)
print(y)


plt.plot(x, y, 'r')
# %%
print(x)
# %%
fig = plt.figure()
axe_01 = fig.add_subplot(2, 1, 1)
axe_02 = fig.add_subplot(2, 1, 2)
axe_01.plot(x, y, 'r')
axe_02.bar(x, y)
# %%
fig = plt.figure()
axe_01 = fig.add_subplot(1, 3, 1)
axe_02 = fig.add_subplot(1, 3, 2)
axe_03 = fig.add_subplot(1, 3, 3)


axe_01.plot(x, y)
axe_02.bar(x, y)
axe_03.plot(x, y)
# %%
import math
x = [i for i in range(5)]
print(x)

sin_y = [math.sin(2*math.pi*i) for i in x]
cos_y = [math.cos(2*math.pi*i) for i in x]

print(sin_y)
print(cos_y)



# %%
import numpy as np
x = np.arange(0., 5., 0.1)

sin_y = [np.sin(2 * np.pi * i) for i in x]
cos_y = [np.cos(2 * np.pi * i) for i in x]


fig = plt.figure()
axe_01 = fig.add_subplot(2, 1, 1)
axe_02 = fig.add_subplot(2, 1, 2)

axe_01.plot(x, sin_y, 'b--')
axe_02.plot(x, cos_y, 'r--')


# %%
print(type(x))
# %%
x = np.linspace(-5, 5, 1_000) #ndarray

y = np.power(x, 2)

print(x)
print(y)
# %%

plt.plot(x, y)
plt.grid()
plt.show()

# %%
x = np.linspace(-5, 5, 1_000)
y = np.power(x, 2)

plt.plot(x, y)
plt.title("2d graph")
plt.xlabel("x")
plt.ylabel('y')
plt.xlim((-5, 5))
plt.ylim((0, 25))
plt.grid()
plt.show()
# %%
x = np.linspace(-5, 5, 1000)
print(x)
# %%
plt.plot(x, np.power(x, 2), "r-", label="$x^2$")
plt.plot(x, np.power(x, 3), "g-", label="$x^3$")
plt.plot(x, np.power(x, 4), "b+", label="$x^4$")

plt.title("2d graph")

plt.xlabel("x")
plt.ylabel("y")

plt.xlim((-5, 5))
plt.ylim((0, 25))

plt.grid()
#범례를 추가한다는 의미는 label을 표시한다는 의미이다.
plt.legend(loc="best") #location코드가 많다 best는 0

plt.show()
# %%
#임의의 표준정규분포 데이터 생성

data = np.random.randn(1_000)
print(data)
print(type(data))

fig = plt.figure()
axe_01 = fig.add_subplot(121)
axe_02 = fig.add_subplot(122)

axe_01.set_title("1st histogram")
axe_01.set_xlabel("x value")
axe_01.set_ylabel("y value")
axe_01.grid(True)
axe_01.hist(data, bins=30, density=True, color='b')



axe_02.set_title("1st histogram")
axe_02.set_xlabel("x value")
axe_02.set_ylabel("y value")
axe_02.grid(True)
axe_02.hist(data, bins=30, density=True, color='g', cumulative=True)

#subplots 사이의 간격을 지정해주는 인자다.
plt.subplots_adjust(wspace=.4)
plt.show()

# %%

people = ["Tom", "Dick", "Harry", "Maria", "James"]

y_position = np.arange(len(people))
print(y_position)

performance = 3 + 10 * np.random.rand(len(people))
print(performance)

error = np.random.rand(len(people))
print(error)

plt.barh(y_position, performance,
            xerr=error, align='center', alpha=0.4)
plt.yticks(y_position, people)


plt.xlabel("Performance")
plt.title("How fast do you want to go today?")

plt.show()

# %%

labels = ["Cat", "Dogs", "Birds", "Snakes"]
sizes = [15, 30, 45, 10]
colors = ['yellowgreen', 'gold', 'lightskyblue', 'lightcoral']
explode = [0, 0.1, 0, 0]

plt.pie(sizes, explode=explode, labels=labels, colors=colors,
        autopct="%3.1f%%", shadow=True, startangle=90)


# %%

from mpl_toolkits.mplot3d import Axes3D

def randrange(n, min, max):
    return (max-min)*np.random.rand(n) + min


n = 100
fig = plt.figure()
axe = fig.add_subplot(111, projection='3d')

for c, m, zl, zh in [('r', 'o', -50, -25), ('b', '^', -30, -5)]:
    print(c, m, zl, zh)
    xs = randrange(n, 23, 32)
    ys = randrange(n, 0, 100)
    zs = randrange(n, zl, zh)
    print(xs)
    print(ys)
    print(zs)
    axe.scatter(xs, ys, zs, c=c, marker=m)
    
axe.set_xlabel('X Label')
axe.set_ylabel('Y Label')
axe.set_zlabel('Z Label')

plt.show()
# %%

#numpy배열은 내장 파이썬의 연속된 자료형들보다 훨씬 더 적은 메모리를 사용함
#numpy 연산은 파이썬 반복문을 사용하지 않고 전체 배열에 대한 복잡한 계산을 수행함


mass = [10, 20, 30, 40, 50]
accel = [1, 3, 7, 9, 11]

force = mass * accel
print(force)
# %%

import numpy as np

mass = np.array([10, 20, 30, 40, 50])
accel = np.array([1, 3, 7, 9, 11])

force = mass * accel
print(force)

# %%
force = []

mass = [10, 20, 30, 40, 50]
accel = [1, 3, 7, 9, 11]

for i in range(len(mass)):
    force.append(mass[i] * accel[i])
    
force
# %%
import numpy as np

a_array = np.arange(1_000_000)
a_list = list(range(1_000_000))
print(a_array)
print(a_list)
# %%
for _ in range(10):
    b_array = a_array * 2

# %%

for _ in range(10):
    b_list = [x*2 for x in a_list]

# %%
data = np.random.randint(2, 4, size=(2, 3))
data

# %%


#가우시안 분포로 나타낸다.
data = np.random.randn(2, 3)
print(data)
# %%

data.shape
print(data.dtype)

# %%
data_01 = [5, 6, 7.5, 8, 9.9, 10]
array_01 = np.array(data_01)
array_01
# %%

data_02 = [[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]]
array_02 = np.array(data_02)
array_02
# %%
array_01.ndim
array_02.ndim

# %%
array_01.shape
array_01.dtype


# %%

a = np.zeros(10)
a.dtype

#생성 시 원하는 형태의 튜플을 함수로 전달
b = np.ones((2, 10))
b
# %%

#5*3배열 2개 -> 3차원 배열
np.empty((2, 5, 3))
# %%

np.arange(15)

# %%
np.linspace(1, 5, 10)
# %%
array_01 = np.array([1, 2, 3, 4, 5], dtype=np.float64)
array_02 = np.array([1, 2, 3, 4, 5], dtype=np.int32)

print(array_01.dtype)
print(array_02.dtype)

print(array_01)
print(array_02)
# %%

int_array = np.array([1, 2, 3, 4, 5])
int_array.dtype

# %%


float_array = np.array([1.2, 2.5, 3, 4, 5, 6, 7, 8, 9.0])
print(float_array)
print(float_array.dtype)
float_array.astype(np.int64)
print(float_array)
print(float_array.dtype)

# %%
numeric_string = np.array(['1.25', '-9.6', '42'], dtype=np.string_)
print(numeric_string.dtype)
numeric_string.astype(np.float64)
# %%
int_array = np.arange(10)
int_array
# %%

calibers = np.array([.22, .270, .356, .380, .44, .50], dtype=np.float64)
print(calibers.dtype)
int_array.astype(calibers.dtype)
print(int_array)

# %%

a_array = np.array([[1., 2., 3.], [4., 5., 6.]])
a_array * a_array
# %%


