#%%

import numpy as np
x = np.arange(0., 5., 0.1)


# %%
data = np.random.randn(1_000)

print(data)
# %%
import matplotlib.pyplot as plt
fig = plt.figure()

axe_01 = fig.add_subplot(121)
axe_01 = fig.add_subplot(122)

axe_01.set_title("1st histogram")
axe_01.set_xlabel("x value")
axe_01.set_ylabel("y value")
axe_01.grid(True)
axe_01.hist(data, bins=100, density=True, color='b')

plt.subplots_adjust(wspace=.4)
plt.show()

# %%

people = ["Tom", "Dick", "Harry", "Maria", "James"]

y_position = np.arange(len(people))
performance = 3 + 10 * np.random.rand(len(people))
error = np.random.rand(len(people))

plt.barh(y_position, performance,
        xerr=error, align='center', alpha=0.4)
plt.yticks(y_position, people)

plt.xlabel("Performance")
plt.title("How fast do you want to go tday?")
plt.show()
# %%



a_array = np.arange(1_000_000)
a_list = list(range(1_000_000))

for _ in range(10):
    b_list = [x*2 for x in a_list]

# %%


for _ in range(10):
    b_array = a_array * 2
# %%
data = np.random.randn(2, 3)
data
# %%
a = np.linspace(1, 5, 10)
a.dtype

# %%


array_01 = np.array([1, 2, 3, 4, 5], dtype=np.float64)
array_02 = np.array([1, 2, 3, 4, 5], dtype=np.int32)


print(array_01)
print(array_02)
# %%


float_array = np.array([1.2, 2.5, 3, 4, 5, 6, 7, 8, 9.0])
float_array
# %%
a = float_array.astype(np.int32)
print(a)
# %%

numeric_string = np.array(['1.25', '-9.6', '42'], dtype=np.string_)
a = numeric_string.astype(np.float64)
print(a.dtype)

# %%
int_array = np.arange(10)

calibers = np.array([.22, .270, .356, .380, .44, .50], dtype=np.float64)
a = int_array.astype(calibers.dtype)
print(a.dtype)
# %%
empty_unit32 = np.empty(10, dtype='u4')
empty_unit32
# %%
a_array = np.array([[1., 2., 3.], [4., 5., 6.]])
a_array
# %%
a_array * a_array
# %%
b_array = np.array([[0., 4., 1.], [7., 2., 12.]])
b_array > a_array
# %%

array_2d = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
array_2d
# %%
array_2d[2]
# %%
array_2d[0][2]
# %%
array_2d[0, 2]
# %%
array_2d[:2]
# %%

array_2d[:2, 1:]

# %%
array_2d[1, :2]
# %%
array_2d[:2, 2]
# %%
array_2d[:2, 2:]
# %%
array_2d[:2, 1:] = 0
array_2d
# %%


name_list = ['Bob', 'Joe', 'Will', 'Bob', 'Will', 'joe', 'Joe']
names = np.array(name_list)
type(names)
# %%

data = np.random.randn(7, 4)
data
# %%
names == 'Bob'
# %%

data[names == 'Bob']
# %%
data[names == 'Bob', 2:]
# %%
data[names == 'Bob', 3]
# %%
data[~(names == 'Bob')]
# %%
data[data < 0] = 0

# %%
data
# %%
data[names != 'Joe'] = 7
data
# %%
array_x = np.empty((8, 4))
# %%
array_x
# %%
for x in range(8):
    array_x[x] = x
array_x
# %%
array_x[[4, 3, 0, 6]]
# %%
type(array_x)
# %%
array_x[:, [3]]
# %%
array_f = np.arange(32).reshape(8, 4)
array_f
# %%
array_f[[1, 3, 5, 7], [0, 1, 2, 3]]
# %%
array_f[[1, 3, 5, 7]][:, [0, 1, 2]]
# %%
array_f[[1, 3, 5, 7]]
# %%
array_r = np.arange(15).reshape(3, 5)
array_r
# %%
array_r.reshape(5, -1)
# %%
array_r.reshape(4, -1)
# %%
array_r

# %%
array_r.T
# %%
