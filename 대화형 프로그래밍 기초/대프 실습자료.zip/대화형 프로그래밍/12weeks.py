#--coding: utf-8-

# print(range(100))

# print(iter(range(100)))


# def dir_list(para):
#     attrs = dir(para)
#     for attr in attrs:
#         print(attr, end="\t")
        
# dir_list(["1st", "2st", "3rd"])
# #__iter__메소드가 있으면 반복 가능한 객체


# a_list = ["1st", "2nd", "3rd"]
# print(a_list.__iter__())

# a_list_iter = a_list.__iter__()
# print(a_list_iter.__next__())
# print(a_list_iter.__next__())
# print(a_list_iter.__next__())

# str_iter = "KNU".__iter__()
# print(str_iter.__next__())
# print(str_iter.__next__())
# print(str_iter.__next__())

# #For loop에서 iterator 사용시 Stopiteration 예외가 발생하면 자동으로 종료되도록 설계되어 있음(중요)
# for i in range(3):
#     print(i)
    
# #이런 반복을 클래스 정의시 iterator protocol 이라고 함 (iter, next메소드를 사용하는것)




#iterable vs iterator
#반복가능하다는 의미는 한꺼번에 모두 가져 올 수도 있다는 의미고
#반복자는 한번에 하나의 값만 순서대로 가져 올 수 있다는 의미이다.
#iterable 객체에서 __iter__()메소드를 호출하여 iterator를 생성하여 사용


# it = iter([1, 2, 3])
# print(next(it))
# print(next(it))
# print(next(it))

#iter와 __iter__의 차이를 살펴보자
#내장된 많은 자료형들(list, tuple, string, set, dict)등에 해당하는 자료형에 대한 연산을 정의하는 메소드들이 있습니다.
#그 메소드들은 메소드의 이름 앞뒤에 '__'(double underscore)를 지니고 있다.(던더)
#iter()를 호출하는 것은 __iter__()메소드가 있기 때문에 가능한 것이다.

#리스트, 튜플, range, 문자열은 반복가능하면서 시퀀스 객체
#그러나 세트, 딕셔너리는 반복가능하지만 시퀀스 객체는 아니다.(시퀀싱 못함)
#이유는 시퀀스 객체는 요소의 순서가 정해져 있으나 set, dict는 아님.


# class Iterator_name:
#     def __iter__(self):
#         pass
    
#     def __next__(self):
#         pass
    
    
# class Range:
#     def __init__(self, stop):
#         self.start = 0
#         self.stop = stop
#     def __iter__(self):
#         return self
    
#     def __next__(self):
#         if self.start < self.stop:
#             r = self.start
#             self.start += 1
#             return r
#         else:
#             raise StopIteration

# #내부적으로 __next__메소드를 계속 해주는거니까..
# for i in Range(10):
#     print(i, end=" ")


# print()

# a, b, c = Range(3)
# print(a, b, c)

# a, b, c, d = map(int, "12 34 56 78".split())
# print(a, b, c, d)

# a, b, _, d = Range(4)
# print(a, b, d)

# #반대로 반환값을 패킹(*_)하는 이유는 반환 받을 변수의 개수 불일치를 해소 등의 이유로..
# a, *_ = Range(10)
# print(a)


# class Range:
#     def __init__(self, stop):
#         self.start = 0
#         self.stop = stop
        
#     def __getitem__(self, index):
#         if index < self.stop:
#             return index
#         else:
#             raise IndexError
        
# a = Range(3)[0], Range(3)[1], Range(3)[2]
# print(a)
# print(type(a))
# for i in Range(3):
#     print(i, end=" ")


# import random

# #iter(callable(), sentine1)
# it = iter(lambda : random.randint(1, 5), 4)

# print(type(it))
# print(next(it))
# print(next(it))
# print(next(it))

# a = iter(range(10))
# print(type(a))


# import random
# random.seed(40)
# func = lambda : random.randint(1, 10)
# for i in iter(func, 5):
#     print(i, end=' ')
    
# while True:
#     i = random.randint(1, 10)
#     if i == 5:
#         break
#     print(i, end=' ')

# it = iter(range(3))

# print(next(it, 2))
# print(next(it, 2))
# print(next(it, 2))
# print(next(it, 2))
# print(next(it, 2))

# it = iter(range(3))
# print(next(it, "out of range"))
# print(next(it, "out of range"))
# print(next(it, "out of range"))
# print(next(it, "out of range"))
# print(next(it, "out of range"))
# print(next(it, "out of range"))

# class Range:
#     def __init__(self, start, stop, step):
#         self.start = start
#         self.stop = stop
#         self.step = step
        
#     def __iter__(self):
#         return self
    
#     def __next__(self):
#         self.start += 1
#         if self.start * self.step < self.stop:
#             return self.start * self.step
#         else:
#             raise StopIteration
        
# for i in Range(0, 20, 3):
#     print(i, end=" ")


#iterator는 클래스에 __iter__, __next__ 또는, __getitem__을 이용해 구현하지만
#Generator는 사용자 정의 함수 안에 yield라는 파이썬 키워드를 사용하면 끝
#->그래서 iterator보다 훨씬 간단하게 작성할 수 있다.


# from keyword import kwlist

# print(len(kwlist))
# for kw in kwlist:
#     print(kw, end="\t")


#함수 안에서 yield를 사용하면 함수는 generator가 된다.
#yield에는 값(변수) 지정
# def number_generator():
#     yield 10
#     yield 20
#     yield 30
#     yield 5
#     yield 15
# for number in number_generator():
#     print(number, end=" ")

# ng = number_generator()
# print(ng)
# print(type(ng))

def dir_list(para):
    i = 0
    attrs = dir(para)
    for attr in attrs:
        i += 1
        if i % 5 == 0:
            print(attr)
        else:
            print(attr, end="\t")


# #__iter__, __next__가 있는것으로 보아 이는 iterator라고 할 수 있다.
# dir_list(ng)

#iterator는 __next__ 메소드 안에서 직접 return으로 값을 반환했지만,
#generator는 yield에 지정한 값이 __next__메소드의 반환값으로 나오는 차이가 있다.
#또한, iterator는 raise로 StopIteration 예외를 직접 발생시켰지만,
#generator는 함수의 끝까지 가면 StopIteration 예외가 자동으로 발생한다.

# def num_gen():
#     yield 0
#     yield 1
#     yield 2
    
# ng = num_gen()

# x = ng.__next__()
# print(x)

# x = next(ng)
# print(x)

# x = next(ng)
# print(x)

# #이렇게 제너레이터는 함수를 끝내지 않은 상태에서 yield를 사용하여 값을 바깥으로 전달할 수 있다.
# #즉 return은 반환 즉시 함수가 끝나지만 yield는 잠시 함수 바깥의 코드가
# #실행되도록 양보하여 값을 가져가게 한 뒤 다시 제너레이터 안의 코드를 계속 실행하는 방식이다.(아주중요)


# def show_one_number(x):
#     yield x
#     return "더 이상 내보낼 yield 값이 없습니다."


# try:
#     iterator = iter(show_one_number(2020))
#     print(next(iterator))
#     print(next(iterator))


# except StopIteration as e:
#     print(e)

# def range_gen(stop):
#     n = 0

#     while n < stop:
#         yield n
#         n += 1

# # for i in range_gen(3):
# #     print(i, end=' ')

# print(range_gen(3))
# rg = iter(range_gen(3))
# print(rg)

# try:
#     while True:
#         print(next(rg), end=" ")
# except StopIteration:
#     pass

# rg = range_gen(3)

# print()

# try:
#     while True:
#         print(next(rg), end=" ")
# except StopIteration:
#     pass



# def upper_gen(x):
#     for fruit in x:
#         yield fruit.upper()


# fruits = "apple pear grape orange pineapple".split()
# print(type(fruits))
# for fruit in upper_gen(fruits):
#     print(fruit)

# def num_gen():
#     x_list = [1, 2, 3, 4, 5]
#     for i in x_list:
#         yield i
        
# for i in num_gen():
#     print(i, end=' ')

# #yield from의 경우 매번 반복문을 사용하지 않아도 된다.
# print(num_gen())

# #yield from repeatable_obj
# #yield from iterator_obj
# #yield from generator_obj

# def num_gen2():
#     yield from [1, 2, 3, 4, 5]

# for i in num_gen2():
#     print(i, end=' ')


# ng = num_gen2()
# print()

# try:
#     while True:
#         print(next(ng), end=' ')
# except StopIteration:
#     pass

# #yield from 제너레이터 객체 지정하기
# def range_generator(stop):
#     n = 0
#     while n < stop:
#         yield n
#         n += 1
        
# def three_generator():
#     yield from range_generator(3)
    
# for i in three_generator():
#     print(i, end=' ')


#yield from에 이터레이터 객체 지정하기

# class Range:
#     def __init__(self, stop):
#         self.start = -1
#         self.stop = stop
        
#     def __iter__(self):
#         return self
    
#     def __next__(self):
#         self.start += 1
#         if self.start < self.stop:
#             return self.start
#         else:
#             raise StopIteration
        
# def three_iterator():
#     yield from Range(3)

# for i in three_iterator().__iter__():
#     print(i, end=' ')
    
    
# def number_generator():
#     yield 10
#     yield 20
#     yield 30
#     yield 5
#     yield 15

# ng = number_generator().__iter__()
# try:
#     while True:
#         print(ng.__next__(), end=' ')
# except StopIteration:
#     pass


# import sys

# #generator를 만드는 방법은 'yield'키워드를 쓰는 것 의외에 하나 더 있음.
# #리스트 comprehension을 사용할 때 대괄호[]를 사용했다.
# #같은 리스트 표현식을 괄호()로 묶으면 제너레이터 표현식이 된다.
# a_list = [x for x in range(1_000_000)]
# b_generator = (x for x in range(1_000_000))

# #메모리를 제너레이터 comprehehsion을 사용하면 효과적이게 줄일 수 있다.
# print(sys.getsizeof(a_list))
# print(sys.getsizeof(b_generator))


# def is_prime(n):
#     if n < 2 or n % 1 > 0:
#         return False
#     elif n == 2 or n == 3:
#         return True

#     for x in range(2, int(n**0.5) + 1):
#         if n % x == 0:
#             return False
#         return True
    
    
# def get_primes():
#     value = 0
#     while True:
#         if is_prime(value):
#             yield value
#         value += 1
        
        
# primes = get_primes()

# for i in range(20):
#     print(next(primes), end=' ')
    
# for i in range(20):
#     print(next(primes), end=' ')
