def countdown(n):
    count = n

    def down():
        nonlocal count
        return count
    return down

# n = 20
# c = countdown(n)
# print(type(c))

# for i in range(n):
#     print(c(), end=" ")


def A(n):
    count = n

    def wrapper():
        nonlocal count
        count -= 1
        return count
    return wrapper


# a = A(20)
# print(a())

class Countdown_1:
    def __init__(self, n):
        self.count = n
    def __call__(self):
        r = self.count
        self.count -= 1
        return r


class Countdown_2:
    def __init__(self, n):
        Countdown_2.count = n

    def __call__(self):
        r = Countdown_2.count
        Countdown_2.count -= 1
        return r


class Countdown_3:
    
    @staticmethod
    def __init__(n):
        Countdown_3.count = n
    
    @staticmethod
    def __call__():
        r = Countdown_3.count
        Countdown_3.count -= 1
        return r


class Countdown_4:
    @classmethod
    def __init__(cls, n):
        cls.count = n
    @classmethod
    def __call__(cls):
        r = cls.count
        cls.count -= 1
        return r




# n = 20
# c = Countdown(n)
# print(type(c))
# for i in range(n):
#     print(c(), end=" ")

# n = 20
# c = Countdown_2(n)
# print(type(c))
# for i in range(n):
#     print(c(), end=" ")

# n = 20
# c = Countdown_3(n)
# print(type(c))
# for i in range(n):
#     print(c(), end=" ")

# n = 20
# c = Countdown_4(n)
# # print(type(c))
# # for i in range(n):
# #     print(c(), end=" ")
# c()
# print(c.count)

# n = 20
# c = Countdown_5(n)
# print(type(c))
# for i in range(n):
#     print(c(), end=" ")









# class parent_class:
#     test = 'parent'

#     @classmethod
#     def output_1(cls):
#         return cls.test

#     @staticmethod
#     def output_2():
#         return parent_class.test

# class child_class(parent_class):
#     test = 'child'


# class Windows:
#     os = "window10"		# 클래스 속성

#     def __init__(self):
#         self.out = "OS: " + self.os
        
#     @staticmethod
#     def static_os():
#         return Windows()

#     @classmethod
#     def class_os(cls):
#         return cls()

#     def os_output(self):
#         print(self.out)

# class Linux(Windows):
#     os = "Linux"		# 클래스 속성

# a = Linux.static_os()
# a.os_output()

# b = Linux.class_os()
# b.os_output()





# print(child_class.output_1())
# print(child_class.output_2())