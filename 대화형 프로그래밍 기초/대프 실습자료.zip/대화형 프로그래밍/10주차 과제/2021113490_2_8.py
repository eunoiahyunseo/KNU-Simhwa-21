import math
import turtle as t

def draw_circle(r):
    t.speed(0)
    t.penup()
    t.goto(r, 0)
    for a in range(0, 361):
        rad = math.radians(a)

        x = r * math.cos(rad)
        y = r * math.sin(rad)
        t.pendown()
        t.goto(x, y)
    t.done()
        
draw_circle(100)