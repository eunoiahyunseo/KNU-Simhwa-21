
        
# n = int(input("총 입력 갯수 : "))
# result_list = []

# def determine():
#     global result_list
#     for _ in range(n):
#         result_list
#         bracket = input()
#         stack = list()
#         bracket_list_v1 = ["(", "{", "["]
#         bracket_list_v2 = [")", "}", "]"]

#         for k in bracket:
#             if k in '([{':
#                 stack.append(k)
#             elif k in ")}]":
#                 if not stack:
#                     result_list.append(False)
#                     return False
#                 else:
#                     top_match = stack.pop()
#                     index = bracket_list_v2.index(k)
#                     if (bracket_list_v1[index] != top_match):
#                         result_list.append(False)
#                         return False
#         result_list.append((len(stack) == 0))
#         return (len(stack) == 0)
        
# for _ in range(n):
#     determine()
# for i in result_list:
#     if i == True:
#         print("YES")
#     else:
#         print("NO")
            
            
            
# n = int(input("총 입력 갯수 : "))
# result_list = []
# result_list_2 = []

# def determine():
#     global result_list
#     for _ in range(n):
#         bracket = input()
#         stack = list()
        
#         list_1 = ["(", "{", "["]
#         list_2 = [")", "}", "]"]
                
#         for k in bracket:
#             if k in "({[":
#                 stack.append(k)
#             elif k in ")}]":
#                 if stack:
#                     top_match = stack.pop()
#                     index = list_2.index(k)
#                     if(list_1[index] == top_match):
#                         pass
#                     else:
#                         return False
#                 else:
#                     return False
#         if (len(stack) == 0):
#             return True
#         else:
#             return False
        
# for _ in range(n):
#     result_list_2.append(determine())
    
# for i in result_list_2:
#     if i:
#         print("YES")
#     else:
#         print("NO")    

import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

a = np.arange(10)
print(a)
