items = {'공책':325, '연필':427, '지우개':125, '복사지':510}

stored_standard = int(input("파악 재고수 기준 : "))

for i in items:
    if items[i] < stored_standard:
        print(f"공책 : {items[i]}")

    