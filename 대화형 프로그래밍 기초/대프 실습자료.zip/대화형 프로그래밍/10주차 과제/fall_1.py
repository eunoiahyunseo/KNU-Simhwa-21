import turtle as t
def draw_pos(x,y):
    t.clear()
    t.setpos(x,y)
    t.stamp()

    hl = -(t.window_height() / 2)

    tm = 0
    while True:
        y = y-(9.81/2*tm*tm)
        t.goto(x,y)
        t.stamp()
        if y < hl:
            break
        tm += 0.3


t.setup(500,600)
t.shape("circle")
t.shapesize(0.3,0.3,0)
t.penup()
s = t.Screen()
s.onscreenclick(draw_pos)
s.listen()
t.mainloop()
t.done()