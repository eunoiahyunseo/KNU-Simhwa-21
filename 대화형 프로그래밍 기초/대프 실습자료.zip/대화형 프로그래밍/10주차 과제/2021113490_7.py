import math

i = float(input("실수 : "))

print(i, math.ceil(i))
print(i, math.floor(i))
print(i, math.trunc(i))