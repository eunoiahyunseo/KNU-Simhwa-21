import turtle as t
t.speed(0)
def write_xy(x, y):
    t.penup()
    t.goto(x, y)
    t.pendown()
    t.circle(50)

def screen_clear(x, y):
    t.clear()

t.setup(600, 600)
t.penup()

s = t.Screen()
s.onscreenclick(write_xy, 1)
s.onscreenclick(screen_clear, 2)
s.listen()
t.mainloop()
t.done()
