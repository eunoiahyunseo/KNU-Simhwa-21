import math

i = int(input("정수 : "))
print(float(i), ":", math.sqrt(i))