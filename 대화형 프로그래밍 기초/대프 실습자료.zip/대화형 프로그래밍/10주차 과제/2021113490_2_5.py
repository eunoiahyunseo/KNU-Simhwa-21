moneys = {1:50000, 2:10000, 3:5000, 4:1000, 5:500, 6:100, 7:50, 8:10, 9:5, 10:1}

cost = int(input("금액 : "))
count = 0
sum = 0

for i in range(1, len(moneys) + 1, 1):
    a = cost // moneys[i]
    cost -= a * moneys[i]

    if a != 0:
        count += 1
        sum += a
    print(f"{moneys[i]} : {a}")

print(f"총 {count} 종류 {sum} 개 필요")