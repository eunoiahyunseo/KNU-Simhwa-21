a = hex(256)
print(a)