str = input("문자열 : ")
str_1 = ""
for i in range(len(str)):
    str_1 += str[i]
    
print("개별 문자 출력 : ", str_1)


str_2 = ""
for j in range(len(str) - 1, -1, -1):
    str_2 += str[j]

print("역순 개별 문자 출력 : ", str_2)

