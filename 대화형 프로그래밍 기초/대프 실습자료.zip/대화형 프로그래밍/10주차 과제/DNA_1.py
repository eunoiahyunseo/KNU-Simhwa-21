#상보적 방식 (A->T, T->A, G->C, C->G)
#역순 방식
#상보적 역순 방식


def comp(seq):
    comp_dict = {
        'A':'T',
        'T':'A',
        'C':'G',
        'G':'C'
    }

    seq_comp = ""

    for i in seq:
        seq_comp += str(comp_dict[i])
        
    return seq_comp

def rev(seq):
    # seq_rev = sorted(seq, reverse=True)
    seq_rev = ""
    length = (len(seq) - 1)
    while length >= 0:
        seq_rev += str(seq[length])
        length -= 1


    return seq_rev

def rev_comp(seq):
    seq = comp(seq)
    return rev(seq)    


src = input("DNA sequence : ")
print(src)
count = 0
is_in = False
for k in src:
    if k in 'ATGC':
        count += 1

if count == len(src):
    is_in = True

if is_in:
    cnvt = int(input("1(comp), 2(Rev), 3(Rev_Comp): "))
    if cnvt <= 3 and cnvt >= 1:
        if (cnvt == 1):
            rst = comp(src)
        elif (cnvt == 2):
            rst = rev(src)

        elif (cnvt == 3):
            rst = rev_comp(src)
        
        print(src, "->", rst)

    else:
        print('1(Comp), 2(Rev), 3(Rev_Comp)!!')
else:
    print("ATGC가 src안에 들어가게 문자열을 입력해 주세요")
