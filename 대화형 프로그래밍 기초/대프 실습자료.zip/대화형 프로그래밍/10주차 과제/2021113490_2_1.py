sales = {1:8, 2:6, 3:10, 4:13}

for i in range(1, 5, 1):
    print(i, "분기 :", '#' * sales[i], "(", sales[i], ")")