dic_s = dict()

while True:
    english_word = input("영어 단어 : ")

    if not dic_s:
        print("사전이 비어 있습니다.")

        print("단어를 추가합니다.")
        korea_word = input("한글 단어 : ")
        dic_s[english_word] = korea_word
    elif (dic_s) and (english_word not in dic_s.keys()) and (english_word):
        print(f"{english_word} 단어가 등록되어 있지 않습니다.")
        print("단어를 추가합니다.")
        korea_word = input("한글 단어 : ")
        dic_s[english_word] = korea_word
    elif not english_word:
        print(dic_s)
        break
    else:
        print(f"{english_word} : {dic_s[english_word]}")

