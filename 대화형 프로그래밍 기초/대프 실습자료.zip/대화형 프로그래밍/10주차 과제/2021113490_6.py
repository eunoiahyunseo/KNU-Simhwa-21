import time
import sys
for i in range(1, 6):
    print(i, end=" ", flush=True)
    time.sleep(1)