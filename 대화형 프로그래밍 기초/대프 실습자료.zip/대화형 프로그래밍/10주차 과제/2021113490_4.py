score = int(input("점수 : "))

deg = {
    10:'A',
    9:'A',
    8:'B',
    7:'C',
    6:'D',
    5:'F',
    4:'F',
    3:'F',
    2:'F',
    1:'F',
    0:'F'
}

k = score // 10
if score >= 0 and score <= 100:
    if (k == 9 or k == 10):
        print(score, ": ", deg[k])
    elif k == 8:
        print(score, ": ", deg[k])
    elif k == 7:
        print(score, ":", deg[k])
    elif k == 6:
        print(score, ":", deg[k])
    elif k == 5 or k == 4 or k == 3 or k == 2 or k == 1 or k == 0:
        print(score, ":", deg[k])
else:
    print("입력 가능한 점수 범위는 0~100입니다.")
    
    
    