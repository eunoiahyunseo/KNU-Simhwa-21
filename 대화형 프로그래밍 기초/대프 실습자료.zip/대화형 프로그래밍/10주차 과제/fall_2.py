import turtle as t
import math
tm = 0.3
ux = 0
uy = 0
dx = 0
dy = 0
g = 0.8
velo = 0
ang = 0

def draw_pos(x, y):

    tm = 0.3
    ux = 0
    uy = 0
    dx = 0
    dy = 0
    g = 9.8
    velo = 0
    ang = 0
    velo = t.numinput("입력", "속도 : ", 50, 10, 100)
    ang = math.radians(t.numinput("입력", "각도 : ", 45, 0, 360))

    t.clearstamps()
    t.hideturtle()
    t.setpos(x, y)
    t.showturtle()
    t.stamp()

    hl = -(t.window_height() / 2)
    ux = velo * math.cos(ang)
    uy = velo * math.sin(ang)

    while True:
        x_distance = x + ux * tm
        y_distance = y + uy * tm - 1/2 * g * tm * tm
        t.goto(x_distance, y_distance)

        if y > hl:
            t.stamp()
        else:
            break

    
        tm += 0.3


t.setup(600, 600)
t.shape("circle")
t.shapesize(0.3, 0.3, 0)
t.penup()

s = t.Screen()
s.onscreenclick(draw_pos)
s.listen()
t.mainloop()
t.done()
